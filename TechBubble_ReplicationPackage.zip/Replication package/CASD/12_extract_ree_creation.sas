



/*===============================================================================
    Specify the project and path 
===============================================================================*/

%let project = TechBoom_replicationPackage ;
%let rawdatadir = \\casd.fr\casdfs\Projets\FISCENT\Data;
%let outdir = C:\Users\Public\Documents\&project.\rawdata\raw\ree_creation;


/**********************************************************/
/* Macro to transform upper case to lower case (important for dta export) */
/**********************************************************/

%macro lower_vars(lib=WORK, data=mydata);
	proc sql noprint;
		select cats(name,'=',lower(name))
		into :renlist separated by ' '
		from dictionary.columns
		where libname = upcase("&lib")
		  and memname = upcase("&data")
		  and name ne lowcase(name);
	quit;
	%if %length(%superq(renlist)) %then %do;
		proc datasets lib=&lib nolist;
			modify &data;
			rename &renlist;
		quit;
	%end;
	%else %put NOTE: all variables already in lowercase;
%mend;

/*===============================================================================
    Extract ree creation entreprises raw data  
===============================================================================*/

%macro ree_creation(fyear=, lyear=, outdir=);
    %local year;

    %do year = &fyear %to &lyear;

        data _null_;
            put "NOTE: Processing Year=&year";
        run;

	    /* Determine subdirectory and filename */
	    %if &year >= 1993 and &year <= 2006 %then %do;
	        %let subdir = \R�tropol�es;
	        %let filename = creat&year.;
	    %end;
	    %else %if &year >= 2007 and &year <= 2008 %then %do;
	        %let subdir = \R�tropol�es;
	        %let filename =  crea&year.;
	    %end;
	    %else %if &year >= 2009 and &year <= 2011 %then %do;
	        %let subdir = ;
	        %let filename = france;
	    %end;
	    %else %if &year >= 2012 and &year <= 2015 %then %do;
	        %let subdir = ;
	        %let filename = cren&year;
	    %end;

	    libname ree&year "&rawdatadir.\REE_Cr�ations Entreprises_&year.&subdir.";
        %let lib = ree&year;

        /* Load raw data */
        data mydata;
            set &lib..&filename (keep = SIREN CJ APEN);;
        run;

 		/* Macro to rename upper case to lower case */
		%lower_vars(lib=work, data=mydata);

		/* Export in dta */ 
		proc export data=mydata outfile="&outdir.\ree_creation&year..dta" replace;
		run;

		/* Clean memory */
		proc datasets lib=work nolist;
			delete mydata collapsed;
		quit;

    %end;
%mend;

%ree_creation(fyear=1993, lyear=2015, outdir=&outdir);




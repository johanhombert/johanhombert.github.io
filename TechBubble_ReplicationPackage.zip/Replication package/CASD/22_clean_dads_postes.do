
* This code starts from DADS Postes files in Stata format, select variables, do some cleaning, and save data in Stata format.

* create folder for cleaned data
// cd "${dir}/rawdata/dads_postes"
// capture mkdir cleaned
//
cd "${dir}"


*** Construct annual worker-level DADS files 1994-2015
forvalues t = 1994(1)2008 {

	* Determine region variable name
	if `t' <= 2001 {
		local region_var "reg"
	}
	else {
		local region_var "regt"
	}

	* Append all regions
	clear
	gen r = ""
	foreach r in 11 21 22 23 24 25 26 31 41 42 43 52 53 54 72 73 74 82 83 91 93 94 97 99 {
		append using "rawdata/raw/dads_postes/dads_postes_`t'_`r'"
		replace r = "`r'" if r==""
	}
	* dads file for a given region includes a job spell if either the establishment is located in the region or the individual lives in the region -> keep only if establishment region = file region to drop duplicates
	keep if `region_var'==r
	drop r

	* Year-specific variable transformations
// 	if `t' <= 1996 {
// 		* until 1996: 10-digit siren and 6-digit nic
// 		replace siren = substr(siren,2,9)
// 		replace nic = substr(nic,2,5)
// 	}
// 	if inrange(`t', 1997, 2001) {
// 		* 1997-2001: 10-digit siren 
// 		* nic is 6 digit instead of usual 5 
// // 		rename sirenn siren
// 		rename nicc nic
// 	}
	* Ensure that siren is always 9 digit (sometimes 10 with leading zero) and nic 5 digit (sometimes 6 with leading zero)
	replace siren 	= substr(siren,-9,.)
	replace nic 	= substr(nic,-5,.)

	* Variable renamings
	if `t' <= 2001 {
		rename cipdz ce
// 		rename eqtc etp
	}
	else {
		*rename s_net netnet // net wage
		rename s_brut brut
		rename cs cs2 // 2-digit occupation
		rename pcs pcs4
		rename cpfd ce
	}

	* Currency conversion for pre-2000 years
	if `t' <= 1999 {
		foreach x in brut brut_1 {
			replace `x' = `x'/6.55957
		}
	}

	rename siren sir
	merge m:1 sir using "output/dads_panel_list_of_sir", keep(3) nogen
	save "${dads_postes}/dads_postes_`t'", replace
}

*** 2009-2011
forvalues t = 2009(1)2011 {
	* append all regions
	clear
	gen r = ""
	* list of files change from year to year
	if `t'==2009 {
		foreach r in 11aa 11bb 11cc 11dd {
		append using "rawdata/raw/dads_postes/dads_postes_`t'_`r'"
		}
		replace r = "11" if r==""
		foreach r in 21 22 23 24 25 26 31 41 42 43 52 53 54 72 73 74 82 83 91 93 94 97 99 {
		append using "rawdata/raw/dads_postes/dads_postes_`t'_`r'"
		replace r = "`r'" if r==""
		}
	}
	if `t'==2010 {
		foreach r in 11aa 11bb 11cc 11dd {
		append using "rawdata/raw/dads_postes/dads_postes_`t'_`r'"
		}
		replace r = "11" if r==""
		foreach r in 82a 82b {
		append using "rawdata/raw/dads_postes/dads_postes_`t'_`r'"
		}
		replace r = "82" if r==""
		foreach r in 21 22 23 24 25 26 31 41 42 43 52 53 54 72 73 74 83 91 93 94 97 99 {
		append using "rawdata/raw/dads_postes/dads_postes_`t'_`r'"
		replace r = "`r'" if r==""
		}
	}
	if `t'==2011 {
		foreach r in 11 21 22 23 24 25 26 31 41 42 43 52 53 54 72 73 74 82 83 91 93 94 97 99 {
		append using "rawdata/raw/dads_postes/dads_postes_`t'_`r'"
		replace r = "`r'" if r==""
		}
	}
	* dads file for a given region includes a job spell if either the establishment is located in the region or the individual lives in the region -> keep only if establishment region = file region to drop duplicates
	keep if regt==r
	drop r

	*rename s_net netnet // net wage
	rename s_brut brut
	rename pcs pcs4
	gen cs2 = substr(pcs4,1,2) // cs2 no longer in the raw data 
	rename cpfd ce
	rename siren sir
	merge m:1 sir using "output/dads_panel_list_of_sir", keep(3) nogen
	save "${dads_postes}/dads_postes_`t'", replace
}

*** 2012-2013
forvalues t = 2012(1)2013 {
	* append all regions
	clear
	gen r = ""
	foreach r in 21 22 23 24 25 26 31 41 42 43 52 53 54 72 73 74 82 83 91 93 94 97 99 { // all regions except ile de france
	append using "rawdata/raw/dads_postes/dads_postes_`t'_`r'"
	replace r = "`r'" if r==""
	}
	* dads file for a given region includes a job spell if either the establishment is located in the region or the individual lives in the region -> keep only if establishment region = file region to drop duplicates
	keep if regt==r
	drop r

	save "${dads_postes}/dads_postes_`t'", replace

	* append all ile-de-france departements
	clear
	gen d = ""
	foreach d in 75 77 78 91 92 93 94 95 {
	append using "rawdata/raw/dads_postes/dads_postes_`t'_`d'idf"
	replace d = "`d'" if d==""
	}
	* dads file for a given region includes a job spell if either the establishment is located in the region or the individual lives in the region -> keep only if establishment region = file region to drop duplicates
	keep if dept==d
	drop d

	append using "${dads_postes}/dads_postes_`t'"

	*rename s_net netnet // net wage
	rename s_brut brut
	rename pcs pcs4
	gen cs2 = substr(pcs4,1,2) // cs2 no longer in the raw data 	
	rename cpfd ce
	rename siren sir
	merge m:1 sir using "output/dads_panel_list_of_sir", keep(3) nogen

	save "${dads_postes}/dads_postes_`t'", replace
}

*** 2014-2015
forvalues t = 2014(1)2015 {
	display in red "-----------		`t'		-----------"

	// Regions
	* restrict immediately to the set of siren we want to work with
	foreach r in 24 27 28 32 44 52 53 75 76 84 93 94 97 99 { // all regions except ile de france
		use "rawdata/raw/dads_postes/dads_postes_`t'_`r'", clear
			gen r = "`r'"
		rename siren sir
		merge m:1 sir using "output/dads_panel_list_of_sir", keep(3) nogen
		tempfile dads_postes_`t'_`r'
		save `dads_postes_`t'_`r''
	}
	* append all regions
	clear
	foreach r in 24 27 28 32 44 52 53 75 76 84 93 94 97 99 { // all regions except ile de france
		append using `dads_postes_`t'_`r''
	}
	* dads file for a given region includes a job spell if either the establishment is located in the region or the individual lives in the region -> keep only if establishment region = file region to drop duplicates
	keep if regt==r
	drop r

	save "${dads_postes}/dads_postes_`t'", replace

	// append all ile-de-france departements
	*local t = 2014
	clear
	foreach d in 75 77 78 91 92 93 94 95 {
		use "rawdata/raw/dads_postes/dads_postes_`t'_`d'idf",clear
			gen d = "`d'"
		rename siren sir
		merge m:1 sir using "output/dads_panel_list_of_sir", keep(3) nogen
		tempfile dads_postes_`t'_`d'idf
		save `dads_postes_`t'_`d'idf'
	}
	clear
	foreach d in 75 77 78 91 92 93 94 95 {
		append using `dads_postes_`t'_`d'idf'
	}
	/* dads file for a given region includes a job spell if either the establishment is located in the region or the individual lives in the region
	-> keep only if establishment region = file region to drop duplicates
	*/
	keep if dept==d
	drop d

	append using "${dads_postes}/dads_postes_`t'"

	rename s_brut brut
	rename pcs pcs4
	gen cs2 = substr(pcs4,1,2) // cs2 no longer in the raw data 	
	rename cpfd ce
	save "${dads_postes}/dads_postes_`t'", replace
}
*

*===============================================================================
* Firm level employment by age bins for selected years  
*===============================================================================

forval t = 2001(1)2008 {

	* Determine region variable name
	if `t' <= 2001 {
		local region_var "reg"
	}
	else {
		local region_var "regt"
	}

	* Append all regions
	clear
	gen r = ""
	foreach r in 11 21 22 23 24 25 26 31 41 42 43 52 53 54 72 73 74 82 83 91 93 94 97 99 {
		append using "rawdata/raw/dads_postes/dads_postes_`t'_`r'"
		replace r = "`r'" if r==""
	}
	* dads file for a given region includes a job spell if either the establishment is located in the region or the individual lives in the region -> keep only if establishment region = file region to drop duplicates
	keep if `region_var'==r
	drop r
	if `t' > 2001 {
		rename cs cs2  
	}
	keep siren cs2 age nbheur
	
	* Ensure that siren is always 9 digit (sometimes 10 with leading zero) and nic 5 digit (sometimes 6 with leading zero)
	replace siren 	= substr(siren,-9,.)
	rename siren sir
	
	* Drop if missing variables
	drop if age==. | nbheur==.
	replace nbheur = 0 if nbheur<0
	* Skilled STEM workers
	keep if cs2=="38"
	gen n_stem = cs2=="38"
	gen h_stem = (cs2=="38")*nbheur
	
	* Age groups
	foreach agegp in 30 35 40{
		gen agegroup`agegp' = age <=`agegp' 
	}

	* Employment by age group
	foreach agegp in 30 35 40{
		gen n_stem_`agegp' = n_stem *agegroup`agegp'
		gen h_stem_`agegp' = h_stem *agegroup`agegp'
	}
	
	* Age-weighted employment, used to construct mean worker age
	gen n_stem_age = n_stem * age
	gen h_stem_age = h_stem * age
	
	* collapse median age weighted by hour 
	preserve 
		gcollapse(median) medage_h_stem = age (mean) avgage_h_stem = age [aw=nbheur] ,by(sir)
		tempfile temp 
		save `temp'
	restore 	
	* Collapse by firm
	gcollapse (sum) n_* h_* (median) medage_n_stem = age , by(sir)
	
	* Mean worker age
	qui gen avgage_n_stem = n_stem_age/n_stem
	qui gen avgage_h_stem = h_stem_age/h_stem
	
	merge 1:1 sir using `temp',nogen 
	
	save "output/employment_age_`t'", replace
}

*** 2010
forval t =2009(1)2010 {
	* append all regions
	clear
	gen r = ""
	* list of files change from year to year
	if `t'==2009 {
		foreach r in 11aa 11bb 11cc 11dd {
		append using "rawdata/raw/dads_postes/dads_postes_`t'_`r'"
		}
		replace r = "11" if r==""
		foreach r in 21 22 23 24 25 26 31 41 42 43 52 53 54 72 73 74 82 83 91 93 94 97 99 {
		append using "rawdata/raw/dads_postes/dads_postes_`t'_`r'"
		replace r = "`r'" if r==""
		}
	}
	if `t'==2010 {
		foreach r in 11aa 11bb 11cc 11dd {
		append using "rawdata/raw/dads_postes/dads_postes_`t'_`r'"
		}
		replace r = "11" if r==""
		foreach r in 82a 82b {
		append using "rawdata/raw/dads_postes/dads_postes_`t'_`r'"
		}
		replace r = "82" if r==""
		foreach r in 21 22 23 24 25 26 31 41 42 43 52 53 54 72 73 74 83 91 93 94 97 99 {
		append using "rawdata/raw/dads_postes/dads_postes_`t'_`r'"
		replace r = "`r'" if r==""
		}
	}
	if `t'==2011 {
		foreach r in 11 21 22 23 24 25 26 31 41 42 43 52 53 54 72 73 74 82 83 91 93 94 97 99 {
		append using "rawdata/raw/dads_postes/dads_postes_`t'_`r'"
		replace r = "`r'" if r==""
		}
	}
	* dads file for a given region includes a job spell if either the establishment is located in the region or the individual lives in the region -> keep only if establishment region = file region to drop duplicates
	keep if regt==r
	keep siren pcs age nbheur

	gen cs2 = substr(pcs,1,2)  
	rename siren sir

	* Drop if missing variables
	drop if age==. | nbheur==.
	replace nbheur = 0 if nbheur<0
	* Skilled STEM workers
	keep if cs2=="38"
	gen n_stem = cs2=="38"
	gen h_stem = (cs2=="38")*nbheur
	
	* Age groups
	foreach agegp in 30 35 40{
		gen agegroup`agegp' = age <=`agegp' 
	}

	* Employment by age group
	foreach agegp in 30 35 40{
		gen n_stem_`agegp' = n_stem *agegroup`agegp'
		gen h_stem_`agegp' = h_stem *agegroup`agegp'
	}
	
	* Age-weighted employment, used to construct mean worker age
	gen n_stem_age = n_stem * age
	gen h_stem_age = h_stem * age
	
	* collapse median age weighted by hour 
	preserve 
		gcollapse(median) medage_h_stem = age (mean) avgage_h_stem = age [aw=nbheur] ,by(sir)
		tempfile temp 
		save `temp'
	restore 	
	* Collapse by firm
	gcollapse (sum) n_* h_* (median) medage_n_stem = age , by(sir)
	
	* Mean worker age
	qui gen avgage_n_stem = n_stem_age/n_stem
	qui gen avgage_h_stem = h_stem_age/h_stem
	
	merge 1:1 sir using `temp',nogen 
	
	save "output/employment_age_`t'", replace
}


*===============================================================================
* Erase raw dta 
*===============================================================================

local files : dir "rawdata/raw/dads_postes" files "*"
foreach f of local files {
	capture erase "rawdata/raw/dads_postes/`f'"
	if _rc di as error "Could not delete: $temp/`f'"
}


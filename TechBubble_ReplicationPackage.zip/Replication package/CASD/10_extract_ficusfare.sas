


/*===============================================================================
    Specify the project and path 
===============================================================================*/

%let project = TechBoom_replicationPackage ;
%let rawdatadir = \\casd.fr\casdfs\Projets\FISCENT\Data;
%let inpath= \\casd.fr\casdfs\Projets\FISCENT\Data;
%let outdir = C:\Users\Public\Documents\&project.\rawdata\raw\ficus_fare;

/*===============================================================================
/* Macro to transform upper case in lower case (important for dta export) 
===============================================================================*/

%macro lower_vars(lib=WORK, data=mydata);
    proc sql noprint;
        select cats(name,'=',lower(name))
        into : renlist separated by ' '
        from dictionary.columns
        where libname = upcase("&lib")
        and memname = upcase("&data")
        and name ne lowcase(name);
    quit;
    %if %length(&renlist) %then %do;
        proc datasets lib=&lib nolist;
            modify &data;
            rename &renlist;
        quit;
    %end;
%mend;

/*===============================================================================
    FICUS
===============================================================================*/

%macro ficus(fyear=, lyear=, outdir=);
    %local year yr2;

    %do year = &fyear %to &lyear;
        %let yr2 = %substr(&year, 3, 2);

		data _null_;
		put "NOTE: Year=&year YR2=&yr2";
		run;

		/* Handle the fact that path changes over years */
		%if (&year >= 1994 & &year<=2000) %then %do;
			libname ficus&yr2 "&rawdatadir.\Statistique annuelle d'entreprise_FICUS_&year\Fichiers en euros";
		%end;
		%else %if (&year >= 2001 & &year<=2004) %then %do;
			libname ficus&yr2 "&rawdatadir.\Statistique annuelle d'entreprise_FICUS_&year\Fichiers avec les unit�s l�gales";
		%end;
		%else %if (&year >= 2005 & &year<=2007) %then %do;
			libname ficus&yr2 "&rawdatadir.\Statistique annuelle d'entreprise_FICUS_&year\Fichiers avec les unit�s consolid�es et les unit�s l�gales hors contours des profilages";
		%end;

		/* Load raw data and append apu, fin and tab */
		data mydata;
		set ficus&yr2..apu ficus&yr2..fin ficus&yr2..tab ;
		run;
		
		/* Macro to rename upper case to lower case */
		%lower_vars(lib=work, data=mydata);

		/* Export in dta */ 
		proc export data=mydata outfile="&outdir.\ficus_&year..dta" replace;
		run;

		/* Clean memory */
		proc datasets lib=work nolist;
			delete mydata collapsed;
		quit;

    %end;
%mend;

%ficus(fyear=1994, lyear=2007, outdir=&outdir);

/*===============================================================================
    FARE
===============================================================================*/

%macro fare(fyear=, lyear=, outdir=);
    %local year mem;

    %do year = &fyear %to &lyear;

		%put NOTE: Processing FARE year=&year;

		/* Handle the fact that raw data has different names over years */
		%if (&year = 2008 or &year = 2009) %then %do;
			%let mem = tab;
		%end;
		%else %if (&year = 2010 or &year = 2011) %then %do;
			%let mem = fare&year;
		%end;
		%else %if (&year = 2012) %then %do;
			%let mem = fare&year._meth&year;
		%end;
		%else %do;
			%let mem = fare&year.meth&year;
		%end;

		/* Load raw data - keeping ALL variables */
		data mydata;
			set "&rawdatadir.\Statistique annuelle d'entreprise_FARE_&year.\&mem..sas7bdat";
		run;

		/* Macro to rename upper case to lower case */
		%lower_vars(lib=work, data=mydata);

		/* Export in dta */
		proc export data=mydata outfile="&outdir.\fare&year..dta" replace;
		run;

		/* Clean memory */
		proc datasets lib=work nolist;
			delete mydata;
		quit;


    %end;
%mend;

%fare(fyear=2008, lyear=2017, outdir=&outdir);

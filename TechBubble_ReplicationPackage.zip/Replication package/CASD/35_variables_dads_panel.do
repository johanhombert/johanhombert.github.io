
cd "${dir}"


*===============================================================================
* 	JOB TERMINATION
*===============================================================================
{

*** Identify next full-time job after a job termination

use nni year sir sb s_brut dp nbheur using "output/dads_panel", clear

* we don't need cohorts before 1993
drop if year<1993

* wage
gen wage 		= sb/dp*30 if year<2008
replace wage	= s_brut/dp*30 if year>=2008
drop if wage==.
drop sb s_brut

* simplify the data structure: keep the highest paying job per year
sort nni year wage dp sir
by nni year: keep if _n==_N

* firm information
merge m:1 sir year using "output/firm_all_var", keep(1 3) nogen keepusing(gemp1)
rename gemp1 term_gemp_ficus

	* loop on last digit of nni (to work on smaller datasets to speed up the code)
	gen lastdigit = substr(nni,length(nni),1)
	forvalues digit = 0(1)9 {
		tempfile dads_panel_terminated_`digit'
		preserve
		keep if lastdigit=="`digit'"

	* identify job termination = same siren does not reappear in next 4 observations
	sort nni year
	by nni: gen terminated = inlist(sir,sir[_n+1],sir[_n+2],sir[_n+3],sir[_n+4])==0

		* identify characteristics of the next job
		by nni: gen next_wage = wage[_n+1] if terminated==1 // monthly wage of next job

			keep nni sir year terminated next_wage term_gemp_ficus // next_length full_exit 
			sort nni sir year terminated
			by nni sir year: keep if _n==_N
			save `dads_panel_terminated_`digit'', replace
		restore
	}
	* end of loop on first digit of nni

	* append all files
	use `dads_panel_terminated_0', clear
	forvalues digit = 1(1)9 {
		append using `dads_panel_terminated_`digit''
	}

save "output/dads_panel_terminated", replace

}


*===============================================================================
*	JOB MARKET TIGHTNESS
*===============================================================================
{

*** Job termination for all workers

	use nbheur dp sb s_brut ce sir nni debremu finremu cs2 dept apet* year using "output/dads_panel", clear 

	* full-time jobs
	gen hourperweek	= ceil(nbheur/dp*(360/52))
	gen fulltime	= ce=="C" & hourperweek>=30

	* wage
	gen wage 		= sb/dp*30 if fulltime==1 & year<2008
	replace wage	= s_brut/dp*30 if fulltime==1 & year>=2008
	
	drop nbheur dp hourperweek sb s_brut 
	* firm information
	merge m:1 sir year using "output/firm_all_var", keep(1 3) nogen keepusing(gemp1)
	rename gemp1 term_gemp_ficus

	* loop on last digit of nni (to work on smaller datasets to speed up the code)
	gen lastdigit = substr(nni,length(nni),1)
	forvalues digit = 0(1)9 {
		tempfile dads_panel_all_terminated_`digit'
		preserve
			keep if lastdigit=="`digit'"

			* identify job termination = same siren does not reappear in next 6 observations
			gen deb = year + (min(debremu,360)-1)/360
			gen fin = year + (min(finremu,360)-1)/360
			drop debremu finremu
			sort nni deb
			by nni: gen terminated = inlist(sir,sir[_n+1],sir[_n+2],sir[_n+3],sir[_n+4],sir[_n+5],sir[_n+6])==0

			* identify next full-time job, looking at the next three obs
			gen next_obs = .
			forvalues x = 1(1)3 {
				by nni: replace next_obs = `x' if terminated==1 & next_obs>`x'-1 & (deb[_n+`x']<. & deb[_n+`x']>fin) & fulltime[_n+`x']==1
			}
			by nni: gen next_wage 	= wage[_n+next_obs] // monthly wage of next full-time job

			keep nni sir year terminated wage fulltime next_wage term_gemp_ficus apet apet2 cs2 dept //  next_length 
			sort nni sir year terminated
			by nni sir year: keep if _n==_N
			save `dads_panel_all_terminated_`digit'', replace
		restore
	}
	* end of loop on first digit of nni

	* append all files
	use `dads_panel_all_terminated_0', clear
	forvalues digit = 1(1)9 {
		append using `dads_panel_all_terminated_`digit''
	}

	save "output/dads_panel_all_terminated", replace


*** Construct job loss
	use nni year sir terminated fulltime wage next_wage term_gemp_ficus cs2 dept if year>=2002 & year<=2005 using "output/dads_panel_all_terminated", clear

	* Job switch
	sort nni year
	gen swi_sir = inlist(sir,sir[_n+1],sir[_n+2],sir[_n+3],sir[_n+4],sir[_n+5],sir[_n+6])==0
	gen term = swi_sir==1 & terminated==1
	drop swi_sir terminated

	* Keep full-time high-skill jobs
	keep if fulltime==1 & wage<. & substr(cs2,1,1)=="3"

	* Job termination
	gen localjobloss_dwage 	= term==1 & next_wage<wage  
	gen localjobloss_demp	= term==1 & term_gemp_ficus<-.1
	gen LJMT				= localjobloss_dwage==1 | localjobloss_demp==1 
	
	* Collapse by occupation-departement
	rename cs2 occup
	gcollapse (mean) LJMT, by(occup dept)
	save "output/jobloss_occdep", replace
}


*===============================================================================
*	PANEL OF ALL WORKERS 
*===============================================================================
{
	
	use "output/dads_panel", clear

*** Basic cleaning 	
	* Monthly gross wage
	* NB: before 1999, s_brut is missing, after 1999, sb is more and more missing
	gen wage 		= sb if year<2008
	replace wage	= s_brut if year>=2008
	replace wage 	= wage/dp*30	// dp = number of days worked


*** Multiple jobs in a year 	

	* When worker has several jobs in same year (only 1% of obs since we have already dropped job spells shorter than 6 months), keep the one the with highest wage (to simplify data structure)
	drop if wage==.
	gen logwage = log(wage)
	gsort nni year wage dp cs2 sir
	by nni year: keep if _n==_N

*** Clean a few missing apet at the beginning 
	* If missing in t but filled in t+1 AND same firm, fill
	gsort nni -year 
	by nni: replace apet = apet[_n-1] if _n>1 & apet[_n-1]!="" & apet=="" & sir==sir[_n-1] & year<2008
		
	* Replace with apen if apet missing 
	cap replace apet = apen if apet == "" & year<2008
	
*** Define ICT sectors

	* using NAF rev.1, 2003 (1993-2008)
	gen sec4 = apet
	gen sec3 = substr(apet,1,3)
	gen sec2 = substr(apet,1,2)
	foreach x in ict ict_manuf ict_who ict_tel ict_ser {
		gen `x' = 0 if apet~="" & year>=1993
	}
	replace ict_manuf = 1 if sec3=="300" | sec4=="313Z" | inlist(sec3,"321","322","323","332","333")
	replace ict_who = 1 if inlist(sec4,"516G","518G","518J")
	replace ict_tel = 1 if sec3=="642"
	replace ict_ser = 1 if sec2=="72" | sec4=="713E"
	replace ict = ict_manuf+ict_who+ict_tel+ict_ser
	drop sec4 sec3 sec2 ict_manuf ict_who ict_tel ict_ser
	
	* use mapping with NAF rev.2, 2008 to define ICT after 2008
	* first merge on worker/firm, if worker still in same firm as in 2008
	merge m:1 sir nni using "output/ict_nni2008", keep(1 3) nogen
	replace ict = ict_nni2008 if ict==. & year>=2008
	drop ict_nni2008
	* then merge on firm, if firm was already there in 2008
	merge m:1 sir using "output/ict_sir2008", keep(1 3) nogen
	replace ict = ict_sir2008 if ict==. & year>=2008
	drop ict_sir2008
	* and finally merge on apet2
	merge m:1 apet2 using "output/ict_naf2008", keep(1 3) nogen
	replace ict = ict_naf2008 if ict==. & year>=2008
	drop ict_naf2008	

	* broad industries: NAF 2003
	capture drop sec
	gen sec = real(substr(apet,1,2)) if apet~="" & year>=1993
	gen broadind = "Agri" if sec>=1 & sec<=5
	replace broadind = "Mining" if sec>=10 & sec<=14
	replace broadind = "Manuf" if sec>=15 & sec<=37
	replace broadind = "Util" if sec>=40 & sec<=41
	replace broadind = "Construc" if sec==45
	replace broadind = "Retail" if sec>=50 & sec<=52
	replace broadind = "Hotel/Resto" if sec==55
	replace broadind = "Transport" if sec>=60 & sec<=63
	replace broadind = "Telecom" if sec==64
	replace broadind = "FIRE" if sec>=65 & sec<=70
	replace broadind = "Service" if sec>=71 & sec<=74
	replace broadind = "Public" if sec==75
	replace broadind = "Educ" if sec==80
	replace broadind = "Health" if sec==85
	replace broadind = "Soc/Cultu" if sec>=90 & sec<=93
	replace broadind = "Public" if sir=="ETAT" & broadind=="" & year>=1993
	drop sec

	* broad industries: NAF2008
	merge m:1 apet2 using "output/naf2008_to_broadind_naf2003_naf2008", keep(1 3) nogen
	replace broadind = broadind_naf2003 if broadind==""
	drop broadind_naf2003
	* fill in manually NAF2008 not matched
	replace broadind = "Service" if broadind=="" & inlist(substr(apet2,1,2),"74")
	replace broadind = "Public" if broadind=="" & inlist(substr(apet2,1,2),"84")
	replace broadind = "Educ" if broadind=="" & inlist(substr(apet2,1,2),"85")
	
	//save "output/panel_full_dads_allworkers", replace
	save "output/dads_panel_all", replace
	
}
*

*===============================================================================
*	PANEL OF ALL FULL-TIME ENTRANTS
*===============================================================================
{
	use "output/dads_panel_all", clear
	
*** Clean a few missing apet at the beginning 
	* If missing in t but filled in t+1 AND same firm, fill
	gsort nni -year 
	by nni: replace apet = apet[_n-1] if _n>1 & apet[_n-1]!="" & apet=="" & sir==sir[_n-1] & year<2008
		
	* Replace with apen if apet missing 
	cap replace apet = apen if apet == "" & year<2008

*** Clean apet variable to make sure that the naf93 codes are converted into naf2 rev1 
	replace apet="0110" if apet=="011A" 	
	replace apet="0117" if apet=="011D" 
	replace apet="0150" if apet=="013Z" 
	replace apet="271Y" if apet=="271Z" 
	replace apet="271Y" if apet=="273J" 
	replace apet="282C" if apet=="282A" 
	replace apet="282C" if apet=="282B" 
	replace apet="287Q" if apet=="287M" 
	replace apet="287Q" if apet=="287P" 
	replace apet="321C" if apet=="321B" 
	replace apet="291B" if apet=="291C" 
	replace apet="292L" if apet=="292K" 
	replace apet="295B" if apet=="295C" 
	replace apet="295R" if apet=="295P" 
	replace apet="401A" if apet=="401Z" 
	replace apet="402A" if apet=="402Z" 
	replace apet="6506" if apet=="502Z" 
	replace apet="6425" if apet=="524J" 
	replace apet="5806" if apet=="514L" 
	replace apet="5703" if apet=="513A" 
	replace apet="5560" if apet=="452V" 
	replace apet="518G" if apet=="516G" 
	replace apet="518J" if apet=="516J" 
	replace apet="518P" if apet=="516N" 
	replace apet="518A" if apet=="516A" 
	replace apet="518C" if apet=="516C" 
	replace apet="518E" if apet=="516E" 
	replace apet="518M" if apet=="516K" 
	replace apet="518N" if apet=="516L" 
	replace apet="519A" if apet=="517Z" 
	replace apet="551A" if apet=="551D" 
	replace apet="642C" if apet=="642A" 
	replace apet="642C" if apet=="642B" 
	replace apet="642C" if apet=="642B" 
	replace apet="711A" if apet=="711Z" 
	replace apet="7708" if apet=="741A" 
	replace apet="722A" if apet=="722Z" 	
	replace apet="900G" if apet=="900B" 
	replace apet="900E" if apet=="900C" 
	replace apet="922E" if apet=="922C" 
	replace apet="921D" if apet=="923D" 
	replace apet="923K" if apet=="923H" 
	replace apet="923K" if apet=="923J" 
	replace apet="930L" if apet=="926C" 
	replace apet="913A" if apet=="9722"		
	
	* Set ICT to zero if the employer is the state
	replace ict = 0 if sir=="ETAT"
	
	* Set apet if employer is the state as apet missing for some reasons 
	replace apet = "751A"  if sir=="ETAT" // Administration publique gÈnÈrale

	* Drop years before 1990
	drop if year<1991
	
	* Labor market entry year (first real job)
	gen hourperweek = ceil(nbheur/dp*(360/52))
	gen fulltime = 1 if ce=="C" & hourperweek>=30 & dp>=180
	
	gen temp 	= year if fulltime==1
	gegen yr0 = min(temp),by(nni)
	replace yr0 = . if yr0<1991 | yr0-annai>30
	drop hourperweek temp ce fulltime
	
	* Drop workers who started before 1991
	drop if yr0==.
	drop if year<yr0
	gen year0 = yr0 

*** Clean CS2 variable	
	// Backfill missing
	gsort nni -year
	by nni: replace cs2 = cs2[_n-1] if _n>1 & cs2 == ""
	
	// Replace mistakes 
	sort nni year
	by nni: replace cs2 = cs2[_n-1] if cs2[_n-1]==cs2[_n+1] & cs2 !=cs2[_n-1] & _n>1
	
	// Frontfill 
	by nni: replace cs2 = cs2[_n-1] if  _n>1 & cs2 == ""
		
	* Define cohorts
	gen coh = "pre" 		if yr0>=1994 & yr0<=1996
	replace coh = "boom" 	if yr0>=1998 & yr0<=2001
	replace coh = "post" 	if yr0>=2003 & yr0<=2005
	keep if yr0>=1994 & yr0<=2008
	
	* Worker characteristics at entry
	gen occup = cs2  
	sort nni year
	foreach var in occup ict apet dept sir{
		by nni: gen `var'0 	= `var'[1]
	}
	
	* Drop if ICT at entry not defined (civil servants and a few other missing)
	drop if ict0==.

	* Drop if labor market entry before age 20
	gen age0 = yr0-annai
	drop if age0<20
	drop annai 

	* Broad sector at entry (32-sector classification = Insee 31-sector classification in "sous-sections" where we split GA "commerce" into 51 wholesale vs. 50/52 retail)
	gen sec = real(substr(apet0,1,2)) if yr0<2008
	gen naf32 = "AA" if sec>=1 & sec<=2
	replace naf32 = "BA" if sec==5
	replace naf32 = "CA" if sec>=10 & sec<=12
	replace naf32 = "CB" if sec>=13 & sec<=14
	replace naf32 = "DA" if sec>=15 & sec<=16
	replace naf32 = "DB" if sec>=17 & sec<=18
	replace naf32 = "DC" if sec==19
	replace naf32 = "DD" if sec==20
	replace naf32 = "DE" if sec>=21 & sec<=22
	replace naf32 = "DF" if sec==23
	replace naf32 = "DG" if sec==24
	replace naf32 = "DH" if sec==25
	replace naf32 = "DI" if sec==26
	replace naf32 = "DJ" if sec>=27 & sec<=28
	replace naf32 = "DK" if sec==29
	replace naf32 = "DL" if sec>=30 & sec<=33
	replace naf32 = "DM" if sec>=34 & sec<=35
	replace naf32 = "DN" if sec>=36 & sec<=37
	replace naf32 = "EA" if sec>=40 & sec<=41
	replace naf32 = "FA" if sec==45
	replace naf32 = "GA" if sec>=50 & sec<=52
	replace naf32 = "51" if sec==51
	replace naf32 = "HA" if sec==55
	replace naf32 = "IA" if sec>=60 & sec<=64
	replace naf32 = "JA" if sec>=65 & sec<=67
	replace naf32 = "KA" if sec>=70 & sec<=74
	replace naf32 = "LA" if sec==75
	replace naf32 = "MA" if sec==80
	replace naf32 = "NA" if sec==85
	replace naf32 = "OA" if sec>=90 & sec<=93
	replace naf32 = "PA" if sec>=95 & sec<=97
	replace naf32 = "QA" if sec==99
	drop sec

*** Create consistent industry classification througout the sample period
	rename apet2 naf	// naf2008 industry classification used after 2008
	foreach d in 2 3 4 {	// construct 2-digit, 3-digit and 4-digit classifications
		//"apet": naf2003 industry classification used until 2008
		gen sec`d' = substr(apet,1,`d')
		//"apet2" = "naf": naf2008 industry classification used after 2008
		//mapping naf2008 --> naf2003: bring in variable called "ape`d'"
		merge m:1 naf using "output/naf2_naf1rev1_`d'digit", keep(1 3) nogen
		replace sec`d' = ape`d' if sec`d'==""
	}
	rename naf apet2
	
*** Job termination
	* Merge with job transition in current year
	merge 1:1 nni sir year using "output/dads_panel_terminated", keep(1 3) nogen keepusing(terminated next_wage term_gemp_ficus)  

	gen term_all 		= terminated 
	gen term_dwage 		= terminated & (next_wage<wage) 
	gen term_demp 		= terminated & (term_gemp_ficus<-.1)  
	gen term_either 	= (term_dwage==1) | (term_demp==1)
	
	drop next_wage term_gemp_ficus 
	
	*** Bring education
		merge m:1 nni using "output/dads_edp", keep(1 3) nogen keepusing(dip_tot)
		* 2e/3e sycle universitaire
		gen univM = dip_tot==7 if dip_tot<.

*** Bring initial employer information

	* rename variables on which we merge
	foreach var in sir year apet dept occup { //nic4
		rename `var' `var'_curr
		rename `var'0 `var'
	}
	
	** Capital availability 
	merge m:1 sir year using "output/gcap", keep(1 3) nogen keepusing(gcap_secdep_l1o)
	
	merge m:1 apet dept year using "output/gcap_secdep", keep(1 3) nogen keepusing(ngcap_secdep)
	
	merge m:1 apet using "output/sec_stock", keep(1 3) nogen

	** Sectoral skill average 
	merge m:1 apet using "output/sec_skill_average", keep(1 3) nogen

	** Firm balance sheet 	
	merge m:1 sir year using "output/firm_all_var", keep(1 3) nogen keepusing(S Y L Sf5 S2005  yearcrea_ficus)
	foreach var of varlist yearcrea_ficus S Y L Sf5 {
		rename `var' `var'0
	}
	
	** USA own dummy
	merge m:1 sir year using "output/lifi", keep(1 3) nogen
	rename usa usa0
	
	** rename variables on which we merge
	foreach var in sir year apet dept occup { //nic4
		rename `var' `var'0
		rename `var'_curr `var'
	}

*** Bring current employer information	

	** Firm balance sheet 	
	merge m:1 sir year using "output/firm_all_var", nogen keep(1 3) keepusing(S Y L Sf5 yearcrea_ficus resultat)
	
	merge m:1 sir using "${ree_creation}/creation", keep(1 3) nogen
	
	merge m:1 sir year using "output/firm_wagebill", keep(1 3) nogen


*** Firm characteristics (initial and current)

foreach TIME in 0 "" {
	
	* Age
	gen firmage`TIME' = year`TIME'-yearcrea_ficus`TIME'
	
	* Labor productivity
	gen YL`TIME' = (Y`TIME'/(L`TIME'+1))
	replace YL`TIME' = 0 if YL`TIME'<0
	
	* 5-year sales growth
	gen growth5yr`TIME'	= (Sf5`TIME'-S`TIME')/((Sf5`TIME'+S`TIME')*0.5)
	
	* 5-year sales growth (with extensive margin)
	gen growth5yre`TIME'= growth5yr`TIME'
	replace growth5yre`TIME' = -2 if S`TIME'<. & Sf5`TIME'==.
	replace growth5yre`TIME' = 0 if S`TIME'==0 & Sf5`TIME'==0

}

* US owned
replace usa0 = 0 if usa0==. & yr0>=1997 & yr0<=2005


*** Total earnings accounting for stock ownership

foreach var in resultat {
	* when the firm is not matched with Ficus-Fare, earnings is missing -> set to zero
	recode `var' .=0
	* monthly earnings
	replace `var'=(`var')*1000/12 // amounts in Ficus-Fare are yearly and in 1000 euros
}

* Adjustment 1: If worker is CEOs (1-digit CS = 2), add firm's earnings to the wage
* when there are multiple cs=2, add 1/N of the firm's earnings
gen earnings_ceo	= wage
replace earnings_ceo= wage + (max(resultat,0)/cs2count) if substr(cs2,1,1)=="2" & cs2count<. & cs2count>0
replace earnings_ceo= wage + max(resultat,0) if substr(cs2,1,1)=="2" & (cs2count==. | cs2count==0)
replace earnings_ceo= 11*wage if earnings_ceo>11*wage & earnings_ceo<.	// winsorize non-wage earnings at 10 times the wage to account of measurement error

* Adjustment 2: If worker is high-skill (cs=23 or 3x), adjust worker's earnings for stock options
* if the firm is 7 years old of less, attribute 1/3 of earnings to skilled workers who joined within 3 years of firm creation
* add firm's earnings in proportion to share of own wage in total skilled wage bill
merge m:1 nni sir using "output/dads_startingyear", keep(1 3) nogen 	// bring startingyear = year in which the worker started with the firm
gen share 			= (wage*dp/30)/skilledwagebill
replace share 		= 0 if share<0
replace share 		= 1 if share>1 & share<.
recode share 		.=0
gen earnings_all	= wage
replace earnings_all= wage + max(resultat,0)*share*(1/3) ///
	if (year<=yearcrea+7 & yearcrea<.) /// the firm is 7 year old or less
	& (startingyear<=yearcrea+3 & yearcrea<.) /// the worker joined within 3 years of firm creation
	& (substr(cs2,1,2)=="23" | substr(cs2,1,1)=="3") // skilled worker
replace earnings_all= 4*wage if earnings_all>4*wage & earnings_all<.	// winsorize non-wage earnings at 3 times the wage to account for maesurement error

* total earnings
foreach x in ceo all {
	gen learnings_`x' = log(earnings_`x') 
}

save "output/dads_panel_entrants", replace

}
*

*===============================================================================
* WORKING SAMPLE
*===============================================================================
{	

use if yr0>=1994 & yr0<=2005 using "output/dads_panel_entrants", clear

* Drop low skill
rename occup0 occ0
drop if real(substr(occ0,1,1))>3

* Bring different levels of naf 
gen n700 = apet0 
merge m:1 n700 using "output/naf2003_n1_5",nogen keep(1 3)

* Departement
rename dept0 dep0

* Individual FE
gegen id = group(nni)

* Specify panel
sort id year
xtset id year

* Periods
gen per = 1 if year>=1998 & year<=2001
replace per = 2 if year>=2002 & year<=2005
replace per = 3 if year>=2006 & year<=2010
replace per = 4 if year>=2011 & year<=2015

* Do some cleaning 
drop ptt debremu finremu contrat_travail entpan
	
* Main RHS: Cohort x ICT0 x periods	
forvalues t = 3(1)4 {
	gen ict0boom_`t' = ict0 * (coh=="boom") * (per==`t') if inlist(coh,"boom","post")
	gen ict0preboom_`t' = ict0 * (coh=="pre"|coh=="boom") * (per==`t') if inlist(coh,"pre","boom","post")
}
gen ict0boomwpre_2 = ict0 * (coh=="boom") * (per==2) if inlist(coh,"boom","post")

* Labels
forval t = 2/4{
	if `t'==2{
		local text = "[03--05]"
	}	
	if `t'==3{
		local text = "[06--10]"
	}
	if `t'==4{
		local text = "[11--15]"
	}
	cap label var ict0boom_`t' 		"ICT\(_{0}\)\(\times\)Boom\(\times\)`text'"
	cap label var ict0preboom_`t' 	"ICT\(_{0}\)\(\times\)Boom\(\times\)`text'"
}
label var ict0boom_3 		"\addlinespace ICT\(_{0}\)\(\times\)Boom\(\times\)[06--10]"

gen gcap = gcap_secdep_l1o if ngcap_secdep>=10
qui foreach var in gcap {
	gen_pctile_hi `var'_hi,var(`var') by(ict0 yr0)  cond(year==yr0)
}

* Sectoral overvaluation and STEM share (defined at sector level)
qui foreach var in r99 stem_sec_avg {
	gen_pctile_hi `var'_hi,var(`var') by(ict0)  cond(year==yr0)
}	
	
* Pseudo firms fixed effects
foreach TIME in 0 "" {
	foreach var in L firmage YL growth5yr {
		gquantiles quintile_`var'`TIME' = `var'`TIME', by(yr`TIME') nq(5) xtile
		replace quintile_`var'`TIME' 	= 0 if quintile_`var'`TIME'==.
	}
	gegen pseudofirm1`TIME' = group(quintile_L`TIME' quintile_firmage`TIME' quintile_YL`TIME')
	gegen pseudofirm2`TIME' = group(quintile_L`TIME' quintile_firmage`TIME' quintile_YL`TIME' quintile_growth5yr`TIME')
	foreach x in 1 2 {
		gegen pfirm`x'`TIME'yr 	= group(pseudofirm`x'`TIME' year)
	}
	drop quintile*  pseudofirm*
}

* Top quartile of initial employer's ex-post growth
cap drop temp*
gen temp = growth5yre0 if year==yr0
fasterxtile temp2 = temp, by(yr0) nq(4)
gegen temp3 = max(temp2), by(id)
gen growth_topquartile = temp3==4 if temp3<.
drop temp*

* Initial wage quintile
cap gegen wage0 	= max(wage*(year==yr0)), by(id)
cap fasterxtile w0q = wage0, by(yr0) nq(5)
cap drop wage0

* Job termination
local time 4
foreach x in all demp dwage either {
	gen temp 				= 1 if term_`x'==1 & year<=yr0+`time'-1
	gegen term_`x'_`time' 	= max(temp), by(id)
	recode term_`x'_`time' . = 0
	drop temp
}

* Fixed effects 
foreach fe in age0 sx coh yr0 occ0 ict0 dep0 broadind naf32 apet0 w0q {
	gegen `fe'yr = group(`fe' year)
} 


* Across-cohorts wage difference identified from 2003 onwards
keep if year>=2003

* Keep high skilled workers 
keep if inlist(occ0,"23","37","38")

save "output/workingsample", replace

}
*

*===============================================================================
*	CUMULATIVE EARNINGS
*===============================================================================
{
	
	* Calculate total earnings across all jobs spells at worker-year level
	use nni year sb s_brut dp if year>=1994 using "output/dads_panel", clear
	gen earnings 		= sb if year<2008
	replace earnings	= s_brut if year>=2008
	gcollapse (sum) earnings sb, by(nni year)
	save "output/earnings", replace

	* Start from panel of entrants, and add observation in gap years
	use nni year using "output/dads_panel_entrants", clear

	* number of subsequent missing years
	sort nni year
	by nni: gen b = year[_n+1] - year if _n<_N
	by nni: replace b = 2015 - year+1 if _n==_N

	* fill in gap years
	expand b
	drop b
	sort nni year
	by nni year: replace year = year[1]+_n-1

	* merge with total earnings
	merge 1:1 nni year using "output/earnings", keep(1 3) nogen
	replace earnings	= 0 if earnings ==.

	* earnings0 = no adjustment
	gen earnings0 = earnings

	* earnings1: add UB=60% of previous income for 1 year
	sort nni year
	gen earnings1 = earnings
		by nni : replace earnings1 = earnings[_n-1]*0.6 if earnings1==0 & _n>1

	* earnings2 = add UB=30% of previous income for 1 year
	gen earnings2 = earnings
		by nni : replace earnings2 = earnings[_n-1]*0.3 if earnings2==0 & _n>1
	
	* earnings2 = add UB=60% of previous income for 1 year + for 2nd year if previous job spell is at least 2 years
	gen earnings3 = earnings
		by nni : replace earnings3 = earnings[_n-1]*0.6 if earnings3==0 & _n>1
		by nni : replace earnings3 = earnings[_n-2]*0.6 if earnings3==0 & _n>3 & earnings[_n-3]>0

	* calculate discounted sum
	sort nni year
	foreach x in 0 1 2 3 {
		by nni: gen pv`x' 			= earnings`x' if _n==1 
		by nni: replace pv`x' 		= pv`x'[_n-1] + earnings`x'/1.05^(year-year[1]) if _n>1
	}
	keep nni year pv* sb* earnings*
	save "output/cumulative_earnings", replace

	erase "output/earnings.dta"

}


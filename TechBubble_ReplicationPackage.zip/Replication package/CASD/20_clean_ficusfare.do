
* This code starts from FICUS-FARE files in SAS format, select variables, do some cleaning, and save data in Stata format.

cd "${dir}"


/*------------------------------------------------------------------------------

Select variables, do some cleaning, and save one file per year

------------------------------------------------------------------------------*/
{

* create directory to store cleaned data
// cd "${dir}/rawdata/ficus_fare"
// capture mkdir cleaned


***	FICUS 1994-2007
	
forvalues t = 1994(1)2007 {
	
// 	local t = 2002 
	* list of variables selected
	global X datcr siren ape dep com resubic resubnc dividen disponi empdet avancou detfou pravanc autdett ///
	subvinv typimpo ctdx catotal achamar saltrai charsoc immoinc immocor ///
	tactint effsalm vabcf ebe invcorp bfdr autcapi prodsto prodimm varstma achampr varstmp autacha ///
	stocmar orbil cj avanver chavanc creacli autregu autcrea tactibr valmobi ///
	stocmpp capisoc autfond impoben pbcai invavap amimcor immofin tamimmo dotamor ctcx
	
	* Append yearly files
	use $X using "${dir}/rawdata/raw/ficus_fare/ficus_`t'", clear
	
	* drop missing siren
	drop if inlist(siren,"",".","0","000000000")
	
	* keep 1 obs per siren
	gsort siren catotal
	by siren: keep if _n==_N 
	
	* Rename some variables
	gen resultat 		= resubic 
	replace resultat 	= resubnc if resultat==0	
	rename ctdx duree_ex 
	ren ctcx date_cloture
	ren cj stat_cj
	ren avanver avances
	ren chavanc chg_avances
	ren creacli creances_cli
	ren autregu regu
	ren autcrea aut_crea
	rename tactibr tot_act
	ren disponi cash
	ren valmobi val_mob
	ren autfond osfd
	rename subvinv sub_inv 
	ren empdet empr_dettes
	ren catotal ca
	ren effsalm emp
	ren saltrai wages
	ren impoben imp_ben
	ren pbcai sales_bef_tax
	ren dividen div
	ren invavap inv_corp_incor_ap
	ren invcorp inv_corp_b_ha
	ren amimcor inv_corp_incor_am
	rename dotamor dot_amort 
	rename detfou cred
	capture gen ocli=pravanc+autdett 	
	rename vabcf va	
	rename achampr achamatprem
	
	* Adjust year of creation
	cap tostring datcr,replace
	gen yrcrea	= substr(datcr,1,4)
	destring yrcrea,replace force
	gen stock = stocmpp+stocmar
	
	* Commune
	drop if dep=="99" // missing
	cap tostring com,replace 
	cap replace com = "" if com == "."
	cap replace com = substr("00"+com,-3,.)
	gen commune	= substr(dep,1,2)+com
	
	* Save
	gen year	= `t'	
	save "${ficus_fare}/ficus-fare`t'",replace

}


***	FARE 2008
{

use siren ape_08 eff_etp_08 eff_3112_08 datcr_08 orbil_08 dep_08 com_08 resulta_08 dividen_08 cj_08 ctdx_08 ctcx_08 dotamor_08 impoben_08 amimcor_08 amimfin_08 amiminc_08 typimpo_08 catotal_08 saltrai_08 charsoc_08 immoinc_08 immocor_08 immofin_08 effsalm_08 vabcf_08 ebe_08 autacha_08 achamar_08 achampr_08 autchex_08 r502_08 resexploit_08 using "${dir}/rawdata/raw/ficus_fare/fare2008", clear

rename (*_08) (*)
tostring ctdx,replace
	cap tostring siren,replace 
	cap replace siren = substr("000000000"+siren,-9,.)

	drop if inlist(siren,"",".","0","000000000")
	sort siren catotal
	by siren: keep if _n==_N 
	* Prepare commune code for merge with bassin d'emploi
	drop if dep=="99" // missing
	gen commune	= com

* Rename 
	rename achampr achamatprem
	rename resulta resultat
    ren effsalm emp
    ren catotal ca
    ren ctcx date_cloture
    ren autchex aut_char_expl
    ren cj stat_cj
    ren ctdx duree_ex
    ren dividen div
    ren impoben  imp_ben
    ren saltrai wages
    ren typimpo rif
    ren r502 cotis_exploi
    ren resexploit res_exploi
	rename vabcf va
	
*** Adjust year of creation
	cap tostring datcr,replace 
	gen yrcrea	= substr(datcr,1,4)
	destring yrcrea, replace force
	gen year	= 2008	
	
save "${ficus_fare}/ficus-fare2008", replace

}


***	FARE 2009-2015

forvalues t = 2009(1)2015 {
	
if `t'>=2009&`t'<=2010{
	use ent_cre_daaaammjj siren ape* b182 b341 redi_r222 redi_r213 redi_r005 depcom redi_r210 ///
	redi_r211 redi_r212 stat_cj autcapi capisoc r006 b181 b182 b302 b319 b330 b604 ///
	ap_immo_tot ap_immo_corp ap_immo_fin ap_immo_inc ///
	invavap inv_corp_b_ha inv_corp inv_brut inv_incorp immo_fin immo_inc immo_corp immo_tot r206 ///
	redi_r216 redi_r217 redi_r403 redi_r402 redi_r401 b100 ///
	redi_r218 redi_r223 redi_r005 redi_r101 redi_r103 redi_r201 redi_e200 redi_e001 stat_etat ///
	liasse_source reserves redi_r502 redi_r310 d333 redi_r214 ///
	i009 b173 stocks_tot b171 b190 b172 autregu b001 b002 pravanc b348 b342 ///
	redi_r503 redi_r504 r004 b300 b202 b203 b303 b320 actinet_tot b342 b348 using "${dir}/rawdata/raw/ficus_fare/fare`t'", clear 
// 	lowercase *
}
if `t'>=2011& `t'<=2012{
	use ent_cre_daaaammjj siren ape* b182 b341 redi_r222 redi_r213 redi_r005 depcom redi_r210 ///
	redi_r211 redi_r212 stat_cj autcapi capisoc r006 b181 b182 b302 b319 b330 b604 ///
	ap_immo_tot ap_immo_corp ap_immo_fin ap_immo_inc ///
	invavap inv_corp_b_ha inv_corp inv_brut inv_incorp immo_fin immo_inc immo_corp immo_tot r206 ///
	redi_r216 redi_r217 redi_r403 redi_r402 redi_r401 b100 ///
	redi_r218 redi_r223 redi_r005 ///
	redi_r101 redi_r103 redi_r201 redi_e200 redi_e001 stat_etat ///
	liasse_source reserves redi_r502 redi_r310 d333 redi_r214 ///
	i009 b173 stocks_tot b171 b190 b172 autregu b001 b002 pravanc b348 b342 ///
	redi_r503 redi_r504 r004 b300 b202 b203 b303 b320 actinet_tot b342 b348 rif b301 using "${dir}/rawdata/raw/ficus_fare/fare`t'", clear 
// 	lowercase *
}
if `t'>=2013 & `t'<=2016 | `t'>=2018{
	use ent_cre_daaaammjj siren ape* b182 b341  ///
	redi_r222 redi_r213 redi_r005 depcom redi_r210 ///
	redi_r211 redi_r212 ///
	stat_cj autcapi capisoc b181 b182 b302 b319 b330 b604 ///
	ap_immo_tot ap_immo_corp ap_immo_fin ap_immo_inc ///
	invavap inv_corp_b_ha inv_corp inv_brut inv_incorp immo_fin immo_inc immo_corp immo_tot r206 ///
	redi_r216 redi_r217 redi_r403 redi_r402 redi_r401 b100 ///
	redi_r218 redi_r223 redi_r005 ///
	redi_r101 redi_r103 redi_r201 redi_e200 redi_e001 stat_etat ///
	liasse_source reserves redi_r502 redi_r310 d333 redi_r214 ///
	i009 b173 stocks_tot b171 b190 b172 autregu b001 b002 pravanc b348 b342 ///
	redi_r503 redi_r504 r004 b300 b202 b203 b303 b320 actinet_tot b342 b348 rif b301 ///
	diff_ul diff_ep using "${dir}/rawdata/raw/ficus_fare/fare`t'", clear 
// 	lowercase *
	cap tostring siren,replace 
	cap replace siren = substr("000000000"+siren,-9,.)
	drop if substr(siren,1,1)=="P"
}
if `t'==2017{ // there is a bug in the 2017 file, redi_001 is supposed to exist according to documentation but is not present in the data
	use ent_cre_daaaammjj siren ape* b182 b341  ///
	redi_r222 redi_r213 redi_r005 depcom redi_r210 ///
	redi_r211 redi_r212 ///
	stat_cj autcapi capisoc b181 b182 b302 b319 b330 b604 ///
	ap_immo_tot ap_immo_corp ap_immo_fin ap_immo_inc ///
	invavap inv_corp_b_ha inv_corp inv_brut inv_incorp immo_fin immo_inc immo_corp immo_tot r206 ///
	redi_r216 redi_r217 redi_r403 redi_r402 redi_r401 b100 ///
	redi_r218 redi_r223 redi_r005 ///
	redi_r101 redi_r103 redi_r201 redi_e200 stat_etat ///
	liasse_source reserves redi_r502 redi_r310 d333 redi_r214 ///
	i009 b173 stocks_tot b171 b190 b172 autregu b001 b002 pravanc b348 b342 ///
	redi_r503 redi_r504 r004 b300 b202 b203 b303 b320 actinet_tot b342 b348 rif b301 ///
	diff_ul diff_ep using "${dir}/rawdata/raw/ficus_fare/fare`t'", clear 
// 	lowercase *
	drop if substr(siren,1,1)=="P"
}
	cap tostring siren,replace 
	cap replace siren = substr("000000000"+siren,-9,.)

	drop if inlist(siren,"",".","0","000000000")
	sort siren redi_r310
	by siren: keep if _n==_N 

*** Rename variables 
	rename ape_rep ape
	rename b319 resultat
	rename b300 tot_liab
	rename b341 avancou
	rename b342 detfou
	rename b348 autdett
	rename r004 vabcf
	rename b182 disponi
	rename b604 dividen

	rename redi_r005 ebe
	rename redi_r310 catotal
	rename redi_r210 achamar
	rename redi_r212 achamatprem 
	rename redi_r211 varstma
	rename redi_r213 varstmp
	
	rename redi_r214 autacha
	rename redi_r222 autchex
	rename redi_r216 saltrai
	rename redi_r217 charsoc
	rename b100 tactibr
	cap rename redi_e001 effsalm

	* rename immobilisation and amortissement
	rename immo_tot		tamimmo 
	rename immo_corp 	immocor 
	rename immo_fin 	immofin
	rename immo_inc  	immoinc

	rename ap_immo_corp amimcor 
	rename ap_immo_fin amimfin
	rename ap_immo_inc amiminc 

	rename ent_cre_daaaammjj datcr 

	rename r206 imp_ben
	rename dividen div
	rename saltrai wages
	rename redi_r403 sales_serv
	rename redi_r401 sales_march
	rename redi_r402 sales_goods
	rename catotal ca 
	rename redi_e200 empl_etp
	cap rename effsalm emp
	capture rename r006 sales_bef_tax
	rename d333 external_costs_loc 
	rename redi_r502 cot_dirigeant
	rename redi_r201 tot_char_expl
	rename stocks_tot stock
	rename b171 avances
	rename b172 creances_cli
	rename b173 aut_crea
	rename b181 val_mob 
	rename disponi cash 
	rename b190 chg_avances
	rename autregu regu
	rename tactibr tot_act
	rename b001 wkca
	rename b002 wca
	rename actinet_tot tot_act_net
	capture rename b301 shfd
	rename b302 osfd
	rename b330 empr_dettes
	rename detfou cred
	capture gen ocli=pravanc+autdett 
	rename b320 sub_inv
	rename b303 prov_risk
	rename b202 amort_imm_tot
	rename b203 amort_circ_tot
	rename invavap inv_corp_incor_ap
	rename i009 inv_corp_net
	rename inv_corp inv_corp_brut
	rename inv_incorp inv_incorp_brut
	rename redi_r218 dot_amort
	rename redi_r223 dot_prov
	rename redi_r101 res_exploi
	rename redi_r103 res_av_impot
	
	rename vabcf va	
*** Adjust year of creation
	cap tostring datcr,replace 
	gen yrcrea	= substr(datcr,1,4)
	destring yrcrea,replace force
	
*** Commune code	
	gen dep=substr(depcom,1,2)
	drop if dep=="99" // missing
	rename depcom commune
	
gen year	= `t'	
	
save "${ficus_fare}/ficus-fare`t'",replace
}

}


/*------------------------------------------------------------------------------

Clean folder raw data for ficus-fare 

------------------------------------------------------------------------------*/

forvalues t = 1994(1)2006{
	erase "${dir}/rawdata/raw/ficus_fare/ficus_`t'.dta"
}

forvalues t = 2008(1)2015 {
	if `t'!=2009{
		erase "${dir}/rawdata/raw/ficus_fare/fare`t'.dta"
	}
}


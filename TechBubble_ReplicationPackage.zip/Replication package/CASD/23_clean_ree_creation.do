
*===============================================================================
* CREATE UNIQUE STATA FILE
*===============================================================================

* Append all years
clear
gen year = .
forvalues year = 1993(1)2015 {
	local n0 = _N
	append using "${dir}/rawdata/raw/ree_creation/ree_creation`year'"
	replace year = `year' in `=`n0'+1'/L
}

* Keep 1 observation per siren
gegen yearcrea = min(year),by(siren)
bys siren: keep if _n==1

* Legal status
rename cj cj_sine

* Industry
rename apen sec_sine

* Save
rename siren sir
keep sir yearcrea cj_sine sec_sine
save "${ree_creation}/creation", replace


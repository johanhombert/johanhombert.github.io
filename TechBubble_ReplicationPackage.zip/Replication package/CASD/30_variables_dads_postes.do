
cd "${dir}"



*===============================================================================
* SECTOR-DEPARTMENT LEVEL EMPLOYMENT
*===============================================================================
{

* Append all years and collapse once
clear
gen year = .
forvalues t = 1998(1)2001 {
	local n0 = _N
	append using "rawdata/cleaned/dads_postes/dads_postes_`t'", keep(dep apet nbheur)
	replace year = `t' in `=`n0'+1'/L
}
gen L = max(0,min(nbheur/2000,1))	// full-time equivalent
gcollapse (sum) L, by(dep apet year)
save "output/L", replace

}
*

*===============================================================================
* SKILL SHARE
*===============================================================================
{

* Create annual files
forvalues t = 1997(1)2001 {
	di "*** `t' ***"
	use cs2 apet dep nbheur using "rawdata/cleaned/dads_postes/dads_postes_`t'", clear
	rename dep dept
	drop if cs2=="00" | cs2==""
	gen n = 1	// all
	gen nnost = cs2=="37" // non-stem
	gen nstem = cs2=="38" // stem
	* full-time equivalent
	foreach var in n nstem nnost {
		replace `var' =  `var' * max(0,min(nbheur/2000,1))
	}
	* collapse at sector-geography level
	preserve
	gcollapse (sum) n nstem nnost, by(apet dept)
	gen stem_secdep = nstem/(nstem+nnost)
	save "output/secdep_skill_`t'", replace
	restore
	* collapse at sector level
	preserve
	gcollapse (sum) n nstem nnost, by(apet)
	gen stem_sec = nstem/(nstem+nnost)
	save "output/sec_skill_`t'", replace
	restore
}

* Merge all years
clear
gen year = .
forvalues t = 1997(1)2001 {
	local n0 = _N
	append using "output/sec_skill_`t'"
	replace year = `t' in `=`n0'+1'/L
}
tempfile sec_skill_panel
save `sec_skill_panel', replace

* fill in gap years
reshape wide n nstem nnost stem_sec, i(apet) j(year)
foreach var in n nstem nnost {
	forvalues t = 1997(1)2001 {
		replace `var'`t' = 0 if `var'`t'==.
	}
}
reshape long n nstem nnost stem_sec, i(apet) j(year)
* employment growth rates
gegen apet_num = group(apet)
gsort apet_num year
xtset apet_num year
foreach var in n nstem nnost {
	replace `var' = 0 if `var'==.
	gen w`var' = .5*(`var'+L.`var')
	gen g`var' = (`var'-L.`var')/(.5*(`var'+L.`var'))
}
* time-average stem share by sector
keep if year>=1998 & year<=2001
drop apet_num
gcollapse (mean) stem_sec_avg=stem_sec, by(apet)
save "output/sec_skill_average", replace

* At sector level
use `sec_skill_panel', clear
* save
keep apet year stem_sec
save "output/sec_skill", replace

* At sector x department level
clear
gen year = .
forvalues t = 1997(1)2001 {
	local n0 = _N
	append using "output/secdep_skill_`t'"
	replace year = `t' in `=`n0'+1'/L
}
* save
keep apet dept year stem_secdep
save "output/secdep_skill", replace

* Erase annual files
forvalues t = 1997(1)2001 {
	erase "output/sec_skill_`t'.dta"
	erase "output/secdep_skill_`t'.dta"
}


*** Skilled wage bill & number of CEOs at firm-year level: 1994-2015

* Build one firm-year panel directly (avoid yearly temp files)
clear
gen year = .
forvalues t = 1994(1)2015 {
	local n0 = _N
	append using "rawdata/cleaned/dads_postes/dads_postes_`t'", keep(sir cs2 brut)
	replace year = `t' in `=`n0'+1'/L
}
* number of workers with occupation "pcs=2" ("CEOs")
gen cs2count = substr(cs2,1,1)=="2"
* total wage bill for skilled workers
gen skilledwagebill = brut if cs2=="23" | substr(cs2,1,1)=="3"
* collapse at firm-year level
gcollapse (sum) cs2count skilledwagebill, by(sir year)
save "output/firm_wagebill", replace


}
*

*===============================================================================
* Local labor market (departement x naf4)
*===============================================================================
{

	* append Ficus-Fare files
	clear
	gen year = .
	forvalues t = 2001(1)2007 {
		local n0 = _N
		append using "${ficus_fare}/ficus-fare`t'", keep(siren dep ape)  
		replace year = `t' in `=`n0'+1'/L
	}

	* remove leading and trailing 0 in departement
	replace dep = substr(dep,1,2) if length(dep)==3 & substr(dep,3,1)=="0"
	replace dep = substr(dep,2,3) if length(dep)==3 & substr(dep,1,1)=="0"

	* assign initial value 
	sort siren year 
	bys siren: gen dep0 = dep[1] 
	bys siren: gen ape0 = ape[1] 
	keep siren dep0 ape0 
	rename siren sir 
	gegen llm  = group(dep0 ape0)
	keep sir llm
	gduplicates drop sir, force
	save "output/sir_llm",replace
}
*

*===============================================================================
* Changes in age pyramid after bubble collapse
*===============================================================================
{
*-------------------------------------------------------------------------------
* Firm STEM employment 
*-------------------------------------------------------------------------------

foreach t in 2003 2008 {
	
	use sir cs2 age nbheur using "rawdata/cleaned/dads_postes/dads_postes_`t'" if inlist(cs2,"38") , clear
	
	* Filters
	* drop if missing variables
	drop if age==. | nbheur==.
	replace nbheur = max(0,min(nbheur/2000,1))
	
	* Young
	gen age30 = age<=30

	* # hours 
	gen h_stem_30 = age30*nbheur
	
	* Median age weighted by hours 
	preserve 
		gcollapse(median) h_Medage_`t' = age [aw=nbheur],by(sir)
		tempfile temp 
		save `temp'
	restore 
	
	* Sum number of hours 
	gcollapse(sum) h_stem*,by(sir)
	merge 1:1 sir using `temp',nogen 	
	gen year = `t'
	save "output/employment_age_`t'", replace
	
}
*

*-------------------------------------------------------------------------------
* Changes at llm level 
*-------------------------------------------------------------------------------
{

global Beg 	"2003"

*** Firm level employment growth post bubble
	* Append annual files
	clear
	gen year = .
	foreach t in 2003 2008  {
		append using "output/employment_age_`t'"
	}

	*** Construct measures of change in age pyramid 
	foreach t in $years_demog {
		** Employment levels used to construct employment growth
		qui gegen h_L_age30_`t' = max(h_stem_30*(year==`t')),by(sir)
	}
	gcollapse (mean) *_age* *Medage_*, by(sir)

*** Employment growth for young workers 
	keep h_* sir 
	* Log growth 
	local end 2008 
	gen dlog_h_age30_${Beg}`end' = log(h_L_age30_`end'/h_L_age30_${Beg}) ///
		if h_L_age30_${Beg}>0 & h_L_age30_`end'>0
	
	* Change in median age 
	gen dMedageh_${Beg}2008 = h_Medage_2008 - h_Medage_${Beg}				

	drop h_*
		
*** Average at the llm level  	
	merge m:1 sir using "output/sir_llm", keep(3) nogen keepusing(llm)
	gcollapse(mean) dlog* dM*age* ,by(llm) 
	save "output/employment_age_h_llm", replace
	
*** Erase annual files
	foreach t in 2003 2008  {
		erase "output/employment_age_`t'.dta"
	}

}
*
}
*

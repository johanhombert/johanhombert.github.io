
* Install packages

foreach pkg in ftools gtools moremata estout reghdfe xtqreg ppmlhdfe winsor2 {
	ssc install `pkg', replace
}

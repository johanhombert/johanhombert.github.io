


/*===============================================================================
    Specify the project and path 
===============================================================================*/

%let project = TechBoom_replicationPackage ;
%let rawdatadir = \\casd.fr\casdfs\Projets\FISCENT\Data;
%let inpath= \\casd.fr\casdfs\Projets\FISCENT\Data;
%let outdir = C:\Users\Public\Documents\&project.\rawdata\raw\ficus_fare;

/*===============================================================================
/* Macro to transform upper case in lower case (important for dta export) 
===============================================================================*/

%macro lower_vars(lib=WORK, data=mydata);
    proc sql noprint;
        select cats(name,'=',lower(name))
        into : renlist separated by ' '
        from dictionary.columns
        where libname = upcase("&lib")
        and memname = upcase("&data")
        and name ne lowcase(name);
    quit;
    %if %length(&renlist) %then %do;
        proc datasets lib=&lib nolist;
            modify &data;
            rename &renlist;
        quit;
    %end;
%mend;

/*===============================================================================
    FICUS
===============================================================================*/

%macro ficus(fyear=, lyear=, outdir=);
    %local year yr2;

    %do year = &fyear %to &lyear;
        %let yr2 = %substr(&year, 3, 2);

		data _null_;
		put "NOTE: Year=&year YR2=&yr2";
		run;

		/* Handle the fact that path changes over years */
		%if (&year >= 1994 & &year<=2000) %then %do;
			libname ficus&yr2 "&rawdatadir.\Statistique annuelle d'entreprise_FICUS_&year\Fichiers en euros";
		%end;
		%else %if (&year >= 2001 & &year<=2004) %then %do;
			libname ficus&yr2 "&rawdatadir.\Statistique annuelle d'entreprise_FICUS_&year\Fichiers avec les unit�s l�gales";
		%end;
		%else %if (&year >= 2005 & &year<=2007) %then %do;
			libname ficus&yr2 "&rawdatadir.\Statistique annuelle d'entreprise_FICUS_&year\Fichiers avec les unit�s consolid�es et les unit�s l�gales hors contours des profilages";
		%end;

		/* Load raw data and append apu, fin and tab */
		data mydata;
		set ficus&yr2..apu ficus&yr2..fin ficus&yr2..tab ;
		run;
		
		/* Macro to rename upper case to lower case */
		%lower_vars(lib=work, data=mydata);

		/* Export in dta */ 
		proc export data=mydata outfile="&outdir.\ficus_&year..dta" replace;
		run;

		/* Clean memory */
		proc datasets lib=work nolist;
			delete mydata collapsed;
		quit;

    %end;
%mend;

%ficus(fyear=1994, lyear=2007, outdir=&outdir);

/*===============================================================================
    FARE
===============================================================================*/

%macro fare(fyear=, lyear=, outdir=);
    %local year mem;

    %do year = &fyear %to &lyear;

		%put NOTE: Processing FARE year=&year;

		/* Handle the fact that raw data has different names over years */
		%if (&year = 2008 or &year = 2009) %then %do;
			%let mem = tab;
		%end;
		%else %if (&year = 2010 or &year = 2011) %then %do;
			%let mem = fare&year;
		%end;
		%else %if (&year = 2012) %then %do;
			%let mem = fare&year._meth&year;
		%end;
		%else %do;
			%let mem = fare&year.meth&year;
		%end;

		/* Load raw data - keeping ALL variables */
		data mydata;
			set "&rawdatadir.\Statistique annuelle d'entreprise_FARE_&year.\&mem..sas7bdat";
		run;

		/* Macro to rename upper case to lower case */
		%lower_vars(lib=work, data=mydata);

		/* Export in dta */
		proc export data=mydata outfile="&outdir.\fare&year..dta" replace;
		run;

		/* Clean memory */
		proc datasets lib=work nolist;
			delete mydata;
		quit;


    %end;
%mend;

%fare(fyear=2008, lyear=2017, outdir=&outdir);











/*===============================================================================
    Specify the project and path 
===============================================================================*/

%let project = TechBoom_replicationPackage ;
%let rawdatadir = \\casd.fr\casdfs\Projets\FISCENT\Data;
%let outdir_panel = C:\Users\Public\Documents\&project.\rawdata\raw\dads_panel;
%let outdir_postes = C:\Users\Public\Documents\&project.\rawdata\raw\dads_postes;

/*===============================================================================
/* Macro to transform upper case in lower case (important for dta export) 
===============================================================================*/

%macro lower_vars(lib=WORK, data=mydata);
    proc sql noprint;
        select cats(name,'=',lower(name))
        into : renlist separated by ' '
        from dictionary.columns
        where libname = upcase("&lib")
        and memname = upcase("&data")
        and name ne lowcase(name);
    quit;
    %if %length(&renlist) %then %do;
        proc datasets lib=&lib nolist;
            modify &data;
            rename &renlist;
        quit;
    %end;
%mend;


/*===============================================================================
    DADS POSTES
===============================================================================*/

/* Main macro for all years */
%macro extract_dads_postes(listyears, listreg, outdir);
    %local i j year yr2 reg keepvars regbase filtcond;
    %let i = 1;
    %do %while(%length(%scan(&listyears, &i)));
        %let year = %scan(&listyears, &i);
        %let yr2 = %substr(&year, 3, 2);

        %let j = 1;
        %do %while(%length(%scan(&listreg, &j)));
            %let reg = %scan(&listreg, &j);

            %put NOTE: DADS Postes YEAR=&year YR2=&yr2 REG=&reg;

            /* Derive region filter:                                         */
            /*   Take first 2 chars of &reg (11aa->11, 82a->82, 21->21)     */
            /*   1994-2001: filter on reg  |  2002+: filter on regt          */
            %let regbase = %substr(&reg, 1, 2);
            %if &year <= 2001 %then %let filtcond = strip(reg) = "&regbase";
            %else %let filtcond = strip(regt) = "&regbase";

            /* Set variables based on year */
            %if &year = 1994 %then %let keepvars = siren duree duree_1 nic reg dep com cs2 nbheur brut brut_1 cipdz apet age;
            %else %if &year >= 1995 and &year <= 2001 %then %let keepvars = siren duree duree_1 nic reg dep com cs2 nbheur brut brut_1 cipdz apet apet_1 age;
			 %else %if &year >= 2002 and &year <= 2007 %then %let keepvars = siren ident_s  duree duree_1 nic regt dept cs pcs nbheur  s_brut s_brut_1 cpfd apet apet_1 age;
            %else %if &year = 2008 %then %let keepvars = siren ident_s duree duree_1 nic regt dept cs pcs nbheur s_brut s_brut_1 cpfd apet apet_1 age;
            %else %let keepvars = siren ident_s duree duree_1 nic regt dept pcs pcs_1 nbheur s_brut s_brut_1 cpfd apet apet_1 age;

            /* Set path and file name based on year, apply region filter */
            %if &year <= 2008 %then %do;
                data mydata;
                    set "&rawdatadir.\DADS_DADS Postes_&year.\post&reg.&yr2..sas7bdat"
                    (keep = &keepvars where = (&filtcond));
                run;
            %end;
            %else %if &year >= 2009 and &year <= 2013 %then %do;
                data mydata;
                    set "&rawdatadir.\DADS_DADS Postes_&year.\post&reg..sas7bdat"
                    (keep = &keepvars where = (&filtcond));
                run;
            %end;
            %else %do;
                data mydata;
                    set "&rawdatadir.\DADS_DADS Postes_&year.\R�gions\post&reg..sas7bdat"
                    (keep = &keepvars where = (&filtcond));
                run;
            %end;

            %lower_vars(lib=work, data=mydata);

            proc export data=mydata outfile="&outdir.\dads_postes_&year._&reg..dta" replace;
            run;

            proc datasets lib=work nolist;
                delete mydata;
            quit;

            %let j = %eval(&j + 1);
        %end;
        %let i = %eval(&i + 1);
    %end;
%mend;

/* Wrapper macro using fyear/lyear for contiguous year ranges */
%macro extract_dads_postes_range(fyear=, lyear=, listreg=, outdir=);
    %local yr listyears;
    %let listyears =;
    %do yr = &fyear %to &lyear;
        %let listyears = &listyears &yr;
    %end;
    %extract_dads_postes(&listyears, &listreg, &outdir);
%mend;

/* Macro special for IDF 2012-2013 */
%macro extract_dads_idf1213(listyears, listreg, outdir);
    %local i j year reg;
    %let i = 1;
    %do %while(%length(%scan(&listyears, &i)));
        %let year = %scan(&listyears, &i);

        %let j = 1;
        %do %while(%length(%scan(&listreg, &j)));
            %let reg = %scan(&listreg, &j);

            %put NOTE: DADS Postes IDF1213 YEAR=&year REG=&reg;

            data mydata;
                set "&rawdatadir.\DADS_DADS Postes_&year.\Ile de France\post&reg..sas7bdat"
                (keep = siren ident_s duree duree_1 nic regt dept pcs pcs_1 nbheur s_brut s_brut_1 cpfd apet apet_1 age
                 where = (strip(regt) = "11"));
            run;

            %lower_vars(lib=work, data=mydata);

            proc export data=mydata outfile="&outdir_postes.\dads_postes_&year._&reg.idf.dta" replace;
            run;

            proc datasets lib=work nolist;
                delete mydata;
            quit;

            %let j = %eval(&j + 1);
        %end;
        %let i = %eval(&i + 1);
    %end;
%mend;

/* Macro special for IDF 2014-2015 */
%macro extract_dads_idf1415(listyears, listreg, outdir);
    %local i j year reg;
    %let i = 1;
    %do %while(%length(%scan(&listyears, &i)));
        %let year = %scan(&listyears, &i);

        %let j = 1;
        %do %while(%length(%scan(&listreg, &j)));
            %let reg = %scan(&listreg, &j);

            %put NOTE: DADS Postes IDF1415 YEAR=&year REG=&reg;

            data mydata;
                set "&rawdatadir.\DADS_DADS Postes_&year.\D�partements\post&reg..sas7bdat"
                (keep = siren ident_s duree duree_1 nic regt dept pcs pcs_1 nbheur s_brut s_brut_1 cpfd apet apet_1 age
                 where = (strip(regt) = "11"));
            run;

            %lower_vars(lib=work, data=mydata);

            proc export data=mydata outfile="&outdir_postes.\dads_postes_&year._&reg.idf.dta" replace;
            run;

            proc datasets lib=work nolist;
                delete mydata;
            quit;

            %let j = %eval(&j + 1);
        %end;
        %let i = %eval(&i + 1);
    %end;
%mend;

/*################################################################### */
/* RUN DADS POSTES */
/*################################################################### */


/* 1994-2007: All old regions (contiguous range -> use fyear/lyear) */
%let listreg = 11 21 22 23 24 25 26 31 41 42 43 52 53 54 72 73 74 82 83 91 93 94 97 99;
%extract_dads_postes_range(fyear=1994, lyear=2007, listreg=&listreg, outdir=&outdir_postes);


/* 2008: All old regions */
%let listyears = 2008;
%let listreg = 11 21 22 23 24 25 26 31 41 42 43 52 53 54 72 73 74 82 83 91 93 94 97 99;
%extract_dads_postes(&listyears, &listreg, &outdir_postes);

/* 2009-2013: Old regions except IDF and region 82 */
%let listyears = 2009 2010 2011 2012 2013 ;
%let listreg = 21 22 23 24 25 26 31 41 42 43 52 53 54 72 73 74 83 91 93 94 97 99;
%extract_dads_postes(&listyears, &listreg, &outdir_postes);



/* 2010: Region 82 split */
%let listyears = 2010;
%let listreg = 82a 82b;
%extract_dads_postes(&listyears, &listreg, &outdir_postes);

/* 2009 2011-2013: Region 82 normal */
%let listyears = 2009  2011 2012 2013;
%let listreg = 82;
%extract_dads_postes(&listyears, &listreg, &outdir_postes);

/* 2014-2015: New regions except IDF */
%let listyears = 2014 2015;
%let listreg = 24 27 28 32 44 52 53 75 76 84 93 94 97 99;
%extract_dads_postes(&listyears, &listreg, &outdir_postes);

/*################################################################### */
/* ILE-DE-FRANCE */
/*################################################################### */

/* 2009-2010: IDF format aa bb cc dd */
%let listyears = 2009 2010;
%let listreg = 11aa 11bb 11cc 11dd;
%extract_dads_postes(&listyears, &listreg, &outdir_postes);

/* 2011: IDF format normal */
%let listyears = 2011;
%let listreg = 11;
%extract_dads_postes(&listyears, &listreg, &outdir_postes);

/* 2012-2013: IDF départements */
%let listyears = 2012 2013;
%let listreg = 75 77 78 91 92 93 94 95;
%extract_dads_idf1213(&listyears, &listreg, &outdir_postes);

/* 2014-2015: IDF départements */
%let listyears = 2014 2015;
%let listreg = 75 77 78 91 92 93 94 95;
%extract_dads_idf1415(&listyears, &listreg, &outdir_postes);

/*===============================================================================
    DADS PANEL
===============================================================================*/

%macro extract_dads_panel(year, listfiles, outdir);
    %local i file yearrange;
    %let i = 1;
    %do %while(%length(%scan(&listfiles, &i)));
        %let file = %scan(&listfiles, &i);
        %let yearrange = %scan(&file, 2, _);

        %put NOTE: DADS Panel year=&year file=&file yearrange=&yearrange;

        data mydata;
            set "&rawdatadir.\DADS_Panel tous salari�s_&year.\&file..sas7bdat"
            (keep = nic4 an nninouv nnihc nnifict entpan sx annai sir dept comt
                    apet apet2 cs2 pcs4 debremu finremu dp sb sn s_brut netnet
                    nbheur ce contrat_travail entsir pan25 ptt sect);
        run;

        %lower_vars(lib=work, data=mydata);

        proc export data=mydata outfile="&outdir_panel.\dads_panel_&year._&yearrange..dta" replace;
        run;

        proc datasets lib=work nolist;
            delete mydata;
        quit;

        %let i = %eval(&i + 1);
    %end;
%mend;

%let listfiles = pan20_19761993 pan20_19942001 pan20_20022007 pan20_20082012 pan20_20132020;
%extract_dads_panel(2020, &listfiles, &outdir_panel);

/*===============================================================================
    DADS-EDP PANEL
===============================================================================*/

%macro extract_dads_edp(year, listfiles, outdir);
    %local i file yearrange;
    %let i = 1;
    %do %while(%length(%scan(&listfiles, &i)));
        %let file = %scan(&listfiles, &i);
        %let yearrange = %scan(&file, 2, _);

        %put NOTE: DADS-EDP year=&year file=&file yearrange=&yearrange;

        data mydata;
            set "&rawdatadir.\DADS_Panel tous salari�s-EDP_&year.\&file..sas7bdat"
            (keep = an nninouv entpan sx annai sir dept cs2 dp sb dip_tot);
            where mod(annai, 2) = 0;
        run;

        %lower_vars(lib=work, data=mydata);

        proc export data=mydata outfile="&outdir_panel.\dads_panel_edp_&year._&yearrange..dta" replace;
        run;

        proc datasets lib=work nolist;
            delete mydata;
        quit;

        %let i = %eval(&i + 1);
    %end;
%mend;

%let listfiles = paneledp2020_19942001 paneledp2020_20022007;
%extract_dads_edp(2020, &listfiles, &outdir_panel);









/*===============================================================================
    Specify the project and path 
===============================================================================*/

%let project = TechBoom_replicationPackage ;
%let rawdatadir = \\casd.fr\casdfs\Projets\FISCENT\Data;
%let outdir = C:\Users\Public\Documents\&project.\rawdata\raw\ree_creation;


/**********************************************************/
/* Macro to transform upper case to lower case (important for dta export) */
/**********************************************************/

%macro lower_vars(lib=WORK, data=mydata);
	proc sql noprint;
		select cats(name,'=',lower(name))
		into :renlist separated by ' '
		from dictionary.columns
		where libname = upcase("&lib")
		  and memname = upcase("&data")
		  and name ne lowcase(name);
	quit;
	%if %length(%superq(renlist)) %then %do;
		proc datasets lib=&lib nolist;
			modify &data;
			rename &renlist;
		quit;
	%end;
	%else %put NOTE: all variables already in lowercase;
%mend;

/*===============================================================================
    Extract ree creation entreprises raw data  
===============================================================================*/

%macro ree_creation(fyear=, lyear=, outdir=);
    %local year;

    %do year = &fyear %to &lyear;

        data _null_;
            put "NOTE: Processing Year=&year";
        run;

	    /* Determine subdirectory and filename */
	    %if &year >= 1993 and &year <= 2006 %then %do;
	        %let subdir = \R�tropol�es;
	        %let filename = creat&year.;
	    %end;
	    %else %if &year >= 2007 and &year <= 2008 %then %do;
	        %let subdir = \R�tropol�es;
	        %let filename =  crea&year.;
	    %end;
	    %else %if &year >= 2009 and &year <= 2011 %then %do;
	        %let subdir = ;
	        %let filename = france;
	    %end;
	    %else %if &year >= 2012 and &year <= 2015 %then %do;
	        %let subdir = ;
	        %let filename = cren&year;
	    %end;

	    libname ree&year "&rawdatadir.\REE_Cr�ations Entreprises_&year.&subdir.";
        %let lib = ree&year;

        /* Load raw data */
        data mydata;
            set &lib..&filename (keep = SIREN CJ APEN);;
        run;

 		/* Macro to rename upper case to lower case */
		%lower_vars(lib=work, data=mydata);

		/* Export in dta */ 
		proc export data=mydata outfile="&outdir.\ree_creation&year..dta" replace;
		run;

		/* Clean memory */
		proc datasets lib=work nolist;
			delete mydata collapsed;
		quit;

    %end;
%mend;

%ree_creation(fyear=1993, lyear=2015, outdir=&outdir);







/*===============================================================================
    Specify the project and path
===============================================================================*/

%let project = TechBoom_replicationPackage ;
%let rawdatadir = \\casd.fr\casdfs\Projets\FISCENT\Data;
%let outdir = C:\Users\Public\Documents\&project.\rawdata\raw\lifi;

/*===============================================================================
/* Macro to transform upper case in lower case (important for dta export)
===============================================================================*/

%macro lower_vars(lib=WORK, data=mydata);
    proc sql noprint;
        select cats(name,'=',lower(name))
        into : renlist separated by ' '
        from dictionary.columns
        where libname = upcase("&lib")
        and memname = upcase("&data")
        and name ne lowcase(name);
    quit;
    %if %length(&renlist) %then %do;
        proc datasets lib=&lib nolist;
            modify &data;
            rename &renlist;
        quit;
    %end;
%mend;


/*===============================================================================
    LIFI EXTRACTION
===============================================================================*/

/* Main macro for LIFI extraction */
%macro extract_lifi(listyears, outdir);
    %local i year dirname files j file;
    %let i = 1;
    %do %while(%length(%scan(&listyears, &i)));
        %let year = %scan(&listyears, &i);

        %put NOTE: LIFI YEAR=&year;

        /* Determine directory naming and file list based on year */
        %if &year >= 1994 and &year <= 2011 %then %do;
            %let dirname = LIFI_Enqu�te LIFI_&year;
            %let files = tg lar;
        %end;
        %else %if &year >= 2012 and &year <= 2013 %then %do;
            %let dirname = LIFI_LIFI_&year;
            %let files = tg lar;
        %end;
        %else %if &year >= 2014 and &year <= 2015 %then %do;
            %let dirname = LIFI_LIFI_&year;
            %let files = groupe liaison_lifi liaison_reelle ul_lifi;
        %end;

        /* Process each file for the current year */
        %let j = 1;
        %do %while(%length(%scan(&files, &j)));
            %let file = %scan(&files, &j);

            %put NOTE: LIFI YEAR=&year FILE=&file;

            /* Import SAS file */
            data mydata;
                set "&rawdatadir.\&dirname.\&file..sas7bdat";
            run;

            /* Convert variable names to lowercase */
            %lower_vars(lib=work, data=mydata);

            /* Export to Stata format */
            proc export data=mydata outfile="&outdir.\lifi&year.&file..dta" replace;
            run;

            /* Clean up */
            proc datasets lib=work nolist;
                delete mydata;
            quit;

            %let j = %eval(&j + 1);
        %end;

        %let i = %eval(&i + 1);
    %end;
%mend;

/* Wrapper macro using fyear/lyear for contiguous year ranges */
%macro extract_lifi_range(fyear=, lyear=, outdir=);
    %local yr listyears;
    %let listyears =;
    %do yr = &fyear %to &lyear;
        %let listyears = &listyears &yr;
    %end;
    %extract_lifi(&listyears, &outdir);
%mend;


/*################################################################### */
/* RUN LIFI EXTRACTION */
/*################################################################### */

/* Extract years 1994-2007 (matching the Stata dofile) */
%extract_lifi_range(fyear=1994, lyear=2007, outdir=&outdir);


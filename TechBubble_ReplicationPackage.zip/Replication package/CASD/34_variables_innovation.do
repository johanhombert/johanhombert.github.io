
cd "${dir}"


*===============================================================================
* Technology characteristics crosswalk 
*===============================================================================
{

*===============================================================================
* Firm panel with time consistent industries 
*===============================================================================

*-------------------------------------------------------------------------------
* Simple extract ficus-fare    
*-------------------------------------------------------------------------------
	
*** FICUS 1994-2007
forval yr = 1994/2007{
	display in red "ficus `yr'"
	quiet{
		if `yr'==1994 {
			use siren ape emp using "${ficus_fare}/ficus-fare`yr'" , clear 
			gen year = `yr'	
		}
		else {
			append using "${ficus_fare}/ficus-fare`yr'", keep(siren ape emp) gen(_appended)
			replace year = `yr' if _appended==1
			drop _appended
		}
	}
}

*-------------------------------------------------------------------------------
* Convert all naf93 into naf2 rev1    
*-------------------------------------------------------------------------------

replace ape="271Y" if inlist(ape, "271Z", "273J")
replace ape="282C" if inlist(ape, "282A", "282B")
replace ape="287Q" if inlist(ape, "287M", "287P") 
replace ape="321C" if ape=="321B" 
replace ape="291B" if ape=="291C" 
replace ape="292L" if ape=="292K" 
replace ape="295B" if ape=="295C" 
replace ape="295R" if ape=="295P" 
replace ape="401A" if ape=="401Z" 
replace ape="402A" if ape=="402Z" 
replace ape="518G" if ape=="516G" 
replace ape="518J" if ape=="516J" 
replace ape="518P" if ape=="516N" 
replace ape="518A" if ape=="516A" 
replace ape="518C" if ape=="516C" 
replace ape="518E" if ape=="516E" 
replace ape="518M" if ape=="516K" 
replace ape="518N" if ape=="516L" 
replace ape="519A" if ape=="517Z" 
replace ape="551A" if ape=="551D" 
replace ape="642C" if inlist(ape, "642A", "642B") 

replace ape="711A" if ape=="711Z" 
replace ape="722A" if ape=="722Z" 
replace ape="900G" if ape=="900B" 
replace ape="900E" if ape=="900C" 
replace ape="922E" if ape=="922C" 
replace ape="921D" if ape=="923D" 
replace ape="923K" if inlist(ape, "923H", "923J") 
replace ape="930L" if ape=="926C" 	
replace ape="742A" if inlist(ape, "7421", "7422")
replace ape="742B" if inlist(ape, "7424", "7426")
replace ape="742C" if ape=="7425"
replace ape="672Z" if ape=="7431"
replace ape="703A" if ape=="7439"	
replace ape="851C" if ape=="8541"|ape=="8542"|ape=="8553"|ape=="8555"|ape=="8559"|ape=="8574"|ape=="8599"
replace ape="741C" if ape=="7413"
replace ape="741G" if inlist(ape, "7416", "7417")
replace ape="741J" if ape=="7419"

replace ape ="748G" if ape=="7423" | ape=="7489"
replace ape ="748K" if ape=="7481"
replace ape ="804D" if ape=="8044"
replace ape ="923K" if ape == "9233"
replace ape = "366E" if ape == "9239" & siren =="450797238"
replace ape = "745A" if ape == "9239"
replace ape = "672Z" if ape == "9911"
replace ape = "701A" if ape == "9915"	
replace ape = "748K" if ape == "9916" & siren =="452990682"
replace ape = "642D" if ape == "9916" & siren =="429146301"
replace ape = "701A" if ape == "9990" & siren =="328070636"
replace ape = "633Z" if ape == "9990" & siren =="399296979"
replace ape = "524R" if ape == "9990" & inlist(siren, "399296979", "444520035", "344301262", "412123127")
replace ape = "741G" if ape == "9990" & siren =="442915559" 
replace ape = "731Z" if ape == "9990" & siren =="484583364" 
replace ape = "744A" if ape == "9990" & siren =="331068585" 
replace ape = "804C" if ape == "9990" & siren =="410992903" 
replace ape = "748K" if ape == "9990" & siren =="442944443" 
replace ape = "722A" if ape == "9990" & siren =="447918277" 
replace ape = "515C" if ape == "9990" & siren =="421506486" 
replace ape = "633Z" if siren == "438328957"
replace ape = "634A" if siren == "441585577"
replace ape = "521C" if siren == "443151170"	

replace ape = "745A" if ape == "5908"	
replace ape = "741G" if ape == "7714"	
replace ape = "741G" if ape == "8121"	
replace ape = "702C" if ape == "5910"	
replace ape = "518P" if ape == "5909"	
replace ape = "671E" if ape == "7801"	
replace ape = "502Z" if ape == "6506"	

tempfile ficus_cleanedAPE_naf2Rev1
save `ficus_cleanedAPE_naf2Rev1'


*-------------------------------------------------------------------------------
* Basic cleaning of ape (preserve time varying definition)
*-------------------------------------------------------------------------------

use `ficus_cleanedAPE_naf2Rev1', clear

gen flag_digit_last = regexm(substr(ape, -1, 1), "[0-9]")

* Drop firms that have all observations missing industry 
gen missing 	= (substr(ape,1,3)=="999"|ape=="000Z"|ape=="") | flag_digit_last==1
gegen totmiss	= sum(missing),by(siren)
gegen nbobs		= sum(1),by(siren)
drop if totmiss/nbobs ==1
drop nbobs 

* Replace ape==9999|ape==000Z (missing) when another ape code is provided for this firm
* Do the same for the few wrongly coded ape code that ends with a number (it is always a letter)
* Only keep the problematic firms to speed up 
	preserve 
		keep if totmiss>=1
		sort siren year
		replace ape = "" if missing==1
		* Forward fill  
		by siren: replace ape=ape[_n-1] if _n>1 & ape==""
		
		* Backward fill 
		gsort siren -year
		by siren: replace ape=ape[_n-1] if _n>1 & ape==""
		tempfile temp 
		save `temp'
	restore 
* bring back the cleaned ape 
drop if totmiss>=1
append using `temp'
drop totmiss 

** fill in ape when ape is changing one year and going back to its initial value (a mistake)
sort siren year 
replace ape=ape[_n-1] if ape!=ape[_n-1] & siren==siren[_n-1] & ape!=ape[_n+1] & siren==siren[_n+1] & ape[_n-1]==ape[_n+1]
	
drop missing	
save "output/ficus_cleanedAPE_naf2Rev1_timevarying", replace 

}
*	


*===============================================================================
*	Innovation types at the naf level (using CPC characteristics from US)
*===============================================================================
{

*-------------------------------------------------------------------------------
* Create matrix CPC x naf using French patents  
*-------------------------------------------------------------------------------

*** Firm x patentid
	use appln_id siren year_app using "rawdata/patents/matching_BGHM_oecd", clear
	destring year_app,replace
	// Restrict to patents between 1994 and 2001 
	keep if year_app >=1994 & year_app <=2001 
	// string siren 
	tostring siren ,replace force
		gen sir = substr("000000000"+siren,-9,.)
	drop siren 
	rename sir siren 
	rename year_app year 
		tempfile patentid_siren
		save `patentid_siren'
	
*** Now we can associate one ape to each patent via their siren 
	* Get siren we will have to match 
		use siren using `patentid_siren', clear
	bys siren: keep if _n==1 
	tempfile temp 
	save `temp'
	
 	* weight using employment 
	use siren year ape using "output/ficus_cleanedAPE_naf2Rev1_timevarying",clear
	merge m:1 siren using `temp', nogen keep(3)

	* Bring all the patents of the firm-year
	merge 1:m siren year using `patentid_siren',nogen keep(3)
	
	* Bring CPC for each patent (each patent can have multiple CPCs)	
	joinby appln_id using "rawdata/patents/matching_BGHM_cpc" 

	save "output/patent_cpc_naf_dep_timevarying",replace 

*** Clean folder 
		* tempfile patentid_siren is dropped automatically
	
*-------------------------------------------------------------------------------
* Extract CPC info from US patents 
*-------------------------------------------------------------------------------
{	
	use cpc year age retech_stock sdcit using "rawdata/patents/cpc_year_workingdata03", clear 

*** Restrict to working period 
	keep if year >=1990 & year <=2010 
	
	* Winsorize
	foreach var in sdcit retech_stock {
		winsor4 `var', group(year) level(1) method(winsor) outlier(tail)  
	}

*** Compute deviation from CPC baseline 
	quiet foreach var in sdcit retech_stock age {
		areg `var', a(cpc)
		predict res`var',resid		
		winsor4 res`var', group(year) level(1) method(winsor) outlier(tail)  
		gen D`var' =res`var' if year>=1995 & year<=2000
	}	

*** Get average around bubble period 
	gcollapse (mean) D*  , by(cpc)
	tempfile cpc_characteristicsUS
	save `cpc_characteristicsUS'


*** Construction characteristics at ape level 
	use "output/patent_cpc_naf_dep_timevarying", clear 
	** Bring tech class characteristics
	merge m:1 cpc using `cpc_characteristicsUS',nogen keep(3)

	** Multiply age by -1 so that all the measures can be interpreted in the same way 
	* when we sort: higher value = higher experimentation
	replace Dage = -Dage

	gcollapse (mean) D*  , by(ape)  
	rename ape apet // to be consistent with dads panel 
	save "output/innovation_characteristics_naf4",replace 
}
*
}
*	


cap program drop build_ict_sector_shares
program define build_ict_sector_shares
	syntax [, WITHISIC]

	* Base sample
	use year sir apet ict cs2 nbheur using "output/dads_panel_all", clear
	keep if year>=1994 & year<=2008
	drop if ict==.

	* Current sector
	gen sec4 = apet
	gen sec3 = substr(apet,1,3)
	gen sec2 = substr(apet,1,2)

	* ICT sector mapping
	gen ictsec1 = "Services" if sec2=="72" | sec4=="713E"
	gen rank = 1 if ictsec1=="Services"
	gen ictsec2 = " IT consultancy" if sec3=="721"
	replace ictsec2 = " Software" if sec3=="722"
	replace ictsec2 = " Data processing" if sec3=="723"
	replace ictsec2 = " Maintenance computers" if sec3=="725"
	replace ictsec2 = " Other computer-related services" if inlist(sec3,"724","726") | sec4=="713E"

	if "`withisic'"!="" {
		gen isic = "\textit{7210}" if sec3=="721"
		replace isic = "\textit{7220}" if sec3=="722"
		replace isic = "\textit{7230}" if sec3=="723"
		replace isic = "\textit{7250}" if sec3=="725"
		replace isic = "\textit{7123,7240,7290}" if inlist(sec3,"724","726") | sec4=="713E"
	}

	replace ictsec1 = "Telecommunications" if sec3=="642"
	replace rank = 2 if ictsec1=="Telecommunications"
	replace ictsec2 = "  Telecommunications " if sec3=="642"
	if "`withisic'"!="" {
		replace isic = "\textit{6420}" if sec3=="642"
	}

	replace ictsec1 = "Manufacturing" if sec3=="300" | sec4=="313Z" | inlist(sec3,"321","322","323","332","333")
	replace rank = 3 if ictsec1=="Manufacturing"
	replace ictsec2 = "  Computing machinery" if sec3=="300"
	if "`withisic'"!="" {
		replace isic = "\textit{3000}" if sec3=="300"
	}
	replace ictsec2 = "  Insulated wire and cable" if sec4=="313Z"
	if "`withisic'"!="" {
		replace isic = "\textit{3130}" if sec4=="313Z"
	}
	replace ictsec2 = "  Electronic/communication equipment" if inlist(sec3,"321","322","323")
	if "`withisic'"!="" {
		replace isic = "\textit{3210,3220,3230}" if inlist(sec3,"321","322","323")
	}
	replace ictsec2 = "  Measurement/navigation/process control equipment" if inlist(sec3,"332","333")
	if "`withisic'"!="" {
		replace isic = "\textit{3312,3313}" if inlist(sec3,"332","333")
	}

	replace ictsec1 = "Wholesale" if inlist(sec4,"516G","518G","518J")
	replace rank = 4 if ictsec1=="Wholesale"
	replace ictsec2 = " Computers, electronics, telecoms" if inlist(sec4,"516G","518G","518J")
	if "`withisic'"!="" {
		replace isic = "\textit{5151,5152}" if inlist(sec4,"516G","518G","518J")
	}

	replace rank = 0 if ictsec1==""

	* Skilled indicators
	gen all = 1
	gen ski = substr(cs2,1,1)=="3" | cs2=="23"
	gen etp = min(nbheur/1820,1)

	* 1-digit shares
	tempfile ict_table_1digit
	preserve
		gcollapse (sum) all ski [aw=etp], by(ictsec1 rank)
		foreach x in all ski {
			gegen tot`x' = sum(`x')
			gen share_`x' = `x'/tot`x'*100
		}
		drop if rank==0
		gen ictsec2 = ""
		gen isic = ""
		keep ictsec1 ictsec2 rank isic share_*
		save `ict_table_1digit', replace
	restore

	* 2-digit shares
	if "`withisic'"!="" {
		gcollapse (sum) all ski [aw=etp], by(ictsec2 rank isic)
	}
	else {
		gcollapse (sum) all ski [aw=etp], by(ictsec2 rank)
		gen isic = ""
	}
	foreach x in all ski {
		gegen tot`x' = sum(`x')
		gen share_`x' = `x'/tot`x'*100
	}
	drop if rank==0
	gen ictsec1 = ""
	keep ictsec1 ictsec2 rank isic share_*
	append using `ict_table_1digit'
end

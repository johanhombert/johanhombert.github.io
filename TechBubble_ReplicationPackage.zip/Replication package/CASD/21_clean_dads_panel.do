
cd "${dir}"


*===============================================================================
* ASSEMBLE THE DIFFERENT YEARS OF THE DADS PANEL
*===============================================================================
{

*** Append all years

use "rawdata/raw/dads_panel/dads_panel_2020_19761993", clear
foreach time in 19942001 20022007 20082012 20132020 {
	append using "rawdata/raw/dads_panel/dads_panel_2020_`time'"
}

foreach var of varlist _all {
	local lowername = lower("`var'")
	rename `var' `lowername'
}

*** Basic filters 

* Drop obs before 1987 and after 2015, we will never use them
drop if an<1987 | an>2015

* Drop fictitious person id (impossible to identify them in a panel according to documentation)
drop if nnifict=="1"
drop nnifict
cap drop nnihc // nnihc = individual not born in october but added to reach 1/25 sample rate

* Keep individuals in the 1/25th panel
keep if pan25=="1" & mod(annai,2)==0
drop pan25

* Drop unemployed (appears only after 2008)
drop if ce=="A"

* Rename variables
rename an year
rename nic4 nic

* Keep individuals aged 20-65
cap drop age 
gen age 	= year-annai
keep if age>=20 & age<=65

* earnings
compress

save "output/dads_panel", replace

}


*===============================================================================
* CREATE MAPPINGS
*===============================================================================
{

*** Define ICT for NAF rev.2, 2008 using mapping from NAF rev.1, 2003

* use 2008 as both classifications are reported
use sir nninouv year apet apet2 using "output/dads_panel" if year==2008, clear
keep if apet~="" & apet2~=""
tempfile dads_panel_2008
save `dads_panel_2008', replace

* ICT definition in NAF rev.1, 2003
gen ict = inlist(substr(apet,1,2),"72") | inlist(substr(apet,1,3),"300","321","322","323","332","333","642") | inlist(apet,"313Z","516G","518G","518J","713E") if apet~=""

* at sector level: average by NAF rev.2, 2008
preserve
	gcollapse (mean) ict_naf2008=ict, by(apet2)
	drop if ict_naf2008==.
	replace ict_naf2008 = ict_naf2008>=0.5
	save "output/ict_naf2008", replace
restore

* at firm level
preserve
	gcollapse (mean) ict_sir2008=ict, by(sir)
	drop if ict_sir2008==.
	replace ict_sir2008 = ict_sir2008>=0.5
	save "output/ict_sir2008", replace
restore

* firm/worker level
gcollapse (max) ict_nni2008=ict, by(sir nni)
drop if ict_nni2008==.
save "output/ict_nni2008", replace


*** Define broad NAF2003 industries for NAF rev.2, 2008 using mapping from NAF rev.1, 2003

* Reuse 2008 sample (already filtered above)
use year apet apet2 using `dads_panel_2008', clear

* broad ind in NAF 2003
gen sec = real(substr(apet,1,2)) if apet~=""
gen broadind_naf2003 = "Agri" if sec>=1 & sec<=5
replace broadind_naf2003 = "Mining" if sec>=10 & sec<=14
replace broadind_naf2003 = "Manuf" if sec>=15 & sec<=37
replace broadind_naf2003 = "Util" if sec>=40 & sec<=41
replace broadind_naf2003 = "Construc" if sec==45
replace broadind_naf2003 = "Retail" if sec>=50 & sec<=52
replace broadind_naf2003 = "Hotel/Resto" if sec==55
replace broadind_naf2003 = "Transport" if sec>=60 & sec<=63
replace broadind_naf2003 = "Telecom" if sec==64
replace broadind_naf2003 = "FIRE" if sec>=65 & sec<=70
replace broadind_naf2003 = "Service" if sec>=71 & sec<=74
replace broadind_naf2003 = "Public" if sec==75
replace broadind_naf2003 = "Educ" if sec==80
replace broadind_naf2003 = "Health" if sec==85
replace broadind_naf2003 = "Soc/Cultu" if sec>=90 & sec<=93
drop if broadind_naf2003=="" // 9 obs deleted

* collapse by NAF rev.2, 2008
gen n = 1
gcollapse (sum) n, by(broadind_naf2003 apet2)

* assign broadind_naf2003 with larger weight (>.9 for 99% of obs)
gegen totn = sum(n), by(apet2)
gen w = n/totn
*gegen maxw = max(w), by(apet2)
*sum maxw [aw=totn], d
gsort apet2 -w broadind_naf2003
by apet2: keep if _n==1
keep apet2 broadind_naf2003
label var broadind_naf2003 "Broad NAF2003 industries assigned to fine NAF2008 industries"
save "output/naf2008_to_broadind_naf2003_naf2008", replace


*** Mappings NAF rev.1, 2003 to NAF rev.2, 2008: at 2-digit, 3-digit, 4-digit levels

* Firms with NAF2 sector from Fare 2009
use siren ape_diff redi_r310 using "rawdata/raw/ficus_fare/fare2009", clear
* string siren
tostring siren,replace 
replace siren = substr("000000000"+siren,-9,.)
rename ape_diff naf 
rename redi_r310 catotal  
keep if catotal>0 & catotal<.
tempfile naf_bridge
save `naf_bridge', replace

* Merge with firms with NAF1 sector from Ficus 2007
use siren ape catotal using "rawdata/raw/ficus_fare/ficus_2007", clear

* string siren
tostring siren, replace 
replace siren = substr("000000000"+siren,-9,.)
drop if inlist(siren,"",".","0","000000000")
gsort siren catotal
by siren: keep if _n==_N
merge 1:1 siren using `naf_bridge', nogen keep(3)
keep if catotal>0 & catotal<.
save `naf_bridge', replace

* Assign NAF2 to main NAF1 (at 2,3,4 digit)
foreach d in 2 3 4 {
	use `naf_bridge', clear
	gen ape`d' = substr(ape,1,`d')
	gcollapse (sum) catotal, by(naf ape`d')
	gegen totca = sum(catotal), by(naf)
	gen w = catotal/totca
	gsort naf -w
	by naf: keep if _n==1
	keep naf ape`d'
	* add a few missing naf2
	local new = _N+21
	set obs `new'
	qui replace naf = "0113Z" if _n==_N & naf==""
	qui replace naf = "0149Z" if _n==_N-1 & naf==""
	qui replace naf = "0161Z" if _n==_N-2 & naf==""
	qui replace naf = "0322Z" if _n==_N-3 & naf==""
	qui replace naf = "6411Z" if _n==_N-4 & naf==""
	qui replace naf = "6491Z" if _n==_N-5 & naf==""
	qui replace naf = "6520Z" if _n==_N-6 & naf==""
	qui replace naf = "6530Z" if _n==_N-7 & naf==""
	qui replace naf = "8411Z" if _n==_N-8 & naf==""
	qui replace naf = "8412Z" if _n==_N-9 & naf==""
	qui replace naf = "8413Z" if _n==_N-10 & naf==""
	qui replace naf = "8422Z" if _n==_N-11 & naf==""
	qui replace naf = "8423Z" if _n==_N-12 & naf==""
	qui replace naf = "8424Z" if _n==_N-13 & naf==""
	qui replace naf = "8425Z" if _n==_N-14 & naf==""
	qui replace naf = "8430A" if _n==_N-15 & naf==""
	qui replace naf = "8430B" if _n==_N-16 & naf==""
	qui replace naf = "8430C" if _n==_N-17 & naf==""
	qui replace naf = "8510Z" if _n==_N-18 & naf==""
	qui replace naf = "8730B" if _n==_N-19 & naf==""
	qui replace naf = "9900Z" if _n==_N-20 & naf==""
	qui replace ape`d'=substr("011A",1,`d') if naf == "0113Z"
	qui replace ape`d'=substr("012J",1,`d') if naf == "0149Z"
	qui replace ape`d'=substr("011A",1,`d') if naf == "0161Z"
	qui replace ape`d'=substr("050C",1,`d') if naf == "0322Z"
	qui replace ape`d'=substr("651A",1,`d') if naf == "6411Z"
	qui replace ape`d'=substr("652A",1,`d') if naf == "6491Z"
	qui replace ape`d'=substr("660F",1,`d') if naf == "6520Z"
	qui replace ape`d'=substr("660C",1,`d') if naf == "6530Z"
	qui replace ape`d'=substr("751A",1,`d') if naf == "8411Z"
	qui replace ape`d'=substr("751C",1,`d') if naf == "8412Z"
	qui replace ape`d'=substr("751E",1,`d') if naf == "8413Z"
	qui replace ape`d'=substr("752C",1,`d') if naf == "8422Z"
	qui replace ape`d'=substr("752E",1,`d') if naf == "8423Z"
	qui replace ape`d'=substr("752G",1,`d') if naf == "8424Z"
	qui replace ape`d'=substr("752J",1,`d') if naf == "8425Z"
	qui replace ape`d'=substr("753A",1,`d') if naf == "8430A"
	qui replace ape`d'=substr("753B",1,`d') if naf == "8430B"
	qui replace ape`d'=substr("753C",1,`d') if naf == "8430C"
	qui replace ape`d'=substr("801Z",1,`d') if naf == "8510Z"
	qui replace ape`d'=substr("853C",1,`d') if naf == "8730B"
	qui replace ape`d'=substr("9900",1,`d') if naf == "9900Z"
	save "output/naf2_naf1rev1_`d'digit", replace
}


*-------------------------------------------------------------------------------
* Load naf2 rev1 classification
*-------------------------------------------------------------------------------

	import excel using "rawdata/industry-classification/naf2003_n1-5.xls",clear first 
	foreach n in 700 220 60 31 17{
		replace N_`n' = subinstr(N_`n' , ".", "", .)
		rename N_`n' n`n'
	}
	
	save "output/naf2003_n1_5", replace

}


*===============================================================================
* PANEL OF FULL-TIME WORKERS 
*===============================================================================
{
	
	use "output/dads_panel" if ce=="C", clear

*** Basic cleaning 

	* Keep full time
	drop ce 
	
	* Drop job spells shorter than 6 months
	gen hourperweek = ceil(nbheur/dp*(360/52))
	keep if hourperweek>=30
	keep if dp>=180
	
	* Monthly gross wage
	* NB: before 1999, s_brut is missing, after 1999, sb is more and more missing
	gen wage 		= sb if year<2008
	replace wage	= s_brut if year>=2008
	replace wage 	= wage/dp*30	// dp = number of days worked
		
*** Drop observations with wage below 40% of minimum wage (as in LeMinez and Roux)

	* Monthly gross minimum wage (source: Insee website)
	gen smic_brut = .
	replace smic_brut = 4860/6.56 if year==1988
	replace smic_brut = 4961/6.56 if year==1989
	replace smic_brut = 5156/6.56 if year==1990
	replace smic_brut = 5519/6.56 if year==1991
	replace smic_brut = 5629/6.56 if year==1992
	replace smic_brut = 5886/6.56 if year==1993
	replace smic_brut = 6009/6.56 if year==1994
	replace smic_brut = 6249/6.56 if year==1995
	replace smic_brut = 6374/6.56 if year==1996
	replace smic_brut = 6663/6.56 if year==1997
	replace smic_brut = 6797/6.56 if year==1998
	replace smic_brut = 6881/6.56 if year==1999
	replace smic_brut = 7101/6.56 if year==2000
	replace smic_brut = 1127 if year==2001
	replace smic_brut = 1154 if year==2002
	replace smic_brut = 1215 if year==2003
	replace smic_brut = 1286 if year==2004
	replace smic_brut = 1217 if year==2005
	replace smic_brut = 1254 if year==2006
	replace smic_brut = 1280 if year==2007
	replace smic_brut = 1321 if year==2008
	replace smic_brut = 1337 if year==2009
	replace smic_brut = 1343 if year==2010
	replace smic_brut = 1365 if year==2011
	replace smic_brut = 1398 if year==2012
	replace smic_brut = 1430 if year==2013
	replace smic_brut = 1445 if year==2014
	replace smic_brut = 1457 if year==2015
	replace smic_brut = 1466 if year==2016
	replace smic_brut = 1480 if year==2017
	replace smic_brut = 1498 if year==2018
	replace smic_brut = 1521 if year==2019
	replace smic_brut = 1539 if year==2020
	
	replace wage = . if wage<.6*smic_brut
	drop smic_brut

*** Multiple jobs in a year 	

	* When worker has several jobs in same year (only 1% of obs since we have already dropped job spells shorter than 6 months), keep the one the with highest wage (to simplify data structure)
	
	drop if wage==.
	gen logwage = log(wage)
	gsort nni year wage dp cs2 sir
	by nni year: keep if _n==_N

*** Define ICT sectors

	* using NAF rev.1, 2003 (1993-2008)
	gen sec4 = apet
	gen sec3 = substr(apet,1,3)
	gen sec2 = substr(apet,1,2)
	foreach x in ict ict_manuf ict_who ict_tel ict_ser {
		gen `x' = 0 if apet~="" & year>=1993
	}
	replace ict_manuf = 1 if sec3=="300" | sec4=="313Z" | inlist(sec3,"321","322","323","332","333")
	replace ict_who = 1 if inlist(sec4,"516G","518G","518J")
	replace ict_tel = 1 if sec3=="642"
	replace ict_ser = 1 if sec2=="72" | sec4=="713E"
	replace ict = ict_manuf+ict_who+ict_tel+ict_ser
	drop sec4 sec3 sec2 ict_manuf ict_who ict_tel ict_ser
	
	* use mapping with NAF rev.2, 2008 to define ICT after 2008
	* first merge on worker/firm, if worker still in same firm as in 2008
	merge m:1 sir nni using "output/ict_nni2008", keep(1 3) nogen
	replace ict = ict_nni2008 if ict==. & year>=2008
	drop ict_nni2008
	* then merge on firm, if firm was already there in 2008
	merge m:1 sir using "output/ict_sir2008", keep(1 3) nogen
	replace ict = ict_sir2008 if ict==. & year>=2008
	drop ict_sir2008
	* and finally merge on apet2
	merge m:1 apet2 using "output/ict_naf2008", keep(1 3) nogen
	replace ict = ict_naf2008 if ict==. & year>=2008
	drop ict_naf2008	

	* broad industries: NAF 2003
	capture drop sec
	gen sec = real(substr(apet,1,2)) if apet~="" & year>=1993
	gen broadind = "Agri" if sec>=1 & sec<=5
	replace broadind = "Mining" if sec>=10 & sec<=14
	replace broadind = "Manuf" if sec>=15 & sec<=37
	replace broadind = "Util" if sec>=40 & sec<=41
	replace broadind = "Construc" if sec==45
	replace broadind = "Retail" if sec>=50 & sec<=52
	replace broadind = "Hotel/Resto" if sec==55
	replace broadind = "Transport" if sec>=60 & sec<=63
	replace broadind = "Telecom" if sec==64
	replace broadind = "FIRE" if sec>=65 & sec<=70
	replace broadind = "Service" if sec>=71 & sec<=74
	replace broadind = "Public" if sec==75
	replace broadind = "Educ" if sec==80
	replace broadind = "Health" if sec==85
	replace broadind = "Soc/Cultu" if sec>=90 & sec<=93
	replace broadind = "Public" if sir=="ETAT" & broadind=="" & year>=1993
	drop sec

	* broad industries: NAF2008
	merge m:1 apet2 using "output/naf2008_to_broadind_naf2003_naf2008", keep(1 3) nogen
	replace broadind = broadind_naf2003 if broadind==""
	drop broadind_naf2003
	* fill in manually NAF2008 not matched
	replace broadind = "Service" if broadind=="" & inlist(substr(apet2,1,2),"74")
	replace broadind = "Public" if broadind=="" & inlist(substr(apet2,1,2),"84")
	replace broadind = "Educ" if broadind=="" & inlist(substr(apet2,1,2),"85")
	
	save "output/panel_full_dads", replace

}
*	


*===============================================================================
* ADDITIONAL DATASETS USED LATER
*===============================================================================
{
	
*** STARTING YEAR WITH EMPLOYER

	*For each worker-firm pair, construct first year in which the worker works for the firm.
	*We need this variable to identify "joiners" i.e. workers who join in the first years after the firm is created.
	use nni sir year using "output/panel_full_dads", clear
	gsort nni sir year
	by nni sir: keep if _n==1
	rename year startingyear
	save "output/dads_startingyear", replace
	

// *** LIST OF FIRMS IN THE DADS PANEL

	use sir using  "output/dads_panel",clear
	bysort sir: keep if _n==1
	save "output/dads_panel_list_of_sir", replace


***	INFLATION
	clear
	set obs 32
	gen year = 1990+_n
	gen euro2000 = 1 if year==2000
	replace euro2000 = 1.148 if year==1991
	replace euro2000 = 1.121 if year==1992
	replace euro2000 = 1.098 if year==1993
	replace euro2000 = 1.08 if year==1994
	replace euro2000 = 1.061 if year==1995
	replace euro2000 = 1.041 if year==1996
	replace euro2000 = 1.028 if year==1997
	replace euro2000 = 1.022 if year==1998
	replace euro2000 = 1.017 if year==1999
	replace euro2000 = .984 if year==2001
	replace euro2000 = .966 if year==2002
	replace euro2000 = .946 if year==2003
	replace euro2000 = .927 if year==2004
	replace euro2000 = .911 if year==2005
	replace euro2000 = .896 if year==2006
	replace euro2000 = .883 if year==2007
	replace euro2000 = .859 if year==2008
	replace euro2000 = .858 if year==2009
	replace euro2000 = .845 if year==2010
	replace euro2000 = .828 if year==2011
	replace euro2000 = .811 if year==2012
	replace euro2000 = .804 if year==2013
	replace euro2000 = .800 if year==2014
	replace euro2000 = .800 if year==2015
	replace euro2000 = .799 if year==2016
	replace euro2000 = .791 if year==2017
	replace euro2000 = .777 if year==2018
	replace euro2000 = .768 if year==2019
	replace euro2000 = .764 if year==2020
	replace euro2000 = .752 if year==2021
	replace euro2000 = .715 if year==2022
	
	save "${dir}/rawdata/inflation", replace


*** UNEMPLOYMENT
	import excel using "rawdata/unemployment_rate.xls", clear first 
	gen dep0 		= substr(departement,1,2)
	
	* reshape 
	reshape long y_,i(dep0) j(year)
	rename y_ urate 
	drop departement 
	
	* Save at the department x year level
	save "output/unemployment_rate", replace 
	
	* Compute average 1998-2001
	keep if year>=1998 & year<=2001
	gcollapse (mean) urate9801 = urate, by(dep0)
	save "output/unemployment_rate_9801", replace 

}



*===============================================================================
*   MATCHED DADS-EDP PANEL
*===============================================================================
{

* construct education at worker level
use nni dip_tot using "rawdata/raw/dads_panel/dads_panel_edp_2020_19942001", clear
append using "rawdata/raw/dads_panel/dads_panel_edp_2020_20022007", keep(nni dip_tot)
destring dip_tot, replace force
gcollapse (max) dip_tot, by(nni)
save "output/dads_edp", replace

}



cd "${dir}"


*===============================================================================
* 	VARIABLES AT FIRM-YEAR LEVEL
*===============================================================================
{

*** 1. Annual FICUS-FARE files, restricting to siren that are in the DADS panel

forvalues t = 1994(1)2015 {
	display in red "---------     `t'      ----------"
	if `t'<=2007{
		use immocor immoinc siren year ape emp tot_act capisoc ca va ebe resultat div stat_cj datcr using "${ficus_fare}//ficus-fare`t'",clear
	}
	if `t'==2008 {
		use immocor immoinc siren year ape emp ca va ebe resultat div stat_cj datcr using "${ficus_fare}/ficus-fare`t'",clear
	}		
	if `t'>=2009 & `t'!=2017 {
		use immocor immoinc siren year ape emp ca va ebe resultat div stat_cj datcr using "${ficus_fare}/ficus-fare`t'",clear
	}	

		rename siren sir
		destring stat_cj,replace 
		fmerge 1:1 sir using "output/dads_panel_list_of_sir", nogen keep(3)
		tempfile firm_`t'
		save `firm_`t'', replace
	}

	*** 2. Append all years

	clear
	forvalues t = 1994(1)2015 {
		append using `firm_`t''
	}

* Winsorize a few negative values
foreach x in emp ca tot_act div immocor immoinc {
	replace `x' = 0 if `x'<0
}

* Sales
rename ca S

* Value added
rename va Y

* Employment
rename emp L

* Capital 
gen K 		= immocor + immoinc
rename immocor PPE	  

* Past employment growth, sales growth
gsort sir year	
foreach lag in 1 3 {
	by sir: gen gemp`lag' = (L-L[_n-`lag'])/((L+L[_n-`lag'])/2) if year == year[_n-`lag']+`lag'
	by sir: gen gsal`lag' = (S-S[_n-`lag'])/((S+S[_n-`lag'])/2) if year == year[_n-`lag']+`lag'
}

* Futures sales
by sir: gen Sf5 = S[_n+5] if year == year[_n+5]-5
foreach t in 2005 2010 2015 {
	gegen S`t' = max(cond(year==`t', S, .)), by(sir)
}

* Year of creation
gen yearcrea_ficus = real(substr(datcr,1,4)) if length(datcr)==8
replace yearcrea_ficus = . if yearcrea_ficus<1800

* Whenever possible use non missing value for yearcrea 
gen t = yearcrea_ficus<. 
gsort sir -t year 
by sir: replace yearcrea_ficus = yearcrea_ficus[1] if yearcrea_ficus==.
drop t 

* save
keep sir year gemp1 S Y L Sf5 S2005 yearcrea_ficus resultat
save "output/firm_all_var", replace

}


*===============================================================================
* VARIABLES AT SECTOR-YEAR LEVEL
*===============================================================================
{

* append Ficus-Fare files
clear
gen year = .
forvalues t = 1994(1)2006 {
	local n0 = _N
	append using "${ficus_fare}/ficus-fare`t'", keep(siren capisoc dep ape) // tot_act tactint 
	replace year = `t' in `=`n0'+1'/L
}
tempfile ficus_cap_panel
save `ficus_cap_panel', replace

* remove leading and trailing 0 in departement
replace dep = substr(dep,1,2) if length(dep)==3 & substr(dep,3,1)=="0"
replace dep = substr(dep,2,3) if length(dep)==3 & substr(dep,1,1)=="0"

* sector
rename ape sec

* ict
gen ict = inlist(substr(sec,1,2),"72") | inlist(substr(sec,1,3),"300","321","322","323","332","333","642") | inlist(sec,"313Z","516G","518G","518J","713E") if sec~=""
drop if ict==.

* deal with negative capital
replace capisoc = 0 if capisoc<0

* lagged capital
gegen siren_num = group(siren)
gsort siren_num year
xtset siren_num year
gen cap = capisoc if L.capisoc<.
gen capL1 = L.capisoc if capisoc<.

* sec-dep level growth rate
foreach x in cap capL1 {
	gegen `x'_secdep = sum(`x'), by(sec dep year)
}

foreach x in cap capL1 {
	replace `x' = 0 if `x'==. // useful to calculate the leave-one-out growth rate below
}

* growth rate
gen wcap_secdep = 0.5*(cap_secdep+capL1_secdep)
gen gcap_secdep = (cap_secdep-capL1_secdep) / (0.5*(cap_secdep+capL1_secdep))

* leave-one-out growth rate
gen gcap_secdep_l1o = ((cap_secdep-cap)-(capL1_secdep-capL1)) / (0.5*((cap_secdep-cap)+(capL1_secdep-capL1)))

* save
rename siren sir
rename sec apet_sir
rename dep dept_sir
keep sir apet_sir year wcap_* gcap_* dept_sir
save "output/gcap", replace

* save at the sec-dep-year level
use "output/gcap", clear
gcollapse (mean) gcap_secdep (count) ngcap_secdep=gcap_secdep (sum) wcap_secdep, by(apet_sir dept_sir year)	// gcap_secdep is constant within apet_sir dept_sir year
rename apet_sir apet
rename dept_sir dept
save "output/gcap_secdep", replace



*** Capital flow

use `ficus_cap_panel', clear
keep if year>=1995 & year<=2005

* remove leading and trailing 0 in departement
replace dep = substr(dep,1,2) if length(dep)==3 & substr(dep,3,1)=="0"
replace dep = substr(dep,2,3) if length(dep)==3 & substr(dep,1,1)=="0"

* sector & department
rename ape apet
rename dep dept

* deal with negative capital
gen K_sir = max(capisoc,0)

* lagged
	gsort siren year
	by siren: gen KL1_sir = K_sir[_n-1] if year[_n-1]==year-1
replace KL1_sir = 0 if KL1_sir==. & year~=1995

* save apet-dep-level capital
preserve
gcollapse (sum) K_secdep = K_sir, by(apet dept year)
gsort apet dept year
by apet dept: gen KL1_secdep = K_secdep[_n-1] if year[_n-1]==year-1
drop if year==1995
keep apet dept year K_secdep KL1_secdep
save "output/K_new_secdep", replace
restore

* save firm-level capital
merge m:1 apet dept year using "output/K_new_secdep", nogen
gen K_secdep_l1o = K_secdep - K_sir
gen KL1_secdep_l1o = KL1_secdep - KL1_sir
drop if year==1995
rename siren sir
keep sir year K_secdep_l1o KL1_secdep_l1o
save "output/K_new_sir", replace

* Capital at sector-department level
clear
gen year = .
forvalues t = 1998(1)2001 {
	local n0 = _N
	append using "${ficus_fare}/ficus-fare`t'", keep(dep ape capisoc)
	replace year = `t' in `=`n0'+1'/L
}
rename ape apet
gen K = max(capisoc,0)
gcollapse (sum) K, by(dep apet year)
save "output/K", replace

* Capital growth at the sector level
use "output/K", clear
gcollapse (sum) K, by(apet year)
gegen apet_num = group(apet)
xtset apet_num year
gen wK = K+L1.K
gen gK = (K-L1.K)/(.5*wK)
save "output/gcap_sec", replace

}



*===============================================================================
* OVERPRICING
*===============================================================================
{
cd "${dir}"

*** prepare ownership (LIFI) files to consolidate sales at the group level

forvalues t = 1994(1)2007 {
	display "-----   `t'   -----"

	* open yearly LIFI file
	use "rawdata/raw/lifi/lifi`t'lar", clear

	* keep fully owned subsidiaries
	keep if txcontr>=9800

	* rename variables
	keep sirtg sirlifi
	rename sirlifi siren

	* save
		gduplicates drop
		tempfile lifi_`t'
	save `lifi_`t'', replace

}


*** FICUS-FARE

forvalues t = 1994(1)2007 {
	display "-----   `t'   -----"

	* open yearly FICUS file
	use siren ape ca using "${ficus_fare}/ficus-fare`t'", clear

	* sales consolidated at the group level
	merge 1:1 siren using `lifi_`t'', keep(1 3) nogen
	gegen cagr = sum(ca) if sirtg~="", by(sirtg)
	replace cagr = ca if cagr==.

	* save
	keep siren ape ca cagr
	tempfile sales_`t'
	save `sales_`t'', replace
}


*** MERGE WITH STOCK PRICES

	* append all
	clear
	gen year = .
	forvalues t = 1994(1)2007 {
		local n0 = _N
		append using `sales_`t''
		replace year = `t' in `=`n0'+1'/L
	}

	* merge with stock prices (1% listed firms not matched)
	merge 1:1 siren year using "rawdata/stock_price_firm", keep(2 3) keepusing(mktcap mktcapgr return)

	* lagged market cap
	gsort siren year
	by siren: gen mktcap_1 = mktcap[_n-1] if year[_n-1]==year-1
	replace mktcap_1 = mktcap/(1+return) if mktcap_1==.

	keep if _m==3
	drop _m

save "output/firm_stock", replace


*** INDUSTRY-LEVEL OVERPRICING
	use "output/firm_stock", clear

	* price/sales in 1999 (trimmed to handle outliers)
	gen PS = mktcapgr/cagr if year==1999
	replace PS = . if PS>100

	* price run-up
	gen r99 = return if year==1999
	
	* make sure industry codes are in naf2 rev1 and not naf93
	replace ape="0110" if ape=="011A" 	
	replace ape="0117" if ape=="011D" 
	replace ape="0150" if ape=="013Z" 
	replace ape="271Y" if ape=="271Z" 
	replace ape="271Y" if ape=="273J" 
	replace ape="282C" if ape=="282A" 
	replace ape="282C" if ape=="282B" 
	replace ape="287Q" if ape=="287M" 
	replace ape="287Q" if ape=="287P" 
	replace ape="321C" if ape=="321B" 
	replace ape="291B" if ape=="291C" 
	replace ape="292L" if ape=="292K" 
	replace ape="295B" if ape=="295C" 
	replace ape="295R" if ape=="295P" 
	replace ape="401A" if ape=="401Z" 
	replace ape="402A" if ape=="402Z" 
	replace ape="6506" if ape=="502Z" 
	replace ape="6425" if ape=="524J" 
	replace ape="5806" if ape=="514L" 
	replace ape="5703" if ape=="513A" 
	replace ape="5560" if ape=="452V" 
	replace ape="518G" if ape=="516G" 
	replace ape="518J" if ape=="516J" 
	replace ape="518P" if ape=="516N" 
	replace ape="518A" if ape=="516A" 
	replace ape="518C" if ape=="516C" 
	replace ape="518E" if ape=="516E" 
	replace ape="518M" if ape=="516K" 
	replace ape="518N" if ape=="516L" 
	replace ape="519A" if ape=="517Z" 
	replace ape="551A" if ape=="551D" 
	replace ape="642C" if ape=="642A"
	replace ape="642C" if ape=="642B"
	replace ape="711A" if ape=="711Z" 
	replace ape="7708" if ape=="741A" 
	replace ape="722A" if ape=="722Z" 	
	replace ape="900G" if ape=="900B" 
	replace ape="900E" if ape=="900C" 
	replace ape="922E" if ape=="922C" 
	replace ape="921D" if ape=="923D" 
	replace ape="923K" if ape=="923H" 
	replace ape="923K" if ape=="923J" 
	replace ape="930L" if ape=="926C" 
	replace ape="913A" if ape=="9722"

	* collapse by industry
	preserve
	gcollapse (mean) PS, by(ape)	// (p50) PSmed (mean) r9899e=r9899 r99e=r99
	save "output/sec_stock", replace
	restore

	* industry stock returns (value weighted)
	replace r99 = r99*mktcap_1
	gen w_r99 = mktcap_1 if r99<.

	gcollapse (sum) r99 w_*, by(ape)
	replace r99 = r99/w_r99
	drop w_*
	
	* above/below median
	gen ict = inlist(substr(ape,1,2),"72") | inlist(substr(ape,1,3),"300","321","322","323","332","333","642") | inlist(ape,"313Z","516G","518G","518J","713E") if ape~=""
	local var r99
	qui gegen `var'_p50	= pctile(`var'), by(ict) p(50)
	qui gen `var'_hisec	= `var' >= `var'_p50 if `var'<.
	drop `var'_p50

	* save
	merge 1:1 ape using "output/sec_stock", nogen
	rename ape apet
	save "output/sec_stock", replace

}

*===============================================================================
* SUBSIDIARIES
*===============================================================================
{

*** Construct US subsidiary dummy in each yearly file of LIFI

forvalues yr = 1997(1)2005 {

	* open yearly LIFI file
	use "rawdata/raw/lifi/lifi`yr'lar", clear

	* bring sirtg info
	joinby sirtg using "rawdata/raw/lifi/lifi`yr'tg"

	* sirtg country
	destring natact paystg, replace

	* foreign groups
		// 1 groupe privé français
		// 2 groupe public
		// 4 groupe étranger
		// 0 entreprises du contour élargi ou de la mouvance (correspond à CONTOUR = E ou M)
		// blanc entreprises isolées

	* US firms
		// paystg is country of tete de groupe
		// 404 is US
	
	gegen usa = max(paystg==404), by(sirlifi)
	
	bys sirlifi: keep if _n==1
	rename sirlifi sir
	keep sir usa

// 	save "output/lifi`yr'", replace
	tempfile lifi`yr'
	save `lifi`yr''

}


*** Merge all years in 1 file

	* firm-year level
	clear
	gen year = .
	forvalues yr = 1997(1)2005 {
		local n0 = _N
		append using `lifi`yr''
		replace year = `yr' in `=`n0'+1'/L
	}
		
	* balance the panel 1997-2005
	tempfile lifi_panel
	save `lifi_panel', replace
	keep sir
	bys sir: keep if _n==1
	expand 9
	bys sir: gen year = 1996+_n
	merge 1:1 sir year using `lifi_panel', nogen
	
	* lifi has good coverage starting in 1999 -> backfill before 1999
	gen usa_99 = usa if year<=1999
	gegen usa_99max = max(usa_99), by(sir)
	replace usa = usa_99max if year<=1998
	drop usa_99 usa_99max
	
	save "output/lifi", replace

}


*===============================================================================
* FIRM EQUITY
*===============================================================================
{

* Append Ficus-Fare files
clear
gen year = .
forvalues t = 1994(1)2006 {
	local n0 = _N
	append using "${ficus_fare}/ficus-fare`t'", keep(siren capisoc tot_act tactint ape stat_cj)
	replace year = `t' in `=`n0'+1'/L
}

* ICT
rename ape sec
gen ict = inlist(substr(sec,1,2),"72") | inlist(substr(sec,1,3),"300","321","322","323","332","333","642") | inlist(sec,"313Z","516G","518G","518J","713E") if sec~=""
drop if ict==.

* Deal with negative capital
replace capisoc = 0 if capisoc<0

save "output/equity-issuance", replace

}


*===============================================================================
* FIRM OUTCOMES
*===============================================================================
{

*** Firms during the boom

* append tax files during the boom
clear
forvalues t = 1998(1)2001 {
	display "---------     `t'      ----------"
	append using "${ficus_fare}/ficus-fare`t'", keep(siren year ape emp tot_act ca va ebe resultat stat_cj)
}

* drop if missing values
drop if ca+va+ebe+resultat+emp==.
* drop if zero employment
drop if emp<=0
* keep corporations
keep if substr(stat_cj,1,1)=="5"
drop stat_cj

* rename variables
foreach var in year ape emp tot_act ca va ebe resultat {
	rename `var' `var'0
}
rename tot_act0 ta0
rename ca0 sal0
rename resultat0 netincome0

* save
save "output/firm_outcome", replace


*** Outcomes in 2005-10-15

* append tax files
use siren year emp tot_act ca va ebe resultat using "${ficus_fare}/ficus-fare2005", clear

* reshape wide
rename tot_act ta
rename ca sal
rename resultat netincome
foreach var in emp ta sal va ebe netincome {
	rename `var' `var'_
}
reshape wide *_, i(siren) j(year)

* merge with data during boom
merge 1:m siren using "output/firm_outcome", keep(2 3) nogen update

* reshape long
reshape long emp_ ta_ sal_ va_ ebe_ netincome_, i(siren year0) j(year)
foreach var in emp ta sal va ebe netincome {
	rename `var'_ `var'
}

* winsorize a few negative values
foreach var in ta0 sal0 emp0 ta sal emp {
	replace `var' = 0 if `var'<0
}

* save
save "output/firm_outcome", replace

}




cd "${dir}"

*===============================================================================
* MACROS FOR TABLE EDITING
*===============================================================================
{

global feBase "id ict0yr sxyr age0yr occ0yr yr0yr"  	
global varBase "$feBase coh occ0 per apet0yr dep0yr ict0 yr0 logwage ict0boom_3 ict0boom_4"
global fe_list ///
		estfe . est*, labels( ///
		id 	"\\[-1.8ex]\hline\addlinespace\textit{Fixed Effects} \\ \hspace{1.5em}Worker" ///
		sxyr 			"\hspace{1.5em}Sex\(\times\)Year" ///
		age0yr 			"\hspace{1.5em}Age\(_{0}\)\(\times\)Year" ///	
		yr0yr 			"\hspace{1.5em}Year\(_{0}\)\(\times\)Year" ///	
		cohyr 			"\hspace{1.5em}Cohort\(\times\)Year" ///			
		ict0yr 			"\hspace{1.5em}ICT\(_{0}\)\(\times\)Year" ///
		occ0yr 			"\hspace{1.5em}Occupation\(_{0}\)\(\times\)Year" ///	
		pfirm10yr 		"\hspace{1.5em}Pseudo firm\(_{0}\)\(\times\)Year" ///	
		pfirm20yr 		"\hspace{1.5em}Sales growth (\(t \rightarrow t+5\)) quintile\(\times\)Year" ///	
		pfirm1yr 		"\hspace{1.5em}Pseudo firm\(_{t}\)\(\times\)Year" ///			
		w0qyr 			"\hspace{1.5em}Entry wage quintile\(\times\)Year" ///	
		dep0yr 			"\hspace{1.5em}Commuting zone\(_{0}\)\(\times\)Year" ///	
		apet0yr0yr 		"\hspace{1.5em}Industry\(_{0}\)\(\times\)Year" ///		
		dep0yr0yr 		"\hspace{1.5em}Commuting zone\(_{0}\)\(\times\)Year" ///	
		apet0yr 		"\hspace{1.5em}Industry\(_{0}\)\(\times\)Year" ///	
		ict0preboom_1 	"\hspace{1.5em}ICT\(_{0}\)\(\times\)Boom\(\times\)2006-10" ///	
		ict0preboom_2 	"\hspace{1.5em}ICT\(_{0}\)\(\times\)Boom\(\times\)2001-15" ///
		year			"\\[-1.8ex]\hline\addlinespace\textit{Fixed Effects} \\ \hspace{1.5em} Year" ///
		dept			"\hspace{1.5em} Commuting zone")

global clean_table ///		
	replace cells(b(fmt(%8.3f)star) se(fmt(%8.3f)par)) starlevels(* 0.1 ** 0.05 *** 0.01) ///
	varwidth(80) nolines  posthead(\midrule) postfoot(`"\bottomrule"') label ///
	fragment mlabels(none) collabels(none) booktab ///	
	stats(N_true, fmt(%12.0fc ) label("\addlinespace Observations")) nonotes  ///	
	subs("Post_t" "Post$_t$") 	

global clean_table_panelformat ///			
	replace cells(b(fmt(%8.3f)star) se(fmt(%8.3f)par)) starlevels(* 0.1 ** 0.05 *** 0.01)  ///
	varwidth(80) nolines label ///
	mgroups(\vspace{-.3cm})  ///
	fragment mlabels(none) collabels(none) booktab ///
	nonotes nonumber ///
	stats(N_true, fmt(%12.0fc ) label("\\\hline\addlinespace Observations"))  ///	
	subs("Post_t" "Post$_t$") 	
	
global clean_table_panelFE ///
	replace cells(b(fmt(%8.3f)star) se(fmt(%8.3f)par)) starlevels(* 0.1 ** 0.05 *** 0.01) ///
	varwidth(80) nolines  postfoot(`"\bottomrule"') label ///
	fragment mlabels(none) collabels(none) booktab ///	
	subs("Post_t" "Post$_t$") ///
	mgroups(\vspace{-.3cm}) nonumber ///
	stats(N_true pval, fmt(%12.0fc %12.2g ) label("\addlinespace Observations" "\addlinespace\\[-1.8ex]\hline p-value High minus Low"))
		
	
*** True nb of obs with reghdfe
global trueobs ///
	quiet estadd scalar N_true = e(N) + e(num_singletons)

}
*

*===============================================================================
* SHARED HELPERS
*===============================================================================

cap program drop init_jobloss_interactions
program define init_jobloss_interactions
	syntax, BASELABEL(string)
	forvalues t = 3/4 {
		capture drop mob_`t' mobboom_`t' mobict0_`t' mobict0boom_`t'
		gen mob_`t' = .
		gen mobboom_`t' = .
		gen mobict0_`t' = .
		gen mobict0boom_`t' = .
		if `t'==3 {
			local period = "[06--10]"
		}
		if `t'==4 {
			local period = "[11--15]"
		}
		label var mob_`t' "`baselabel'\(\times\)`period'"
		label var mobboom_`t' "`baselabel'\(\times\)Boom\(\times\)`period'"
		label var mobict0_`t' "`baselabel'\(\times\)ICT\(_{0}\)\(\times\)`period'"
		label var mobict0boom_`t' "`baselabel'\(\times\)ICT\(_{0}\)\(\times\)Boom\(\times\)`period'"
	}
end

*===============================================================================
* CACHED SAMPLE FOR REPEATED BOOM/POST REGRESSIONS
*===============================================================================
{
	use if inlist(occ0,"23","37","38") & inlist(coh,"boom","post") ///
		using "output/workingsample", clear
	save "output/workingsample_boompost_skilled", replace
}


*===============================================================================
* TABLE 1: WAGE REGRESSIONS
*===============================================================================
{

use $varBase ict0boomwpre_2 pfirm10yr pfirm20yr w0qyr ///
	using "output/workingsample_boompost_skilled", clear

eststo clear

qui eststo: reghdfe logwage ict0boomwpre_2 ict0boom_*, a(ict0yr sxyr age0yr occ0yr yr0yr) cl(id)
$trueobs
qui foreach fe in " " pfirm10yr pfirm20yr "pfirm20yr w0qyr" "pfirm20yr w0qyr dep0yr"{
	eststo:	reghdfe logwage ict0boom_*, a($feBase `fe') cl(id)
	$trueobs
}

* Duration of exposure
foreach x in 3 4 {
	gen ict0_timeexpo_`x' = ict0 * max(2002-yr0,0) * (per==`x')
}
lab var ict0_timeexpo_3 "ICT\(_{0}\)\(\times\)Time of exposure\(\times\)[06--10]" 
lab var ict0_timeexpo_4 "ICT\(_{0}\)\(\times\)Time of exposure\(\times\)[11--15]" 
qui eststo, title(" "): reghdfe logwage ict0_timeexpo_*, a($feBase) cl(id)
$trueobs

lab var ict0boomwpre_2 "\addlinespace ICT\(_{0}\)\(\times\)Boom\(\times\)[03--05]"

$fe_list
esttab using "results/wage.tex", ///
drop(_cons) width(50) ///
$clean_table indicate( `r(indicate_fe)', labels($\checkmark$ --- ))

}
*

*===============================================================================
* TABLE 2: CAPITAL AVAILABILITY
*===============================================================================
{

use $varBase r99_hi gcap_hi ///
	using "output/workingsample_boompost_skilled", clear

* Fixed effects
gegen apet0yr0yr 	= group(apet0yr yr0)
gegen dep0yr0yr 	= group(dep0yr yr0)

* Interaction terms
forvalues t = 3(1)4 {
	gen equi_`t' = .
	gen equiboom_`t' = .
	gen equiict0_`t' = .
	gen equiict0boom_`t' = .
}

* Labels
forval t = 3/4{
	if `t'==3{
		local text = "[06-10]"
	}
	if `t'==4{
		local text = "[11-15]"
	}	
	cap label var equiict0boom_`t' 	"ICT\(_{0}\)\(\times\)Capital availability\(\times\)Boom\(\times\)`text'"
}

* Regressions
eststo clear
qui foreach x in r99 gcap {
	display "`x'"
	forvalues t = 3(1)4 {
		replace equi_`t' = `x'_hi * (per==`t')
		replace equiboom_`t' = `x'_hi * (coh=="boom") * (per==`t')
		replace equiict0_`t' = `x'_hi * ict0 * (per==`t')
		replace equiict0boom_`t' = `x'_hi * ict0 * (coh=="boom") * (per==`t')
	}
	
	* baseline
	eststo: reghdfe logwage ict0boom_* equiict0boom_* equiict0_* equi_* equiboom_*, a($feBase) cl(id)
	$trueobs
	
	if "`x'" ~= "r99" {
		* sec4-coh-yr FE
		eststo: reghdfe logwage  equiict0boom_* equiict0_* equi_* equiboom_*, a($feBase apet0yr0yr) cl(id)
		$trueobs
		
		* dep-coh-yr FE
		eststo: reghdfe logwage ict0boom_* equiict0boom_* equiict0_* equi_* equiboom_*, a($feBase dep0yr0yr) cl(id)
		$trueobs

	}

}

$fe_list
esttab  using "results/capital.tex", ///
keep(ict0boom_*  equiict0boom_*) width(100) ///
$clean_table indicate( `r(indicate_fe)', labels($\checkmark$ --- ))

}
*

*===============================================================================
* TABLE 3: STEM OCCUPATIONS
*===============================================================================
{

use $varBase ict0preboom_* ///
	stem_sec_avg_hi pfirm20yr w0qyr ///
	using "output/workingsample", clear

* Industry-level STEM intensity
rename stem_sec_avg_hi stemsec

* Worker-level STEM occupation
gen stem = occ0=="38"

* Step 1: Save the p-value for each triple diff
foreach STEM in stemsec stem {
	di in red "`STEM'"
	gen STEM = `STEM'
	
	* Interaction terms
	foreach i in 3 4 {
		gen STEM_ict0preboom_`i' = ict0preboom_`i' * STEM
	}
	
	* Interactions with fixed effects
	foreach fe in $feBase {
		gegen X1_`fe' = group(`fe' STEM)
	}
	foreach fe in pfirm20yr w0qyr dep0yr {
		gegen X_`fe' = group(`fe' STEM)
	}
	
	* Triple-diff regressions
	qui reghdfe logwage STEM_* ict0preboom_*, a(X1_*) cl(id)
	gen double p`STEM'_x1 = 2*ttail(e(df_r), abs(_b[STEM_ict0preboom_4]/_se[STEM_ict0preboom_4]))
	
	qui reghdfe logwage STEM_* ict0preboom_*, a(X1_* X_pfirm20yr X_w0qyr X_dep0yr) cl(id)
	gen double p`STEM'_x2 = 2*ttail(e(df_r), abs(_b[STEM_ict0preboom_4]/_se[STEM_ict0preboom_4]))
	
	drop STEM* X1_* X_*
}

* Step 2: Split-sample regressions
foreach x in 0  1{ //
	eststo clear

	foreach STEM in stemsec stem {
		di in red "`STEM' == `x'"
		preserve
			keep if `STEM'==`x'
			
			qui eststo: reghdfe logwage ict0preboom_*, a($feBase) cl(id)
			$trueobs
			quiet estadd scalar pval = p`STEM'_x1
			
			qui eststo: reghdfe logwage ict0preboom_*, a($feBase pfirm20yr w0qyr dep0yr) cl(id)
			$trueobs
			quiet estadd scalar pval = p`STEM'_x2
			
		restore
	}
	
	if `x'==1 {
		esttab  using "results/stem_1.tex", ///
		$clean_table_panelformat keep(ict0preboom_*)
	}
	
	if `x'==0 {
		$fe_list 
		esttab  using "results/stem_0.tex", ///	
		$clean_table_panelFE keep(ict0preboom_*) ///
		indicate( `r(indicate_fe)', labels($\checkmark$ --- ))

	}
}

}
*

*===============================================================================
* TABLE 4: TECHNOLOGICAL OBSOLESCENCE
*===============================================================================
{

use $varBase ict0preboom_* apet0 naf32 sir0 ///
	if inlist(coh,"pre","boom","post") ///
	using "output/workingsample", clear

** Innovation characteristics
rename apet0 apet
merge m:1 apet using "output/innovation_characteristics_naf4", keep(1 3) nogen 

* Patent obsolescence
rename Dage minusDagepat	// already calculated with a minus previously
rename Dsdcit Dsdcit
rename Dretech_stock Dretech

* bring llm code 
rename sir0 sir 
merge m:1 sir using "output/sir_llm",nogen keep(3) 

* bring change in worker demographic 
merge m:1 llm using "output/employment_age_h_llm",nogen keep(3)

* Workforce age structure
gen minusdagework 	= -dMedageh_20032008
gen younggrowth 	= dlog_h_age30_20032008

* Step 1: Save the p-value for each triple diff
foreach var in minusDagepat Dsdcit Dretech minusdagework younggrowth {
	di "`var'"
	
	* High minus Low
	gquantiles EXPO = `var', xtile nq(2) by(naf32)
	replace EXPO	= EXPO-1
	
	* Interaction terms
	foreach i in 3 4 {
		gen EXPO_ict0preboom_`i' = ict0preboom_`i' * EXPO
	}
	
	* Interactions with fixed effects
	foreach fe in $feBase {
		gegen X1_`fe' = group(`fe' EXPO)
	}
	
	* Triple-diff regression
	reghdfe logwage EXPO_* ict0preboom_*, a(X1_*) cl(id)
	gen double p`var'_x1 = 2*ttail(e(df_r), abs(_b[EXPO_ict0preboom_4]/_se[EXPO_ict0preboom_4]))
	drop EXPO* X1_*
}

* Step 2: Split-sample regressions
foreach x in 0  1{ //
	eststo clear

	foreach var in minusDagepat Dsdcit Dretech minusdagework younggrowth{
		preserve
			
			* High versus Low
			gquantiles EXPO = `var', xtile nq(2) by(naf32)
			replace EXPO	= EXPO-1
			keep if EXPO==`x'
			
			qui eststo: reghdfe logwage ict0preboom_*, a($feBase) cl(id)
			$trueobs
			quiet estadd scalar pval = p`var'_x1
			
		restore
	}
	
	if `x'==1 {
		esttab  using "results/obsolescence_1.tex", ///
		$clean_table_panelformat keep(ict0preboom_*)
	}
	
	if `x'==0 {
		$fe_list 
		esttab  using "results/obsolescence_0.tex", ///	
		$clean_table_panelFE keep(ict0preboom_*) ///
		indicate( `r(indicate_fe)', labels($\checkmark$ --- ))
	}
}

}
*

*===============================================================================
* TABLE 5: CAPITAL FLOW BY EXPOSURE
*===============================================================================
{

use "output/gcap_secdep" if year>1997, clear
merge m:1 apet year using "output/sec_skill", keep(3) nogen
merge m:1 apet using "output/sec_skill_average", keep(3) nogen
merge m:1 apet using "output/innovation_characteristics_naf4", keep(1 3) nogen
gen ict = inlist(substr(apet,1,2),"72") | inlist(substr(apet,1,3),"300","321","322","323","332","333","642") | inlist(apet,"313Z","516G","518G","518J","713E") if apet~=""

foreach var of varlist stem_sec_avg Dage Dsdcit Dretech_stock {
	fasterxtile `var'_hi = `var', nq(2) by(ict)
	replace `var'_hi = `var'_hi-1
	drop `var'
	rename `var'_hi `var'
}

gen expo = .
gen expo_ict = .
lab var ict "\addlinespace ICT"
lab var expo "Exposure"
lab var expo_ict "ICT $\times$ Exposure"

eststo clear
qui foreach var of varlist stem_sec_avg D* {
	di in red "`var'"
	replace expo = `var'
	replace expo_ict = `var'*ict
	eststo: reghdfe gcap_secdep ict expo expo_ict [aw=ngcap_secdep], a(year dept) cluster(apet dept)
	$trueobs
}

$fe_list
esttab  using "results/gcap_expo.tex", ///
drop(_cons) ///
$clean_table indicate( `r(indicate_fe)', labels($\checkmark$ --- ))

}
*

*===============================================================================
* TABLE 6: FIRM OUTCOME
*===============================================================================
{

* panel at the firm x year0 x year level, with firm characteristics in year0 and year, used to calculate growth rates
use "output/firm_outcome", clear

sort siren year year0
by siren year: keep if _n==_N

* growth rates
foreach var in sal {
	gen log`var'0 = log(`var'0)
	gen g`var' = (`var'-`var'0)/(.5*(`var'+`var'0))
	gen w`var' = .5*(`var'+`var'0)
	replace w`var' = .5*(0+`var'0) if `var'==.
	gegen wi`var' = sum(w`var'), by(ape0 year)
	replace wi`var' = w`var'/wi`var'
}

* ict
rename ape0 sec
gen ict = inlist(substr(sec,1,2),"72") | inlist(substr(sec,1,3),"300","321","322","323","332","333","642") | inlist(sec,"313Z","516G","518G","518J","713E") if sec~=""
label var ict "\addlinespace ICT"

* starting year dummies
forvalues t = 1999(1)2001 {
	gen year0_`t' = year0==`t'
	label var year0_`t' "`t'"
}

* outcomes at 2005 horizon
qui keep if year==2005 & emp0>=5 & logsal0<.

* Regressions
label var ict "\addlinespace ICT"

eststo clear
qui eststo: reg gsal ict year0_* logsal0, cl(sec)
qui foreach q in 10 25 50 75 90 {
	di in red  "   p`q'"
	eststo: qreg gsal ict year0_* logsal0, q(.`q')
}

esttab using "results/firm_gsal.tex", ///
keep(ict) ///
replace cells(b(fmt(%8.3f)star) se(fmt(%8.3f)par)) starlevels(* 0.1 ** 0.05 *** 0.01) ///
varwidth(50) nolines  posthead(\midrule) label ///
fragment mlabels(none) collabels(none) booktab ///	
stats(N, fmt(%12.0fc ) label("\\[-1.8ex]\hline\addlinespace Observations")) nonotes  ///	
subs("Post_t" "Post$_t$") 


} 
*

*===============================================================================
* TABLE 7: QUANTILE WAGE REGRESSIONS
*===============================================================================
{

use id sx age0 per coh yr0 ict0 occ0 ict0boom_* year logwage using "output/workingsample_boompost_skilled", clear

capture drop _*
gen age0sq	= age0^2
foreach t in 2 3 4 {
	gen _ict0_`t' = ict0*(per==`t')
	gen _sx_`t' = (sx=="1")*(per==`t')
	gen _sxboom_`t' = (sx=="1")*(coh=="boom")*(per==`t')
	gen _age0_`t' = age0*(per==`t')
	gen _age0boom_`t' = age0*(coh=="boom")*(per==`t')
	gen _age0sq_`t' = age0sq*(per==`t')
	gen _age0sqboom_`t' = age0sq*(coh=="boom")*(per==`t')
	gen _eng_`t' = (occ0=="38")*(per==`t')
	gen _engboom_`t' = (occ0=="38")*(coh=="boom")*(per==`t')
	foreach y0 in 1998 1999 2000 2001 2003 2004 2005 {
		gen _`y0'_`t' = (yr0==`y0')*(per==`t')
	}
}

eststo clear
foreach q in 10 25 50 75 90 {
	display "`q'"
	qui eststo: xtqreg logwage ict0boom_* _*, i(id) q(.`q')
}

lab var ict0boom_3 "\addlinespace ICT\(_{0}\)\(\times\)Boom\(\times\)[06-10]"
esttab  using "results/quantile.tex", ///
keep(ict0boom_* ) ///
replace cells(b(fmt(%8.3f)star) se(fmt(%8.3f)par)) starlevels(* 0.1 ** 0.05 *** 0.01) ///
width(50) nolines  posthead(\midrule) label varwidth(60) ///
fragment mlabels(none) collabels(none) booktab ///	
stats(N, fmt(%12.0fc ) label("\\[-1.8ex]\hline\addlinespace Observations")) nonotes  ///	
subs("Post_t" "Post$_t$") 	

}
*

*===============================================================================
* TABLE 8: JOB LOSSES
*===============================================================================
{

use $varBase year term_*  ///
	using "output/workingsample_boompost_skilled", clear

* keep 1 obs per worker
bysort id (year): keep if _n==1

* rhs variables
gen ict0_boom = ict0 * (coh=="boom")
label var ict0 "ICT\(_{0}\)"
label var ict0_boom "\addlinespace ICT\(_{0}\) x Boom cohort"
foreach fe in sx age0 occ0 yr0{
	gegen `fe'coh = group(`fe' coh)
}
global fe "sxcoh age0coh occ0coh yr0coh"

*** Regressions full sample
eststo clear
qui foreach x in all demp dwage either {
	display in red "`x'"
	eststo: reghdfe term_`x'_4 ict0_boom ict0, a($fe) vce(r)
	$trueobs
}
estfe . est*, labels( ///
	sxcoh 	"\\[-1.8ex]\hline\addlinespace\textit{Fixed Effects} \\ \hspace{1.5em}Sex" ///
	age0coh 		"\hspace{1.5em}Age\(_{0}\)" ///	
	yr0coh 			"\hspace{1.5em}Year\(_{0}\)" ///	
	occ0coh			"\hspace{1.5em}Occupation\(_{0}\)")	
esttab using "results/jobloss.tex", ///
keep(ict0_boom) width(50) ///
$clean_table indicate( `r(indicate_fe)', labels($\checkmark$ --- ))

}
*

*===============================================================================
* TABLE 9: CONTROLLING FOR JOB LOSSES
*===============================================================================
{

use $varBase term_*  ///
	using "output/workingsample_boompost_skilled", clear

	* Interaction terms
	qui init_jobloss_interactions, baselabel("Job termination")

* Baseline without controlling
eststo clear
qui eststo: reghdfe logwage ict0boom_*, a($feBase) cl(id)
$trueobs

* Controlling with the different proxies of job loss
qui foreach x in demp dwage either {
	local var term_`x'_4
	di in red "`var'"
	forvalues t = 3(1)4 {
		replace mob_`t' = `var' * (per==`t')
	}
	eststo: reghdfe logwage ict0boom_* mob_*, a($feBase) cl(id)
	$trueobs
}

$fe_list
esttab using "results/wage-jobloss.tex", ///
keep(ict0boom_* mob_3 mob_4) width(50) ///
$clean_table indicate( `r(indicate_fe)', labels($\checkmark$ --- ))


}
*

*===============================================================================
* TABLE B.3: RETURN TO EXPERIENCE
*===============================================================================
{

use logwage nni sx occup0 apet0 coh year yr0 age ///
	if inlist(occup0,"23","37","38") & inlist(coh,"boom","post") & year<=yr0+10 ///
	using "output/dads_panel_entrants", clear

merge m:1 year using "${dir}/rawdata/inflation", keep(1 3) nogen
gen logwagereal = logwage + log(euro2000)
label var age "\\[-1.8ex] Age"
gegen id = group(nni)

eststo clear
qui eststo: reghdfe logwagereal age, a(id) cl(id)
$trueobs
qui eststo: reghdfe logwagereal age, a(year sx occup0 apet0) cl(id)
$trueobs

estfe . est*, labels( ///
	id 	"\\[-1.8ex]\hline\addlinespace\textit{Fixed Effects} \\ \hspace{1.5em}Worker" ///
	year	 		"\hspace{1.5em}Year" ///	
	sx				"\hspace{1.5em}Sex" ///
	apet0 			"\hspace{1.5em}Industry\(_{0}\)" ///	
	occup0			"\hspace{1.5em}Occupation\(_{0}\)")	
esttab using "results/experience.tex", ///
keep(age) width(50) ///
$clean_table indicate( `r(indicate_fe)', labels($\checkmark$ --- ))


}
*

*===============================================================================
* TABLE B.4: VINTAGE EFFECTS
*===============================================================================
{

use $varBase per ict0 yr0 ///
	if inlist(occ0,"23","37","38") & yr0>=1997 & yr0<=2005 ///
	using "output/workingsample", clear

* Interactions by year0
forvalues c = 1997(1)2004 {
	foreach x in 3 4 {
		gen ict0_yr0`c'_`x' = ict0 * (yr0==`c') * (per==`x')
	}
	lab var ict0_yr0`c'_4 "ICT\(_{0}\)\(\times\)`c' cohort\(\times\)[11--15]"
}
lab var ict0_yr01997_4 "\addlinespace ICT\(_{0}\)\(\times\)1997 cohort\(\times\)[11--15]"

* Duration of exposure
foreach x in 3 4 {
	gen ict0_timeexpo_`x' = ict0 * (2005-yr0) * (per==`x')
}
lab var ict0_timeexpo_4 "ICT\(_{0}\)\(\times\)Time of exposure\(\times\)[11--15]"

* Regressions
eststo clear

qui eststo: reghdfe logwage ict0_yr0*_3 ict0_yr0*_4, a(id ict0yr sxyr age0yr occ0yr yr0yr) cl(id)
$trueobs

$fe_list
esttab using "results/vintage.tex", ///
drop(_cons *_3) ///
$clean_table indicate( `r(indicate_fe)', labels($\checkmark$ --- ))

}
*

*===============================================================================
* FIGURE B.1: CAPITAL FLOW AND LABOR FLOW
*===============================================================================
{

use "output/K", clear
replace dep = substr(dep,1,2) if length(dep)==3 & substr(dep,3,1)=="0"
replace dep = "9A" if dep=="971"
replace dep = "9B" if dep=="972"
replace dep = "9C" if dep=="973"
replace dep = "9D" if dep=="974"
merge 1:1 apet dep year using "output/L", nogen keep(3)

gegen apet_dep = group(apet dep)
xtset apet_dep year
foreach var in K L {
	gen w`var' = `var'+L1.`var'
	gen g`var' = (`var'-L1.`var')/(.5*w`var')
}

gen ict = inlist(substr(apet,1,2),"72") | inlist(substr(apet,1,3),"300","321","322","323","332","333","642") | inlist(apet,"313Z","516G","518G","518J","713E") if apet~=""
drop if ict==.
gen gK_ict = gK * ict
lab var gK "\\[-1.8ex] Capital flow"
lab var gK_ict "Capital flow\(\times\)ICT"
save "output/kl_flows_prepared", replace

* bin scatter
preserve
	qui reghdfe gL [aw=wL], a(apet dep year) resid
	predict gL_res, res
	qui reghdfe gK [aw=wK], a(apet dep year) resid
	predict gK_res, res
	gquantiles gK_20 = gK_res [aw=wL], nq(20) xtile
	gcollapse (mean) gL_res gK_res [aw=wL], by(gK_20)
	capture drop fitted
	reg gL_res gK_res, r
	predict fitted, xb
	qui sum gK_res
	local xt = r(max)
	local yt = _b[_cons]+r(max)*_b[gK_res]+0.002
	local tstat = round(_b[gK_res]/_se[gK_res],.3)
	di `xt'
	di `yt'
	di `tstat'
	tw 	(sc gL_res gK_res) (line fitted gK_res), ///
		text(`yt' `xt' "t=`tstat'", color(maroon)) ///
		xtitle("Capital flow growth (residual)") ylabel(,nogrid angle(0)) ytitle("Labor flow growth (residual)") ///
		legend(off) graphregion(fcolor(white) lcolor(white) ifcolor(white) ilcolor(white))
	graph export "results/corr-flow.pdf", as(pdf) replace
	graph close
restore

}



*===============================================================================
* TABLE B.5: CAPITAL FLOW AND LABOR FLOW
*===============================================================================
{

use "output/kl_flows_prepared", clear

eststo clear
eststo: reghdfe gL gK, a(year apet dep) cl(apet)
$trueobs
eststo: reghdfe gL gK gK_ict, a(year apet dep) cl(apet)
$trueobs

estfe . est*, labels( ///
	year 		"\\[-1.8ex]\hline\addlinespace\textit{Fixed Effects} \\ \hspace{1.5em}Year" ///
	apet 		"\hspace{1.5em}Industry" ///	
	dep 		"\hspace{1.5em}Communiting zone" ///	
	occ0coh		"\hspace{1.5em}Occupation\(_{0}\)")	
esttab using "results/corr_flow.tex", ///
keep(gK gK_ict) width(50) ///
$clean_table indicate( `r(indicate_fe)', labels($\checkmark$ --- ))

}
*

*===============================================================================
* TABLE B.6: ROBUSTNESS
*===============================================================================
{

use $varBase pfirm10yr naf32 pfirm1yr ///
	learnings_ceo learnings_all ///
	using "output/workingsample_boompost_skilled", clear

eststo clear
qui eststo: reghdfe logwage ict0boom_*, a($feBase) cl(id)
$trueobs
qui eststo: reghdfe logwage ict0boom_*, a($feBase pfirm1yr) cl(id)
$trueobs
qui eststo: reghdfe logwage ict0boom_*, a($feBase pfirm1yr pfirm10yr) cl(id)
$trueobs
qui eststo: reghdfe logwage ict0boom_* if naf32~="JA", a($feBase) cl(id)
$trueobs
qui eststo: reghdfe learnings_ceo ict0boom_*, a($feBase) cl(id)
$trueobs
qui eststo: reghdfe learnings_all ict0boom_*, a($feBase) cl(id)
$trueobs

$fe_list
esttab using "results/robustness.tex", ///
drop(_cons) width(50) ///
$clean_table indicate( `r(indicate_fe)', labels($\checkmark$ --- ))


*** Exclude sectors one by one

use $varBase naf32 if inlist(occ0,"23","37","38") & inlist(coh,"boom","post") ///
	using "output/workingsample_boompost_skilled", clear

* Baseline
qui reghdfe logwage ict0boom_*, a($feBase ) cl(id)
qui gen beta = _b[ict0boom_4] if _n==1
qui gen tstat = _b[ict0boom_4]/_se[ict0boom_4] if _n==1

* Exclude control sectors one-by-one
local index = 2
glevelsof naf32, local(sectors)
foreach sector of local sectors {
	di "`sector'"
	if inlist("`sector'", "51", "DL", "IA", "KA")==0 {
		qui reghdfe logwage ict0boom_* if naf32~="`sector'", a($feBase ) cl(id)
		qui replace beta = _b[ict0boom_4] if _n==`index'
		qui replace tstat = _b[ict0boom_4]/_se[ict0boom_4] if _n==`index'
	local index = `index'+1
	}
}

* Plot distribution of coefs and t-stats
gen zero_main = 0 if _n==1
gen zero_excl = 0 if _n>1
lab var zero_main "Baseline estimate"
lab var zero_excl "Excluding each two-digit sector"
tw sc zero_main zero_excl beta, title("point estimate") msymbol(dot plus) msize(large small) xlabel(-.1(.01)-.06) xtitle("") ytitle("") ylabel(none) legend(off) graphregion(fcolor(white) lcolor(white) ifcolor(white) ilcolor(white))
graph save "output/plot_beta.gph", replace
tw sc zero_main zero_excl tstat, title("t-stat") msymbol(dot plus) msize(large small) xlabel(-5(.2)-3) xtitle("") ytitle("") ylabel(none) legend(region(lwidth(none))) graphregion(fcolor(white) lcolor(white) ifcolor(white) ilcolor(white))
graph save "output/plot_t.gph", replace
graph combine "output/plot_beta.gph" "output/plot_t.gph", col(1) graphregion(fcolor(white) lcolor(white) ifcolor(white) ilcolor(white))
graph export "results/exclude_sectors.pdf", as(pdf) replace
graph close

}
*

*===============================================================================
* TABLE B.7: CUMULATIVE EARNINGS
*===============================================================================
{

use occup0 coh year0 nni ict0 age0 sx ///
	using "output/dads_panel_entrants", clear

	rename occup0 occ0
	keep if inlist(occ0,"23","37","38")
	keep if inlist(coh,"boom")

* cumulative earnings at worker-year level (with no gap years in the panel)
rename year0 yr0
keep nni coh ict0 yr0 age0 sx occ0
bys nni : keep if _n==1
merge 1:m nni using "output/cumulative_earnings", nogen keep(3) keepusing(year pv* )

* log of PV of earnings from entry up to current year
foreach x in 0 1 2 3 {
	gen lpv`x' = log(pv`x')
}

* interactions
forvalues y = 1998(1)2015 {
	qui gen ict0_`y' = ict0 * (year==`y')
	label var ict0_`y' "ICT\(_{0}\)\(\times\)`y'"
}
lab var ict0_2001 "\\[-1.8ex] ICT\(_{0}\)\(\times\)2001"
gegen id = group(nni)
foreach fe in sx age0 yr0 occ0{
	gegen `fe'yr = group(`fe' year)
}

* regressions
eststo clear
qui foreach Y in lpv0 pv0 pv1 pv2 pv3{
	eststo: reghdfe `Y' ict0_*, a(sxyr age0yr occ0yr yr0yr) cl(id)
	$trueobs
}

estfe . est*, labels( ///
	sxyr 	"\\[-1.8ex]\hline\addlinespace\textit{Fixed Effects} \\ \hspace{1.5em}Sex\(\times\)Year" ///
	age0yr 			"\hspace{1.5em}Age\(_{0}\)\(\times\)Year" ///	
	yr0yr 			"\hspace{1.5em}Year\(_{0}\)\(\times\)Year" ///	
	occ0yr 			"\hspace{1.5em}Occupation\(_{0}\)\(\times\)Year" ///	
	dept			"\hspace{1.5em} Commuting zone")

esttab using "results/cumulative.tex", ///
keep(ict0_2001 ict0_2005 ict0_2010 ict0_2015) ///
replace cells(b(fmt(%8.2gc)star) se(fmt(%8.2gc)par)) starlevels(* 0.1 ** 0.05 *** 0.01) ///
	varwidth(40) nolines  posthead(\midrule) postfoot(`"\bottomrule"') label ///
	fragment mlabels(none) collabels(none) booktab ///	
	stats(N_true, fmt(%12.0fc ) label("\addlinespace Observations")) nonotes  ///	
	subs("Post_t" "Post$_t$") indicate( `r(indicate_fe)', labels($\checkmark$ --- ))

}
*

*===============================================================================
* TABLE B.8: TOTAL EARNINGS
*===============================================================================
{

use nni year sx age0 yr0 occ0 ict0 coh ///
	using "output/workingsample_boompost_skilled", clear

* total earnings at worker-year level (with no gap years in the panel)
bysort nni (year): keep if _n==1
drop year
merge 1:m nni using "output/cumulative_earnings", nogen keep(3) keepusing(year earnings*)

* periods
gen per = 1 if year>=1998 & year<=2001
replace per = 2 if year>=2002 & year<=2005
replace per = 3 if year>=2006 & year<=2010
replace per = 4 if year>=2011 & year<=2015

* interactions
forvalues t = 3(1)4 {
	gen ict0boom_`t' = (coh=="boom") * (per==`t') * ict0
}
lab var ict0boom_3 "\\[-1.8ex] ICT\(_{0}\)\(\times\)Boom\(\times\)[06--10]"
lab var ict0boom_4 "ICT\(_{0}\)\(\times\)Boom\(\times\)[11--15]"

* fixed effects
gegen id = group(nni)
foreach fe in sx age0 yr0 occ0 ict0{
	gegen `fe'yr = group(`fe' year)
}

* regressions
eststo clear
qui forval i = 0/3{
	gen learnings`i' = log(earnings`i')
	eststo: reghdfe learnings`i' ict0boom_*, a($feBase) cl(id)
	$trueobs
}

$fe_list
esttab using "results/total_earnings.tex", ///
drop(_cons) width(50) ///
$clean_table indicate( `r(indicate_fe)', labels($\checkmark$ --- ))
	
}
*

*===============================================================================
* TABLE B.9: EDUCATION
*===============================================================================
{

use "output/workingsample_boompost_skilled", clear
bysort nni (year): keep if _n==1

gen ict0_boom = ict0 * (coh=="boom")
label var ict0 "\\[-1.8ex] ICT\(_{0}\)"
label var ict0_boom "ICT\(_{0}\)\(\times\)Boom cohort"

gegen sxcoh = group(sx coh)
gegen age0coh = group(age0 coh)
gegen occ0coh = group(occ0 coh)
gegen dep0coh = group(dep0 coh)

eststo clear
qui eststo: reghdfe univM ict0 ict0_*, a(sxcoh age0coh yr0) cl(id)
$trueobs

qui eststo: reghdfe univM ict0 ict0_*, a(sxcoh age0coh yr0 occ0coh) cl(id)
$trueobs

qui eststo: reghdfe univM ict0 ict0_*, a(sxcoh age0coh yr0 occ0coh dep0coh) cl(id)
$trueobs

estfe . est*, labels( ///
	sxcoh 	"\\[-1.8ex]\hline\addlinespace\textit{Fixed Effects} \\ \hspace{1.5em}Sex" ///
		age0coh 		"\hspace{1.5em}Age\(_{0}\)" ///	
		yr0 			"\hspace{1.5em}Year\(_{0}\)" ///	
		dep0coh 		"\hspace{1.5em}Commuting zone\(_{0}\)" ///	
		occ0coh			"\hspace{1.5em}Occupation\(_{0}\)")	
	
esttab using "results/education.tex", ///
drop(_cons) width(50) ///
$clean_table indicate( `r(indicate_fe)', labels($\checkmark$ --- ))


}
*

*===============================================================================
* TABLE B.10: ATTRITION
*===============================================================================
{

use $varBase year  ///
	using "output/workingsample_boompost_skilled", clear

* Wage growth t-2 --> t
gsort id year
xtset id year
gen gwage = logwage - L2.logwage

* Attrition: dummy last year in panel
gegen maxyear = max(year), by(id)
gen lastyear = year==maxyear
drop maxyear

gen gwage_ict0 = gwage * ict0
gen gwage_boom = gwage * (coh=="boom")
gen gwage_ict0_boom = gwage * ict0 * (coh=="boom")
label var gwage "\\[-1.8ex] Wage growth\$_{i,t-2 \rightarrow t}$"
label var gwage_ict0 "Wage growth\$_{i,t-2 \rightarrow t}$\(\times\)ICT\(_{0}\)"
label var gwage_boom "Wage growth\$_{i,t-2 \rightarrow t}$\(\times\)Boom cohort"
label var gwage_ict0_boom "Wage growth\$_{i,t-2 \rightarrow t}$\(\times\)ICT\(_{0}\)\(\times\)Boom cohort"

eststo clear
qui eststo: reghdfe lastyear gwage if year<=2010, a(ict0yr sxyr age0yr occ0yr yr0yr apet0yr) cl(id)
$trueobs

qui eststo: reghdfe lastyear gwage gwage_ict0 if year<=2010, a(ict0yr sxyr age0yr occ0yr yr0yr apet0yr) cl(id)
$trueobs

qui eststo: reghdfe lastyear gwage gwage_ict0 gwage_boom gwage_ict0_boom if year<=2010, a(ict0yr sxyr age0yr occ0yr yr0yr apet0yr) cl(id)
$trueobs

$fe_list
esttab using "results/attrition.tex", ///
drop(_cons) width(50) ///
$clean_table indicate( `r(indicate_fe)', labels($\checkmark$ --- ))


}
*

*===============================================================================
* TABLE B.11: HIGH-GROWTH FIRMS
*===============================================================================
{

use $varBase growth_topquartile usa0 ///
	using "output/workingsample_boompost_skilled", clear

eststo clear
qui eststo: reghdfe logwage ict0boom_* if growth_topquartile==1, a($feBase) cl(id)
$trueobs

qui eststo: reghdfe logwage ict0boom_* if usa0==1, a($feBase ) cl(id)
$trueobs

$fe_list
esttab using "results/high_growth.tex", ///
drop(_cons) width(50) ///
$clean_table indicate( `r(indicate_fe)', labels($\checkmark$ --- ))

}
*

*===============================================================================
* TABLE B.12: Job loss: STEM vs non-STEM
*===============================================================================
{
use $varBase year term_* /// 
	using "output/workingsample_boompost_skilled", clear

* keep 1 obs per worker
bysort id (year): keep if _n==1

* rhs variables
gen ict0_boom = ict0 * (coh=="boom")
label var ict0 "ICT\(_{0}\)"
label var ict0_boom "\addlinespace ICT\(_{0}\) x Boom cohort"
gegen sxcoh = group(sx coh)
gegen age0coh = group(age0 coh)
gegen occ0coh = group(occ0 coh)
gegen yr0coh = group(yr0 coh)

global fe "sxcoh age0coh occ0coh yr0coh"	

*** Regressions  
gen stem = occ0=="38"

foreach s in 0 1 {
	eststo clear
	preserve
		keep if stem==`s'
		foreach x in all demp dwage either {
			qui eststo, title("`x'"): reghdfe term_`x'_4 ict0_boom ict0, a($fe) vce(r)
			$trueobs
		}
	restore
	esttab  using "results/jobloss_stem_`s'.tex", ///
	keep(ict0_boom ) ///
	$clean_table_panelformat
}
}
*
*===============================================================================
* TABLE B13: CONTROLLING FOR JOB LOSSES
*===============================================================================
{

use $varBase term_* /// 
	using "output/workingsample_boompost_skilled", clear

	* Interaction terms
	qui init_jobloss_interactions, baselabel("Job termination")

* Interacting with the different proxies of job loss (Table B.13)
eststo clear
qui eststo: reghdfe logwage ict0boom_*, a($feBase) cl(id)
$trueobs
foreach x in demp dwage either {
	local var term_`x'_4
	di "`var'"
	forvalues t = 3(1)4 {
		qui replace mob_`t' = `var' * (per==`t')
		qui replace mobboom_`t' = `var' * (per==`t') * (coh=="boom")
		qui replace mobict0_`t' = `var' * (per==`t') * ict0
		qui replace mobict0boom_`t' = `var' * (per==`t') * ict0 * (coh=="boom")
	}
	qui eststo: reghdfe logwage ict0boom_* mob_* mobict0_* mobboom_* mobict0boom_*, a($feBase) cl(id)
	$trueobs
}
$fe_list
esttab  using "results/wage_jobloss_ict.tex", ///
keep(*_4) width(50) ///
$clean_table indicate( `r(indicate_fe)', labels($\checkmark$ --- ))


}
*
*===============================================================================
* TABLE B14: controlling for job loss at the local labor market level 
*===============================================================================
{

use $varBase term_* dep0 year ///
	using "output/workingsample_boompost_skilled", clear

	* Local job market tightness
	rename (occ0 dep0) (occup dept)
	merge m:1 occup dept using "output/jobloss_occdep", keep(1 3) nogen keepusing(LJMT)
	gen_pctile_hi LJMT_hi,var(LJMT) by(occ0 yr0)  


	* Interaction terms
	qui init_jobloss_interactions, baselabel("Job termination")

*** By local job market tightness (Table B.14)
qui foreach z in 0 1 {
	preserve
		di in red "Local labor market tightness = `z'"
		keep if LJMT_hi==`z'
		
		* baseline without controlling
		eststo clear
		eststo: reghdfe logwage ict0boom_*, a($feBase) cl(id)
		$trueobs
		
		* controlling with the different proxies of termination
		foreach x in demp dwage either {
			local var term_`x'_4
			forvalues t = 3(1)4 {
				replace mob_`t' = `var' * (per==`t')
			}
			eststo: reghdfe logwage ict0boom_* mob_*, a($feBase) cl(id)
			$trueobs
		}
		
		$fe_list
		esttab  using "results/wage_jobloss_llm`z'.tex", ///
		keep(ict0boom_* mob_3 mob_4) width(50) ///
		$clean_table_panelformat
	
	restore
}

}
*

*===============================================================================
* R1 & R2: TESTING FOR MISMATCH USING UNEMPLOYMENT RATE
*===============================================================================
{

use $varBase dep0 year ///
	using "output/workingsample_boompost_skilled", clear

* Unemployment rate
preserve
	use dep0 year urate using "output/unemployment_rate", clear
	rename year yr0
	tempfile urate_by_yr0
	save `urate_by_yr0'
restore
merge m:1 dep0 yr0 using `urate_by_yr0', keep(3) nogen

gquantiles urate_hi = urate, xtile nq(2) by(yr0)
replace urate_hi = urate_hi-1

* Split-sample regressions
eststo clear

qui eststo: reghdfe logwage ict0boom_* if urate_hi==1, a($feBase) cl(id)
$trueobs

qui eststo: reghdfe logwage ict0boom_* if urate_hi==0, a($feBase) cl(id)
$trueobs

$fe_list
esttab  using "results/wage_unemployment.tex", ///
drop(_cons) width(50) ///
$clean_table indicate( `r(indicate_fe)', labels($\checkmark$ --- ))

}
*



*===============================================================================
* Quantiles
*===============================================================================

cap program drop gen_pctile_hi 
program define gen_pctile_hi	
	syntax newvarname ,Var(varname) [BY(varlist) COND(string)]
	local v 	`var'
	* Build by option 
	if "`by'" != ""{
		local byopt "by(`by')"
	}
	if "`cond'" != "" {
		local ifopt "if `cond'"
	}	

	* Percentile at yr0
	tempvar p50yr0 p50 
	gegen `p50yr0' 	= pctile(`v') `ifopt',`byopt' p(50)
	gegen `p50'		= max(`p50yr0'),by(id)
	gen `varlist' 	= `v' >=`p50' if `v'<.
end 

*===============================================================================
* Winsorize
*===============================================================================

do "code/_program_winsor4/winsor4.ado"

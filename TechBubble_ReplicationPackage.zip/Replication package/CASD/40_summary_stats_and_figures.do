
cd "${dir}"

* Cache repeated inputs
use if year>=1994 using "output/dads_panel_all", clear
save "output/dads_panel_all_1994plus", replace
use if year>=1994 using "output/dads_panel_entrants", clear
save "output/dads_panel_entrants_1994plus", replace


*===============================================================================
* APPENDIX TABLE B.1: SUMMARY STATS WORKERS
*===============================================================================
{

*** ALL SKILLED WORKERS

* all skilled workers 1994-2020
use year cs2 wage sx age using "output/dads_panel_all_1994plus", clear
keep if substr(cs2,1,1)=="3" | cs2=="23"

* Stats reported in the text of the paper
tab cs2, sort

keep if inlist(cs2,"23","37","38")

* real wage
merge m:1 year using "rawdata/inflation", keep(1 3) nogen
replace wage = wage*euro2000*12

* labels
label var wage "Annual wage"
gen male = sx=="1"
label var male "Male"
label var age "Age"

* summary stats for high-skill workers
eststo clear
estpost tabstat wage male age, stat(N mean p25 p50 p75) col(stat)
estout using "results/sum-stats-all.tex", replace style(tex) cells("count(fmt(%12.0fc) label(N)) mean(fmt(%12.2gc) label(Mean)) p25(fmt(%12.2gc) label(P25)) p50(fmt(%12.2gc) label(P50)) p75(fmt(%12.2gc) label(P75))") label mlabels(none) varwidth(30) collabel(none)

/* Distribution of wages across occupation --> used to calculate the stat reported in the paper that the average skilled wage ~90th percentile of the entire workforce
use "output/dads_panel_all", clear
keep if year>=1994
merge m:1 year using "rawdata/inflation", keep(1 3) nogen
replace wage = wage*euro2000*12
sort wage
gen rank = _n/_N
su rank if abs(wage-42321.28)<1	// 92%
*/


*** SKILLED ENTRANTS

* all skilled entrants
use nni year yr0 occup0 wage sx age age0 if yr0>=1994 & yr0<=2005 using "output/dads_panel_entrants_1994plus", clear
rename occup0 occ0
keep if inlist(occ0,"23","37","38")

* real wage
merge m:1 year using "rawdata/inflation.dta", keep(1 3) nogen
replace wage = wage*euro2000*12

* entry wage
sort nni year
by nni: gen wage0 = wage[1]

* labels
label var wage "Annual wage"
label var wage0 "Annual starting wage"
gen male = sx=="1"
label var male "Male"
label var age "Age"
label var age0 "Age at entry"

eststo clear
estpost tabstat wage male age0, stat(N mean p25 p50 p75) col(stat)
estout using "results/sum-stats-entrants.tex", replace style(tex) cells("count(fmt(%12.0fc) label(N)) mean(fmt(%12.2gc) label(Mean)) p25(fmt(%12.2gc) label(P25)) p50(fmt(%12.2gc) label(P50)) p75(fmt(%12.2gc) label(P75))") label mlabels(none) varwidth(30) collabel(none)


*** STEM SHARE
use year cs2 ict using "output/dads_panel_all_1994plus", clear
keep if substr(cs2,1,1)=="3" | cs2=="23"
* fraction of STEM among high-skill workers (reported in the paper)
gen stem = cs2=="38"
tabstat stem, by(ict)	// 23%

}


*===============================================================================
* APPENDIX TABLE B.2: LIST OF ICT SECTORS
*===============================================================================
{

*** List of ICT sectors 1994-2008 (Appendix Table B.2)

capture confirm global dir
if _rc==0 {
	do "${dir}/code/_program_ict_sector_shares.do"
}
else {
	capture noisily do "code/_program_ict_sector_shares.do"
	if _rc {
		do "_program_ict_sector_shares.do"
	}
}
build_ict_sector_shares, withisic

* create display variable with LaTeX formatting
replace ictsec1 = "\textbf{ICT: " + ictsec1 + "}" if ictsec1~=""
replace ictsec1 = "\vspace{0.1em} \quad " + ictsec2 if ictsec1==""
gsort rank -share_all

* Calculate totals for the final row
gegen tot_all = sum(share_all) if substr(ictsec1,1,9)=="\textbf{I"
gegen tot_ski = sum(share_ski) if substr(ictsec1,1,9)=="\textbf{I"
sum tot_all, meanonly
local total_all = r(mean)
sum tot_ski, meanonly
local total_ski = r(mean)

* ============================================================================
* Generate LaTeX table
* ============================================================================
file open texfile using "results/ict_employment_table.tex", write replace
file write texfile "\begin{tabular}{llcc}" _n
file write texfile "\toprule\addlinespace ICT industries & ISIC rev 3.1 & Share of & Share of \\" _n
file write texfile "& codes & total & skilled\\" _n
file write texfile "&& employment &  employment\\" _n
file write texfile "&& (\%) & (\%)\\" _n
file write texfile "\addlinespace\midrule\addlinespace" _n

* Write data rows
quietly count
forvalues i = 1/`r(N)' {
    local label = ictsec1[`i']
    local code = isic[`i']
    local sh_all = string(share_all[`i'], "%9.1f")
    local sh_ski = string(share_ski[`i'], "%9.1f")
    file write texfile "`label' & `code' & `sh_all' & `sh_ski'\\" _n
}

* Write total row
file write texfile "\addlinespace \midrule" _n
file write texfile "\addlinespace \textbf{ICT: Total} && \textbf{" %9.1f (`total_all') "} & \textbf{" %9.1f (`total_ski') " }\\" _n
file write texfile "\addlinespace\bottomrule" _n
file write texfile "\end{tabular}" _n
file close texfile

display as result _n "✓ LaTeX table saved to: results/ict_employment_table.tex" _n




*** Top and bottom sectors by capital flows
use year apet_sir gcap_secdep if year>=1998 & year<=2001 using "output/gcap", clear
rename apet_sir apet
keep if gcap_secdep<.
gen n = 1
gcollapse (mean) gcap_secdep (sum) n, by(apet year)
gcollapse (mean) gcap_secdep (sum) n, by(apet)
keep if gcap_secdep<.
gen ict = inlist(substr(apet,1,2),"72") | inlist(substr(apet,1,3),"300","321","322","323","332","333","642") | inlist(apet,"313Z","516G","518G","518J","713E") if apet~=""

}


*===============================================================================
* FIGURE 1: TIME-SERIES EQUITY ISSUANCE
*===============================================================================
{

use sir year ict capisoc tot_act using "output/equity-issuance", clear

* drop if negative assets
drop if tot_act<0

* set as a firm-year panel
gegen sir_num = group(sir)
gsort sir_num year
xtset sir_num year

* positive equity growth, dropping firms with total assets below 10 M€
gen dcap = max(capisoc-L.capisoc,0)/L.tot_act if L.tot_act>=10
replace dcap = 1 if dcap>1 & dcap<.

* alternative: net equity growth
gen dcapnet = (capisoc-L.capisoc)/L.tot_act if L.tot_act>=10
replace dcapnet = 1 if dcapnet>1 & dcapnet<.
replace dcapnet = -1 if dcapnet<-1

* average by ICT x Year
gcollapse (mean) dcap dcapnet, by(ict year)
reshape wide dcap dcapnet, i(year) j(ict)
foreach x in "" "net" {
	label var dcap`x'0 "Other sectors"
	label var dcap`x'1 "ICT sector"
}

line dcapnet1 dcapnet0 year, xlabel(1994(3)2006) xtitle("") ytitle("") ylabel(,angle(horizontal)) legend(region(lwidth(none))) graphregion(fcolor(white) lcolor(white) ifcolor(white) ilcolor(white))
graph export "results/Agg_EquityIssuance.pdf", as(pdf) replace
graph close

}


*===============================================================================
* FIGURE 2: ICT EMPLOYMENT SHARE
*===============================================================================
{

*** ALL COHORTS

* all workers
use broadind nni annai year sir ict cs2 using "output/dads_panel_all_1994plus", clear

* entry year
sort nni year
by nni: gen yr0 = year[1] if year[1]>=1991 & year[1]-annai<=30

* keep skilled
* deal with changes in occupation classification at France Telecom: assign initial occupation throughout

gen skilled = substr(cs2,1,1)=="3" | cs2=="23"
sort nni sir year
by nni sir: gen skilled0 = skilled[1] if sir=="380129866"
replace skilled = 1 if sir=="380129866" & skilled0==1
keep if skilled==1
//keep if inlist(cs2,"23","37","38")

* keep 1994-2008
keep if year>=1994 & year<=2008
drop if ict==.

* young vs. seasond workers
gen ict_new = ict==1 if yr0>=year-4 & yr0~=.
gen ict_old = ict==1 if yr0<=year-5 | yr0==.

* collapse by year
gen n = 1
gcollapse (mean) ict ict_new ict_old (sum) n, by(year)

* figure all skilled workers
line ict year, xlabel(1994(3)2006) xtitle("") ytitle("") ylabel(,angle(horizontal)) graphregion(fcolor(white) lcolor(white) ifcolor(white) ilcolor(white))
graph export "results/ict_share_skilled.pdf", as(pdf) replace
graph close

* Numbers reported in the text
l year ict

* figure seasoned versus recent entrants
label var ict_new "0-4 years since entry"
label var ict_old "5+ years since entry"
line ict_old ict_new year, xlabel(1994(3)2006) xtitle("") ytitle("") ylabel(,angle(horizontal)) graphregion(fcolor(white) lcolor(white) ifcolor(white) ilcolor(white)) legend(position(6) region(lpattern(blank)))
graph export "results/ict_share_young.pdf", as(pdf) replace
graph close


*** ENTRANTS

* all skilled entrants
use year yr0 occup0 ict if year==yr0 using "output/dads_panel_entrants_1994plus", clear
keep if substr(occup0,1,1)=="3" | occup0=="23"

* collapse by year
gen n = 1
gcollapse (mean) ict (sum) n, by(year)

* figure
line ict year, xlabel(1994(3)2008) xtitle("") ytitle("") ylabel(,angle(horizontal)) graphregion(fcolor(white) lcolor(white) ifcolor(white) ilcolor(white))
graph export "results/ict_share_entrants.pdf", as(pdf) replace
graph close

}


*===============================================================================
* FIGURES 3 & 4: WAGE DYNAMICS
*===============================================================================
{

use nni year logwage ict0 coh sx age0 yr0 occup0 using "output/dads_panel_entrants_1994plus", clear
rename occup0 occ0

* restrict to skilled
keep if inlist(occ0,"23","37","38")

* restrict to working cohorts
keep if inlist(coh,"pre","boom","post")

* variable x cohort x year
foreach c in pre boom post {
	forvalues t = 1994(1)2015 {
		gen ict0_`c'_y`t' = ict0 * (coh=="`c'") *  (year==`t')
	}
}

* fixed effects
gegen id = group(nni)
gegen sxcohyr = group(sx coh year)
gegen age0cohyr = group(age0 coh year)
gegen occ0cohyr = group(occ0 coh year)
gegen yr0yr = group(yr0 year)
gegen sxyr0yr = group(sx yr0 year)
gegen age0yr0yr = group(age0 yr0 year)
gegen occ0yr0yr = group(occ0 yr0 year)
gegen maxyear = max(year), by(nni)


*** ALL COHORTS

qui reghdfe logwage ict0_*_y*, a(sxcohyr age0cohyr occ0cohyr yr0yr) cl(id)

* create figure
capture drop t
qui gen t = 1994+(_n-1) if 1994+(_n-1)<=2015
capture drop beta_* hi_* lo_*
foreach c in pre boom post {
	qui gen beta_`c' = .
	qui gen hi_`c' = .
	qui gen lo_`c' = .
}

forvalues t = 1994(1)2015 {
	qui replace beta_pre	= _b[ict0_pre_y`t'] if t==`t'
	qui replace hi_pre		= _b[ict0_pre_y`t']+1.96*_se[ict0_pre_y`t'] if t==`t'
	qui replace lo_pre	 	= _b[ict0_pre_y`t']-1.96*_se[ict0_pre_y`t'] if t==`t'
}
forvalues t = 1998(1)2015 {
	qui replace beta_boom 	= _b[ict0_boom_y`t'] if t==`t'
	qui replace hi_boom		= _b[ict0_boom_y`t']+1.96*_se[ict0_boom_y`t'] if t==`t'
	qui replace lo_boom	 	= _b[ict0_boom_y`t']-1.96*_se[ict0_boom_y`t'] if t==`t'
}
forvalues t = 2003(1)2015 {
	qui replace beta_post 	= _b[ict0_post_y`t'] if t==`t'
	qui replace hi_post		= _b[ict0_post_y`t']+1.96*_se[ict0_post_y`t'] if t==`t'
	qui replace lo_post	 	= _b[ict0_post_y`t']-1.96*_se[ict0_post_y`t'] if t==`t'
}

line beta_pre beta_boom beta_post t, ///
	text(.09 1995.3 "Pre-boom", col(navy) size(small)) text(.08 1995.3 "cohort", col(navy) size(small)) xline(1994, lcol(navy) lpat(dot)) xline(1996.5, lcol(navy) lpat(dot)) ///
	text(.115 1999.8 "Boom cohort", col(maroon) size(small)) xline(1998, lcol(maroon) lpat(dot)) xline(2001.5, lcol(maroon) lpat(dot)) ///
	text(.09 2004.3 "Post-boom", col(forest_green) size(small)) text(.08 2004.3 "cohort", col(forest_green) size(small)) xline(2003, lcol(forest_green) lpat(dot)) xline(2005.5, lcol(forest_green) lpat(dot)) ///
	legend(off) xlabel(1994(3)2015) xtitle(" ") ylabel(-.1(.05).1, grid glwidth(vthin) glcolor(gs12)) graphregion(fcolor(white) lcolor(white) ifcolor(white) ilcolor(white))

** Alternative presentation 
line beta_pre beta_boom beta_post t, ///
	text(.065 1995.3 "Pre-boom", col(navy) size(small)) text(.055 1995.3 "cohort", col(navy) size(small)) xline(1994, lcol(navy) lpat(dot)) xline(1996.5, lcol(navy) lpat(dot)) ///
	text(.065 1999.9 "Boom", col(maroon) size(small))text(.055 1999.9 "cohort", col(maroon) size(small))  xline(1998, lcol(maroon) lpat(dot)) xline(2001.5, lcol(maroon) lpat(dot)) ///
	text(.065 2004.3 "Post-boom", col(forest_green) size(small)) text(.055 2004.3 "cohort", col(forest_green) size(small)) xline(2003, lcol(forest_green) lpat(dot)) xline(2005.5, lcol(forest_green) lpat(dot)) ///
	legend(off) xlabel(1994(3)2015) xtitle(" ") ylabel(-.1(.05).1, grid glwidth(vthin) glcolor(gs12)) graphregion(fcolor(white) lcolor(white) ifcolor(white) ilcolor(white))
	
graph export "results/Wage_AllCohorts2.pdf", as(pdf) replace


graph export "results/Wage_AllCohorts.pdf", as(pdf) replace
graph close

* Numbers reported in the paper
su beta_boom if t>=1998 & t<=2001
su beta_boom if t==2015


*** BOOM MINUS POST

gegen ict0yr = group(ict0 year)

qui reghdfe logwage ict0_boom_y* if inlist(coh,"boom","post"), a(sxcohyr age0cohyr occ0cohyr yr0yr ict0yr) cl(id)

* create figure
capture drop t
qui gen t = 2003+(_n-1) if 2003+(_n-1)<=2015
capture drop beta_* hi_* lo_*
foreach c in boom {
	qui gen beta_`c' = .
	qui gen hi_`c' = .
	qui gen lo_`c' = .
}
forvalues t = 2003(1)2015 {
	qui replace beta_boom 	= _b[ict0_boom_y`t'] if t==`t'
	qui replace hi_boom		= _b[ict0_boom_y`t']+1.96*_se[ict0_boom_y`t'] if t==`t'
	qui replace lo_boom	 	= _b[ict0_boom_y`t']-1.96*_se[ict0_boom_y`t'] if t==`t'
}

line beta_boom hi_boom lo_boom t, lcolor(navy navy navy) lpattern(solid dash dash) ///
	yline(0, lcol(black) lpat(solid) lwidth(thin)) ///
	legend(off) xlabel(2003(3)2015) xtitle(" ") ylabel(-.1(.05).05, grid glwidth(vthin) glcolor(gs12)) graphregion(fcolor(white) lcolor(white) ifcolor(white) ilcolor(white))

graph export "results/Wage_BoomMinusPost.pdf", as(pdf) replace
graph close


*** BOOM MINUS PRE

qui reghdfe logwage ict0_boom_y* if inlist(coh,"boom","pre"), a(sxcohyr age0cohyr occ0cohyr yr0yr ict0yr) cl(id)

* create figure
capture drop t
qui gen t = 1998+(_n-1) if 1998+(_n-1)<=2015
capture drop beta_* hi_* lo_*
foreach c in boom {
	qui gen beta_`c' = .
	qui gen hi_`c' = .
	qui gen lo_`c' = .
}
forvalues t = 1998(1)2015 {
	qui replace beta_boom 	= _b[ict0_boom_y`t'] if t==`t'
	qui replace hi_boom		= _b[ict0_boom_y`t']+1.96*_se[ict0_boom_y`t'] if t==`t'
	qui replace lo_boom	 	= _b[ict0_boom_y`t']-1.96*_se[ict0_boom_y`t'] if t==`t'
}

line beta_boom hi_boom lo_boom t, lcolor(navy navy navy) lpattern(solid dash dash) ///
	yline(0, lcol(black) lpat(solid) lwidth(thin)) ///
	legend(off) xlabel(1998(3)2015) xtitle(" ") ylabel(-.1(.05).1, grid glwidth(vthin) glcolor(gs12)) graphregion(fcolor(white) lcolor(white) ifcolor(white) ilcolor(white))

graph export "results/Wage_BoomMinusPre.pdf", as(pdf) replace
graph close

}


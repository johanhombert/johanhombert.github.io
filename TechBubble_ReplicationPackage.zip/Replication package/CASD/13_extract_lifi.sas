


/*===============================================================================
    Specify the project and path
===============================================================================*/

%let project = TechBoom_replicationPackage ;
%let rawdatadir = \\casd.fr\casdfs\Projets\FISCENT\Data;
%let outdir = C:\Users\Public\Documents\&project.\rawdata\raw\lifi;

/*===============================================================================
/* Macro to transform upper case in lower case (important for dta export)
===============================================================================*/

%macro lower_vars(lib=WORK, data=mydata);
    proc sql noprint;
        select cats(name,'=',lower(name))
        into : renlist separated by ' '
        from dictionary.columns
        where libname = upcase("&lib")
        and memname = upcase("&data")
        and name ne lowcase(name);
    quit;
    %if %length(&renlist) %then %do;
        proc datasets lib=&lib nolist;
            modify &data;
            rename &renlist;
        quit;
    %end;
%mend;


/*===============================================================================
    LIFI EXTRACTION
===============================================================================*/

/* Main macro for LIFI extraction */
%macro extract_lifi(listyears, outdir);
    %local i year dirname files j file;
    %let i = 1;
    %do %while(%length(%scan(&listyears, &i)));
        %let year = %scan(&listyears, &i);

        %put NOTE: LIFI YEAR=&year;

        /* Determine directory naming and file list based on year */
        %if &year >= 1994 and &year <= 2011 %then %do;
            %let dirname = LIFI_Enqu�te LIFI_&year;
            %let files = tg lar;
        %end;
        %else %if &year >= 2012 and &year <= 2013 %then %do;
            %let dirname = LIFI_LIFI_&year;
            %let files = tg lar;
        %end;
        %else %if &year >= 2014 and &year <= 2015 %then %do;
            %let dirname = LIFI_LIFI_&year;
            %let files = groupe liaison_lifi liaison_reelle ul_lifi;
        %end;

        /* Process each file for the current year */
        %let j = 1;
        %do %while(%length(%scan(&files, &j)));
            %let file = %scan(&files, &j);

            %put NOTE: LIFI YEAR=&year FILE=&file;

            /* Import SAS file */
            data mydata;
                set "&rawdatadir.\&dirname.\&file..sas7bdat";
            run;

            /* Convert variable names to lowercase */
            %lower_vars(lib=work, data=mydata);

            /* Export to Stata format */
            proc export data=mydata outfile="&outdir.\lifi&year.&file..dta" replace;
            run;

            /* Clean up */
            proc datasets lib=work nolist;
                delete mydata;
            quit;

            %let j = %eval(&j + 1);
        %end;

        %let i = %eval(&i + 1);
    %end;
%mend;

/* Wrapper macro using fyear/lyear for contiguous year ranges */
%macro extract_lifi_range(fyear=, lyear=, outdir=);
    %local yr listyears;
    %let listyears =;
    %do yr = &fyear %to &lyear;
        %let listyears = &listyears &yr;
    %end;
    %extract_lifi(&listyears, &outdir);
%mend;


/*################################################################### */
/* RUN LIFI EXTRACTION */
/*################################################################### */

/* Extract years 1994-2007 (matching the Stata dofile) */
%extract_lifi_range(fyear=1994, lyear=2007, outdir=&outdir);


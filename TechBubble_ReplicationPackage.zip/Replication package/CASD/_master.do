
*===============================================================================
* RUN THIS BLOCK EACH TIME
*===============================================================================

* Path to CASD raw data
global rawdatadir "\\casd.fr\casdfs\Projets\FISCENT\Data"

* Path to project directory
global dir "C:\Users\Public\Documents\TechBoom_replicationPackage"

/*
* Install packages
cd "${dir}"
do "code/01_install_packages.do"
*/

* Own programs
cd "${dir}"
do "code/02_own_programs.do"


*===============================================================================
* DIRECTORIES AND PACKAGES
*===============================================================================

* Create directory for raw data in Stata format
cd "${dir}"
capture mkdir rawdata

* Create directory for temporary files
cd "${dir}"
capture mkdir output

* Create directory for results
cd "${dir}"
capture mkdir results



*===============================================================================
* Create directories to store raw and cleaned data in Stata format
*===============================================================================

cd "${dir}/rawdata"
foreach folder in "raw" "cleaned" {
	cap mkdir 	`folder'
}

* Create directories to store raw data 
cd "${dir}/rawdata/raw"
foreach folder in dads_panel dads_postes ficus_fare ree_creation lifi {
	cap mkdir 	`folder'
}

*** Create directories to store cleaned data  
cd "${dir}/rawdata/cleaned"
foreach folder in dads_panel dads_postes ficus_fare ree_creation lifi{
	cap mkdir 		`folder'
	global `folder' "${dir}/rawdata/cleaned/`folder'"
}


*===============================================================================
* Extract raw data (use SAS code)
*===============================================================================


/*
	10_extract_ficusfare.sas  	// Corporate tax filings
	11_extract_dads.sas			// Matched employer-employee
	12_extract_ree_creation.sas // Total of firm creation 
	13_extract_lifi.sas 		// Corporate ownership (Lifi)
	
*/


*===============================================================================
* Basic cleaning 
*===============================================================================

cd "${dir}"

* Corporate tax filings (ficus-fare)
do "${dir}/code/20_clean_ficusfare.do"

* Matched employer-employee panel 
do "${dir}/code/21_clean_dads_panel.do"

* Matched employer-employee universe n/n-1 
do "${dir}/code/22_clean_dads_postes.do"

* Firm creation  
do "${dir}/code/23_clean_ree_creation.do"

/*------------------------------------------------------------------------------
At this stage we can clean the raw folder 
------------------------------------------------------------------------------*/

foreach dataset in dads_postes ficus_fare ree_creation dads_panel{
	local files : dir "rawdata/raw/`dataset'" files "*"
	foreach f of local files {
		capture erase "rawdata/raw/`dataset'/`f'"
		if _rc di as error "Could not delete: rawdata/raw/`dataset'/`f'"
	}
}

*===============================================================================
* CONSTRUCT VARIABLES
*===============================================================================

cd "${dir}"
* DADS postes
do "${dir}/code/30_variables_dads_postes.do"

* Construct firm variables in Ficus-Fare
do "${dir}/code/31_variables_firm.do"

* Innovation measures
do "${dir}/code/34_variables_innovation.do"

* Construct variables in the DADS panel
do "${dir}/code/35_variables_dads_panel.do"

*===============================================================================
* DATA ANALYSIS
*===============================================================================

* Summary stats and figures
do "${dir}/code/40_summary_stats_and_figures.do"

* Main regressions
do "${dir}/code/41_regressions.do"

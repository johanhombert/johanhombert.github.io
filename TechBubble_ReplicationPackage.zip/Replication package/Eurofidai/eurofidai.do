
*-------------------------------------------------------------------------------
* Extract stock returns from Eurofidai
* ------------------------------------------------------------------------------*

* Market cap at monthly frequency from daily stock prices
insheet using "source/security_results_jhombert_20180720_1876.csv", delim(";") names clear
keep if capitalization<.
gen year = substr(quotation_date,1,4)
gen month = substr(quotation_date,6,2)
gen day = substr(quotation_date,9,2)
sort eurofidai_code year month day
by eurofidai_code year month: keep if _n==_N
destring year, replace
destring month, replace
rename capitalization mktcap
label var mktcap "End-month market cap"
keep eurofidai_code mktcap year month
save "output/mktcap_all_monthly", replace

* start from mapping siren <-> GK code (code emetteur) provided by Eurofidai
* liste_siren_gk_eurofidai_2018-07-18.xlsx

* extract list of unique GK code from this file
* --> 1675 GK (for 1672 siren)
insheet using "source/liste_siren_gk_eurofidai_2018-07-18.csv", delim(";") names clear
distinct code_gk code_siren
keep code_gk
outsheet using "output/list_gk.txt", replace

* do "recherche de code" on eurofidai platform based on the list of GK codes
* get mapping GK code (code emetteur) <-> eurofidai code

* extract list of unique eurofidai code from this file
insheet using "source/codes_results_jhombert_20180720_3739.csv", delim(";") names clear
distinct issuer_code eurofidai_code
keep eurofidai_code
duplicates drop
format eurofidai_code %15.0f
outsheet using "output/list.txt", replace

* download on eurofidai platform the returns data for this list of eurofidai codes
* saved in security_results_jhombert_20180720_9309.csv

* stock returns: id=eurofidai
insheet using "source/security_results_jhombert_20180720_9309.csv", delim(";") names clear
gen year = substr(last_monthly_date,1,4)
gen month = substr(last_monthly_date,6,2)
drop last_monthly_date
destring year, replace
destring month, replace
save "output/returns", replace

* GK 1:m eurofidai
insheet using "source/codes_results_jhombert_20180720_3739.csv", delim(";") names clear
keep if stock_type_name=="Common stock"
keep issuer_code eurofidai_code eurofidai_sector_name
duplicates drop
joinby eurofidai_code using "output/returns"
format eurofidai_code %15.0f
save "output/returns", replace

* GK 1:m siren
insheet using "source/liste_siren_gk_eurofidai_2018-07-18.csv", delim(";") names clear
rename code_gk issuer_code
joinby issuer_code using "output/returns"
distinct issuer_code code_siren
save "output/returns", replace

* year-end market cap
insheet using "source/security_results_jhombert_20180720_3810.csv", delim(";") names clear
keep if capitalization<.
gen year = substr(quotation_date,1,4)
gen month = substr(quotation_date,6,2)
gen day = substr(quotation_date,9,2)
sort eurofidai_code year month day
by eurofidai_code year: keep if _n==_N
destring year, replace
rename capitalization mktcap
label var mktcap "Year-end market cap"
keep eurofidai_code mktcap year
save "output/mktcap", replace

* compute annual returns
use "output/returns", clear
gen return = log(1+monthly_return)
rename code_siren siren
collapse (sum) return (count) n=return, by(siren eurofidai_code year nom_societe nom_societe_long eurofidai_sector_name)
keep if n==12
drop n
replace return = exp(return)-1
merge m:1 eurofidai_code year using "output/mktcap", keep(1 3) nogen
label var eurofidai_code "Eurofidai code"
label var return "Annual return"
label var eurofidai_sector_name "Sector"
save "output/returns_annual", replace


*-------------------------------------------------------------------------------
* Stock returns ICT (Figure 1a in the paper)
*-------------------------------------------------------------------------------

use "output/returns", clear
duplicates drop eurofidai_code year month, force
merge 1:1 eurofidai_code year month using "output/mktcap_all_monthly", keep(3) nogen
keep if year>=1994 & year<=2006
gen date = ym(year,month)
format date %tm
xtset eurofidai_code date

* lagged market cap
gen lagmktcap = L.mktcap

* drop if missing sector
drop if inlist(eurofidai_sector_name,				///
	"",												///
	"Non-classifiable/non-classified institutions")

* ICT sectors
gen ict = inlist(eurofidai_sector_name, ///
	"Computer hardware & networking",	///
	"Electronics & semiconductors",		///
	"Internet, software & IT services",	///
	"Telecommunication")

* value-weighted return
gcollapse (mean) ret=monthly_return [aw=lagmktcap], by(ict year date)

* cumulative return
sort ict date
by ict: gen cumret = log(1+ret) if _n==1
by ict: replace cumret = cumret[_n-1]+log(1+ret) if _n>1
drop ret

* reshape
reshape wide cumret, i(date) j(ict)
label var cumret1 "ICT sector"
label var cumret0 "Other sectors"

* graph
line cumret1 cumret0 date, xtitle("") ytitle("") ylabel(,angle(horizontal)) legend(region(lwidth(none))) graphregion(fcolor(white) lcolor(white) ifcolor(white) ilcolor(white))
graph export "Figure_1A.pdf", as(pdf) replace
graph close

*-------------------------------------------------------------------------------
* Construct the file "stock_price_firm.dta" to be imported in CASD
*-------------------------------------------------------------------------------

* Eurofidai data
use "output/returns_annual", clear
keep if year>=1994 & year<=2007

* convert market cap in '000 euros
replace mktcap = mktcap/6.56 if year<=1998
replace mktcap = mktcap/1000

* market cap consolidated at the group level
merge 1:1 siren year using "source/lifi", keep(1 3) nogen
gegen mktcapgr = sum(mktcap) if sirtg~="", by(sirtg year)
replace mktcapgr = mktcap if mktcapgr==.

* merge with BRN (>90% is successfully merged every year)
merge 1:1 siren year using "source/brn", keep(1 3)
tab year _m
tab year _m [aw=mktcap]
keep if _m==3

* save
keep naf600 siren year mktcap mktcapgr salgr sales return
sum
distinct naf600
save "output/stock_price_firm", replace

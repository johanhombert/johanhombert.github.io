

*===============================================================================
* Adapt the stock command of Bowen et al. 
*===============================================================================

cap prog drop patstat_agg
prog def patstat_agg
syntax varlist, Groupvar(varname) Timevar(varname) Depreciation(real) Windowsize(integer) [Idvar(varname)]
qui{ 
	if "`idvar'" == "" {
		local idvar patent_id 
	}
	
	drop if missing(`groupvar') | missing(`timevar')

	// set up locals for collapse and stat commands 

	local sum_collapse
	local count_collapse
	local sum_range 
	local count_range 
	foreach v in `varlist' {
		local sum_collapse   "`sum_collapse'   sum_`v'   = `v'"
		local count_collapse "`count_collapse' count_`v' = `v'"
		local sum_range      "`sum_range'      `v'_sum_roll`windowsize'   = sum_`v'"
		local count_range    "`count_range'    `v'_count_roll`windowsize' = count_`v'"
	}

	// collapse to G-T panel, with each group-time's average and max patent stats within the period
	gcollapse (sum)   `sum_collapse' (count) `count_collapse', by(`groupvar' `timevar')

	// the panel should have no gaps and 0s where missing values exist 
		
	tsset `groupvar' `timevar'
	tsfill, full
	foreach v of varlist  sum_* count_* {
		replace `v' = 0 if `v' == .
	}	
	
	// Rolling average and stock
	/*
		Rolling window "stocks" (a rolling average weighted towards present)
		sum over patents in window ( (1-d)^t * X )
	*/
	local lookback = 1-`windowsize' // ex: stats over [-3,0] for win length = 4
	rangestat (sum) `sum_range'  `count_range' ///
			  , interval(`timevar' `lookback' 0) by(`groupvar') 

	foreach v in `varlist' {
		g `v'_avg_roll`windowsize' = `v'_sum_roll`windowsize' / `v'_count_roll`windowsize'
		lab var `v'_avg_roll`windowsize' "avg: q+[`lookback', 0])"
	}

	local lookback = `windowsize' - 1 // ex Lags 0,1,2,3 for win length = 4 
	local perc = `depreciation'*100

	sort `groupvar' `timevar'

	foreach v in `varlist' {
		g `v'_stock`windowsize' = 0
		forval lag = 0/`lookback' {
			by `groupvar' (`timevar'): replace `v'_stock`windowsize' = `v'_stock`windowsize' + L`lag'.sum_`v' * (1-`depreciation')^`lag' if _n > `lag'
		}
		replace  `v'_stock`windowsize' = `v'_stock`windowsize' / `v'_count_roll`windowsize'
		replace  `v'_stock`windowsize' = 0 if `v'_count_roll`windowsize' == 0
		lab var `v'_stock`windowsize' "`v' stock: [t-`lookback',t] (`perc'% deprec) "
		
	}
	// output	
	order `groupvar' `timevar' 
	keep `groupvar' `timevar' *_avg_roll* *_stock* 		
}
end 


*===============================================================================
*===============================================================================
* Patent info (except citations)   
*===============================================================================
*===============================================================================
{		
	
*** PATENT data 
	* patent - year 
	use filing_date patent_id using "$patent/patentview/g_application.dta", clear
// 	gen year_app = substr(filing_date,1,4)
	gen year = substr(filing_date,1,4)
	destring year, replace
	keep if year<=2024 // a few coding mistakes
	keep if year>=1970 	
	keep patent_id year
	destring patent_id, replace force
	drop if patent_id==.
	save "$temp/patent_year", replace	
	
*** TECH CLASS 
	** CPC classification data for granted patents at the time of their issue.
	use cpc_subclass patent_id cpc_sequence ///
		using "$patent/patentview/g_cpc_current" if cpc_sequence == 0, clear
	rename cpc_subclass cpc 
	keep patent_id cpc 
	compress		
	save "$temp/patent_techClass",replace
 
	** Create unique cpc number that will change across dataset 
	use cpc_subclass using "$patent/patentview/g_cpc_current", clear
	gduplicates drop cpc_subclass,force 	
	gegen cpcid = group(cpc_subclass)
	rename cpc_subclass cpc 
	compress		
	save "$temp/cpc_cpcid",replace
 
 
*** ASSIGNEE
	// 1. Extract FIRMS 
	use assignee_type patent_id assignee_id location_id assignee_type ///
		using "$patent/patentview/g_assignee_disambiguated" if assignee_type ==2 | assignee_type ==3, clear 
	/*
		0 – Unclassified / Unknown
		1 – Unidentified entity
		2 – U.S. Company or Corporation
		3 – Foreign Company or Corporation
		4 – U.S. Individual
		5 – Foreign Individual
		6 – U.S. Government
		7 – Foreign Government
		8 – U.S. County or Municipality
		9 – Foreign County or Municipality
		12 – U.S. University
		13 – Foreign University
		14 – U.S. Nonprofit Organization
		15 – Foreign Nonprofit Organization
		17 – Unknown or Other entity
	*/
	destring patent_id,replace force 
	drop if patent_id == . //  	640,234 observations deleted
	keep patent_id assignee_id location_id assignee_type
	drop if missing(location_id) //(83,763 observations deleted)
	compress	
	save "$temp/patent_assignee", replace


*** RETech 
	/*
	RETech measures whether the patent pertains to a technological area that is rapidly evolving 
	(i.e., following breakthroughs) or stable from Bowen III, Fresard, and Hoberg (2023)
	*/
	import delimited "$patent/Pat_text_vars_NotWinsored.csv", clear
	keep if ayear>=1976
	rename pnum patent_id
	rename ayear year 	
	compress
	save "$temp/Pat_text_vars_NotWinsored.dta",replace

	
*-------------------------------------------------------------------------------
*  Working sample: merge all the needed info 
*-------------------------------------------------------------------------------
	
	/*
		NB: Bowen et al only available up to 2017 
	*/
	
	use "$temp/patent_year", clear
	** Retech
	merge 1:1 patent_id using  "$temp/Pat_text_vars_NotWinsored",nogen keep(3)
	
	** patent class
	merge 1:1 patent_id using "$temp/patent_techClass",nogen keep(3)
	
	** winsor by year the retech and breadth measure 
	foreach var in retech breadth{
		winsor4 `var',method(winsor) outlier(tail) level(1) group(year)
	}
	** Bring unique mapping cpc digit 
	merge m:1 cpc using "$temp/cpc_cpcid", keep(3) nogen 
	
	keep patent_id year retech breadth cpc cpcid 
	save "$temp/patent_workingdata", replace
	
}
*
*===============================================================================
* Citations
*===============================================================================
{
/*
	patent_id is the patent making the citation.
	citation_patent_id is the patent being cited.
	citation_date usually represents the publication or grant date of the cited patent, NOT the date the citation occurred
*/
	
*-------------------------------------------------------------------------------
*  Patent granted citations: 1970-2018 
*-------------------------------------------------------------------------------

/*
	We are going to miss the citations pre 70 for the obsolescence 
	but given we care about post 1990 it should be fine 
*/

*** Keep relevant variables 
	use patent_id citation_patent_id ///
		using "$patent/patentview/g_us_patent_citation_raw",replace
	destring patent_id citation_patent_id, replace force
	drop if patent_id == . | citation_patent_id==.
	rename citation_patent_id cited_patent
	gduplicates drop patent_id cited_patent, force
	fmerge m:1 patent_id using "$temp/patent_year",nogen keep(3)
	compress
	save "$temp/g_us_patent_citation",replace

*** Compute number of citations each patent will receive (forward looking)
	use cited_patent using "$temp/g_us_patent_citation", clear
	gen nbcit = 1 
	gcollapse (sum) nbcit, by(cited_patent)
	rename cited_patent patent_id 
	save "$temp/nbcitation_patent", replace
}
*
*============================================================
* AGE OF CITED PATENTS 
*============================================================
{
* Data at the level: focal patent x cited patent
	use patent_id citation_patent_id using "$patent/patentview/g_us_patent_citation_raw", clear
	destring patent_id citation_patent_id, replace force
	drop if patent_id==. | citation_patent_id==.
	rename patent_id patent_focal
	rename citation_patent_id patent_cited
	gduplicates drop patent_focal patent_cited,force

* Application year of focal patent
	rename patent_focal patent_id
	merge m:1 patent_id using "$temp/patent_year",nogen keep(3)
	rename patent_id patent_focal
	rename year year_focal

* Application year of cited patent
	rename patent_cited patent_id
	merge m:1 patent_id using "$temp/patent_year", nogen keep(1 3)	 
	rename patent_id patent_cited
	rename year year_cited

	gen age = year_focal - year_cited
	keep if age>=0 & age<=20

*** Compute average age of cited patent for each focal patent 
	gcollapse(mean) age, by(patent_focal year_focal)

*** CPC class of focal patent
	rename patent_focal patent_id
	merge m:1 patent_id using "$temp/patent_techClass",nogen keep(3)	
	
*** Average at the cpc - year 	
	gcollapse(mean) age, by(cpc year_focal)
	rename year_focal year 
	
	// Make sure the panel is balanced and since tech base is stable, assign t-1 value when missing 
	gegen cpc_temp = group(cpc)
	tsset cpc_temp year
	tsfill, full
	sort cpc_temp year 
	by cpc_temp: replace cpc = cpc[_n-1] if cpc=="" & _n>1
	* assign cpc to first years 
	gsort cpc_temp -year 
	by cpc_temp: replace cpc = cpc[_n-1] if cpc=="" & _n>1

	// Assign t-1 value for age when hole 
	sort cpc year 
	by cpc: replace age = age[_n-1] if age==. & _n>1
	
	drop cpc_temp
	
save "$temp/age_cited_cpc", replace
}
*
	
*===============================================================================
*===============================================================================
* Construct working sample: balanced panel
*===============================================================================
*===============================================================================
{	 		
*-------------------------------------------------------------------------------
* Balanced panel at tech-class x year 
*-------------------------------------------------------------------------------
	
	use cpc* year using "$temp/patent_workingdata", clear
	preserve 
		keep cpc cpcid  
		gduplicates drop cpc, force
		tempfile cpc_empty 
		save `cpc_empty'
	restore 
	
	preserve 
		keep year 
		gduplicates drop year, force
		cross using `cpc_empty'
		
		save "$temp/cpc_year_balanced", replace
	restore 
	
*** Compute stock 
	use "$temp/patent_workingdata", clear
	fmerge 1:1 patent_id using "$temp/nbcitation_patent", keep(1 3)  
	replace nbcit = 0 if _merge==1 
	drop _merge
	patstat_agg retech nbcit, g(cpcid) t(year) d(.2) w(5)
	save "$temp/patent_stock", replace
	
	
*** Collapse patent level data and merge 
	use "$temp/patent_workingdata", clear
	** Bring forward looking # citations 
	fmerge 1:1 patent_id using "$temp/nbcitation_patent", keep(1 3)  
	* patent not merged have zero citations 
	replace nbcit = 0 if _merge==1 
	
	** Collapse at the tech-class level 
	gcollapse (sd) sdcit = nbcit, by(cpc year)
	merge 1:1 cpc year using "$temp/cpc_year_balanced",nogen 
	
	merge 1:1 cpcid year using "$temp/patent_stock", keep(3) nogen
	
	gen it_cpc 		= regexm(cpc, "^(G06F|G06Q|H04L|H04W|H04M|H04Q|H04B|H04H|H04N|G11B|H04R|H01L|H01J|H01B|H01Q|H01C|H01G|H05K|G01|G05B)$")

	
*** Merge with average age of cited patents 
	merge 1:1 cpc year using "$temp/age_cited_cpc", keep(1 3)  nogen 
		
	save "$temp/cpc_year_workingdata02", replace
	
}
*	
	
*===============================================================================
*===============================================================================
* Create overvaluation measures using Compustat     
*===============================================================================
*===============================================================================
{
*-------------------------------------------------------------------------------
* Construct price / sale in Compustat   
*-------------------------------------------------------------------------------

	local X "csho prcc_f pddur curcd indfmt gvkey datadate sic naics sale fic loc conm"
		
	use `X' using "$wrds/Compustat2024", clear 
	// Destring variables
	destring gvkey sic, replace
	
	// Apply standard data filters 
	keep if indfmt=="INDL"					/* keep only industrial format */	
	drop if (sic  >= 6000 & sic <= 6999)	/* eliminate financials */
	drop if (sic  >= 4900 & sic <= 4999)	/* eliminate utilities */
	drop if (sic  >= 0000 & sic <= 999)		/* eliminate Agriculture, Fishing & Hunting */
	drop if (sic  >= 8888 & sic <= 8888)	/* eliminate Foreign Governments, */
	drop if (sic  >= 9000 & sic <= 9999)	/* eliminate International affairs & non-operating establishments  */
	
	keep if gvkey!=. 						/* eliminate missing gvkeys */
	keep if datadate~=.						/* eliminate missing date of financials */
	keep if curcd=="USD"					/* eliminate financials not expressed in USD */
	drop loc curcd fic pddur 
	
	* Calendar year
	gen year 		= year(datadate)

	* Ensuring that no duplicates exist
	gsort gvkey year -datadate
	by gvkey year: keep if _n==1
	
	* mk val according to Compustat 
	gen mkval_comp = csho*prcc_f
	drop csho prcc_f
	keep if year >=1990 & year<=2020
	
	* ps 
	gen ps1		= mkval_comp/sale 
		
	keep gvkey year ps1 sale mkval_comp
	save "$temp/compustat_ps", replace

	
*-------------------------------------------------------------------------------
* Merge Compustat with patents using Bowen concordance and collapse by CPC 
*-------------------------------------------------------------------------------

*** Attach year to pat id
	use "$patent/pnum_gvkey",clear 
	rename pnum patent_id 
	merge 1:1 patent_id using "$temp/patent_workingdata",keep(3) keepusing(year cpc) nogen 
	* we can now bring the market val measure 
	merge m:1 gvkey year using "$temp/compustat_ps",keep(3)  nogen 
	
	keep if ps1<.	
	
	** Yearly winsor among firms that have patents 
	winsor4 ps1 , method(winsor) outlier(tail) level(1) group(year)
	
*** Compute average PS by tech class 
	** Weighted mean using sales as weight
	* Compute the weight
	gegen sum_sales  			= sum(sale), by(cpc year)
	* Compute the weighted mean
	foreach var in ps1{
		gegen weighted_`var' 	= sum(`var' * sale), by(cpc year)
		gen meanvw_`var' 		= weighted_`var' / sum_sales	
		label var meanvw_`var'  "`var' - weighted mean"
	}
	gegen sum_mkval		= sum(mkval_comp), by(cpc year)
	gen meanvw2_ps1		= sum_mkval / sum_sales	

	** Get both weighted and regular mean
	gen meanew_ps1 = ps1 
	gcollapse(mean) mean*_* , by(cpc year)
	winsor4 meanvw2_ps1, method(winsor) outlier(tail) level(1) group(year)
		
	** Get overvaluation measure in 1999 and 2000 and keep one obs per cpc 
	foreach var in  meanvw_ps1 meanew_ps1 meanvw2_ps1 { 
		gegen `var'_9900 = rowmean(`var'_1999 `var'_2000)
	}
	keep cpc *_9900 
	gduplicates drop cpc, force
	save "$temp/cpc_overvaluation",replace
	
*-------------------------------------------------------------------------------
* Merge overvaluation with working data 
*-------------------------------------------------------------------------------
	
	use "$temp/cpc_year_workingdata02", clear
	merge m:1 cpc using "$temp/cpc_overvaluation",nogen keep(1 3)
	save "$temp/cpc_year_workingdata03", replace
	
}
*	


*===============================================================================
*===============================================================================
* Produce graphs
*===============================================================================
*===============================================================================

*-------------------------------------------------------------------------------
* Event study: ICT vs. Non ICT  
*-------------------------------------------------------------------------------

*** Estimate event study
use "$temp/cpc_year_workingdata02", clear
keep if year>=1990 & year<=2010

foreach var in retech_stock5 sdcit age  {
evstudydd `var' year,t(it_cpc) shockt(1993) period(2 16) fe(cpc year) cl(cpc)  ///
name("$temp/`var'_it_nonit")
}


*** Plot graph

foreach var in age sdcit retech_stock5  { //
clear
local i = 0

local i = `i'+1
append using "$temp/`var'_it_nonit"
replace time = time+1993 if time<1900
Coeff `i' 1993

graph twoway ///
(rcap B1inf B1sup t1, $se $light_red) ///
(scatter B1 t1, $beta_diamond $redF) ///
$graph $graphwhite  $leg_white xsize(8) ///
leg(off)
graph export "$results/evstudy_ITnonIT_`var'.pdf", as(pdf) replace
}

*-------------------------------------------------------------------------------
* Event study: ICT vs. Non ICT + Overvalued vs not  
*-------------------------------------------------------------------------------

use "$temp/cpc_year_workingdata03", clear
keep if year>=1990 & year<=2010

* Define median within IT vs not, otherwise very often none of the cpc IT have zero overvaluation
local bubbleDef "meanvw_ps1_9900"
gquantiles p50_`bubbleDef' = `bubbleDef',xtile nq(2) by(it_cpc)
replace p50_`bubbleDef' = p50_`bubbleDef'-1

foreach var in age sdcit retech_stock5 {


preserve
keep if p50_`bubbleDef'==0
evstudydd `var' year,t(it_cpc) shockt(1993) period(2 16) fe(cpc year) cl(cpc) ///
name("$temp/`var'_it_nonit_overval_low")
restore

preserve
keep if p50_`bubbleDef'==1
evstudydd `var' year,t(it_cpc) shockt(1993) period(2 16) fe(cpc year) cl(cpc) ///
name("$temp/`var'_it_nonit_overval_high")
restore
}

*** Produce graph
foreach var in age sdcit retech_stock5 {
clear
local i = 0

local i = `i'+1
append using "$temp/`var'_it_nonit_overval_low"
replace time = time+1993 if time<1900
Coeff `i' 1993
label var B`i' "Overvaluation: low"
local i = `i'+1
append using "$temp/`var'_it_nonit_overval_high"
replace time = time+1993 if time<1900
Coeff `i' 1993
label var B`i' "Overvaluation: high"

graph twoway ///
(rcap B1inf B1sup t1, $se $light_blue) ///
(scatter B1 t1, $beta_diamond $blueF) ///
(rcap B2inf B2sup t2, $se $light_red) ///
(scatter B2 t2, $beta_square $redF) ///
$graph $graphwhite  $leg_white xsize(8) ///
leg(order (2  4 )) leg(row(1) pos(6))
graph export "$results/evstudy_ITnonIT_`var'_overvalued.pdf", as(pdf) replace
} 
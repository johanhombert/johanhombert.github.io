

* CPS data
use "data/cps1990", clear
append using "data/cps2000"
append using "data/cps2010"
drop if year>2015

* Share ICT
foreach var in _emp _empUnder30 _empOver30 _empUnder30_coll4{
gen S`var' = ict`var'/(ict`var'+nict`var')
}
keep if year<=2010

* Graph 
graph twoway ///
	(line S_empUnder30 year, lwidth(medthick) lcolor(maroon)) ///
	(line S_empOver30 year, lwidth(medthick) lcolor(navy%80)) ///
	, ylabel(, angle(0) nogrid) graphregion(fcolor(white)) bgcolor(white) ytitle("Employment Share") ///
	graphregion(color(white)) legend(region(lcolor(white) lwidth(vlarge)) symxsize(9) forcesize  ) leg(on) ///
	legend(order (1 "Share ICT age <30" 2 "Share ICT age >30"))
graph export "FigC1_ict_emp.pdf", as(pdf) replace
